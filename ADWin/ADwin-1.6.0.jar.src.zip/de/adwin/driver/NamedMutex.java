/*    */ package de.adwin.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.nio.channels.FileLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NamedMutex
/*    */ {
/*    */   private final int LangID;
/*    */   private final RandomAccessFile LockFile;
/*    */   private final FileChannel fch;
/* 26 */   private FileLock CurrentLock = null;
/*    */   
/*    */   public NamedMutex(int Slot, int LangID) throws ADwinCommunicationError {
/* 29 */     this.LangID = LangID;
/* 30 */     String LockFileName = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + "ADwinDevice" + Slot + "_Lock";
/*    */     try {
/* 32 */       this.LockFile = new RandomAccessFile(LockFileName, "rw");
/* 33 */     } catch (IOException ioe) {
/* 34 */       throw new ADwinCommunicationError("Error when synchronizing on the ADwin system (" + ioe + ")", "Fehler beim Synchronisieren des Zugriffs auf das ADwin-System (" + ioe + ")", LangID, 4000);
/*    */     } 
/*    */ 
/*    */     
/* 38 */     if (this.LockFile == null) {
/* 39 */       throw new ADwinCommunicationError("Error when synchronizing on the ADwin system, File " + LockFileName + " cannot be created", "Fehler beim Synchronisieren des Zugriffs auf das ADwin-System, Datei " + LockFileName + " kann nicht erstellt werden", LangID, 4000);
/*    */     }
/*    */ 
/*    */     
/* 43 */     this.fch = this.LockFile.getChannel();
/*    */   }
/*    */   
/*    */   public synchronized void enter() throws ADwinCommunicationError {
/*    */     try {
/* 48 */       this.CurrentLock = this.fch.lock();
/* 49 */     } catch (Exception e) {
/* 50 */       throw new ADwinCommunicationError("Error when synchronizing on the ADwin system (" + e + ")", "Fehler beim Synchronisieren des Zugriffs auf das ADwin-System (" + e + ")", this.LangID, 4000);
/*    */     } 
/*    */ 
/*    */     
/* 54 */     if (this.CurrentLock == null) {
/* 55 */       throw new ADwinCommunicationError("The underlying operating system does not support file locks", "Das Betriebssystem unterstützt keine file locks", this.LangID, 4000);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void leave() throws ADwinCommunicationError {
/*    */     try {
/* 64 */       this.CurrentLock.release();
/* 65 */     } catch (IOException ioe) {
/* 66 */       throw new ADwinCommunicationError("Error when synchronizing on the ADwin system (" + ioe + ")", "Fehler beim Synchronisieren des Zugriffs auf das ADwin-System (" + ioe + ")", this.LangID, 4000);
/*    */     }
/*    */     finally {
/*    */       
/* 70 */       this.CurrentLock = null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void close() {
/*    */     try {
/* 76 */       this.LockFile.close();
/*    */     }
/* 78 */     catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */   
/*    */   protected void finalize() {
/* 83 */     close();
/*    */   }
/*    */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\NamedMutex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */