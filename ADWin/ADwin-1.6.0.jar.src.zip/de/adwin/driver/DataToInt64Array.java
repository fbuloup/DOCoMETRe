/*     */ package de.adwin.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataToInt64Array
/*     */   extends DataToArrayConverter
/*     */ {
/*     */   protected long[] Array;
/*     */   
/*     */   DataToInt64Array(int Size, int SourceType) {
/* 171 */     super(Size);
/* 172 */     this.Array = new long[Size];
/* 173 */     this.SourceType = SourceType;
/*     */   }
/*     */   
/*     */   long[] getArray() {
/* 177 */     return this.Array;
/*     */   }
/*     */   
/*     */   void storeBytesImpl(byte[] Bytes, int BytesIndex, int IndexStart, int Amount) {
/*     */     int i;
/* 182 */     switch (this.SourceType) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 8:
/* 186 */         for (i = 0; i < Amount; i++) {
/* 187 */           this.Array[IndexStart + i] = ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4);
/*     */         }
/*     */         break;
/*     */       case 5:
/* 191 */         for (i = 0; i < Amount; i++) {
/* 192 */           this.Array[IndexStart + i] = (int)Float.intBitsToFloat(ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4));
/*     */         }
/*     */         break;
/*     */       case 6:
/* 196 */         for (i = 0; i < Amount; i++) {
/* 197 */           this.Array[IndexStart + i] = (int)ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*     */         }
/*     */         break;
/*     */       case 7:
/* 201 */         for (i = 0; i < Amount; i++)
/* 202 */           this.Array[IndexStart + i] = ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getLong(); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   String getString() {
/* 208 */     StringBuilder Str = new StringBuilder(0);
/*     */     
/* 210 */     for (int n = 1; n < this.Array.length && this.Array[n] != 0L; n++) {
/* 211 */       Str.append((char)(int)this.Array[n]);
/*     */     }
/* 213 */     return Str.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataToInt64Array.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */