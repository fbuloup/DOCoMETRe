/*    */ package de.adwin.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class DataToArrayConverter
/*    */ {
/*    */   static final int DATATYPE_DOUBLE = 6;
/*    */   static final int DATATYPE_INT64 = 7;
/*    */   protected int SourceType;
/* 33 */   private int offset = 0;
/*    */   final int size;
/*    */   
/*    */   DataToArrayConverter(int size) {
/* 37 */     this.size = size;
/*    */   }
/*    */   
/*    */   void setOffset(int offset) {
/* 41 */     this.offset = offset;
/*    */   }
/*    */   
/*    */   int getOffset() {
/* 45 */     return this.offset;
/*    */   }
/*    */   
/*    */   void storeBytes(byte[] Bytes, int BytesIndex, int IndexStart, int Amount) {
/* 49 */     int length = Amount;
/* 50 */     int start = IndexStart;
/* 51 */     int BytesPerValue = 4;
/* 52 */     if (this.SourceType == 6)
/* 53 */       BytesPerValue = 8; 
/* 54 */     if (this.offset != 0) {
/* 55 */       start -= this.offset;
/*    */     }
/* 57 */     if (start < 0) {
/* 58 */       length += start;
/* 59 */       BytesIndex -= start * BytesPerValue;
/* 60 */       start = 0;
/*    */     } 
/* 62 */     if (start + length > this.size) {
/* 63 */       length = this.size - start;
/*    */     }
/* 65 */     storeBytesImpl(Bytes, BytesIndex, start, length);
/*    */   }
/*    */   
/*    */   abstract void storeBytesImpl(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   public void setSourceType(int SourceType) {
/* 71 */     if (SourceType == 4) {
/* 72 */       SourceType = 3;
/*    */     }
/* 74 */     this.SourceType = SourceType;
/*    */   }
/*    */   
/*    */   public int getSourceType() {
/* 78 */     return this.SourceType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataToArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */