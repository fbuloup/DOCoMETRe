/*     */ package de.adwin.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataToFloatArray
/*     */   extends DataToArrayConverter
/*     */ {
/*     */   protected float[] Array;
/*     */   
/*     */   DataToFloatArray(int Size, int SourceType) {
/* 222 */     super(Size);
/* 223 */     this.Array = new float[Size];
/* 224 */     this.SourceType = SourceType;
/*     */   }
/*     */   
/*     */   float[] getArray() {
/* 228 */     return this.Array;
/*     */   }
/*     */   
/*     */   void storeBytesImpl(byte[] Bytes, int BytesIndex, int IndexStart, int Amount) {
/*     */     int i;
/* 233 */     switch (this.SourceType) {
/*     */       case 2:
/*     */       case 3:
/* 236 */         for (i = 0; i < Amount; i++) {
/* 237 */           this.Array[IndexStart + i] = ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4);
/*     */         }
/*     */         break;
/*     */       case 5:
/* 241 */         for (i = 0; i < Amount; i++) {
/* 242 */           this.Array[IndexStart + i] = Float.intBitsToFloat(ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4));
/*     */         }
/*     */         break;
/*     */       case 6:
/* 246 */         for (i = 0; i < Amount; i++) {
/* 247 */           this.Array[IndexStart + i] = (float)ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*     */         }
/*     */         break;
/*     */       case 7:
/* 251 */         for (i = 0; i < Amount; i++)
/* 252 */           this.Array[IndexStart + i] = (float)ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getLong(); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataToFloatArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */