/*      */ package de.adwin.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.util.Objects;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class DataFieldTransfer
/*      */ {
/*      */   final InetAddress Connection;
/*      */   final DatagramSocket ds;
/*      */   final ADwinDirectDevice adw;
/*      */   public static final int PACKAGE_OVERHEAD = 8;
/*      */   public static final int BYTES_PER_PACKAGE = 1400;
/*      */   public static final int BYTES_PER_PACKAGE_WITH_OVERHEAD = 1408;
/*      */   
/*      */   DataFieldTransfer(InetAddress ip, DatagramSocket dgs, ADwinDirectDevice ADObject) {
/*   33 */     this.Connection = ip;
/*   34 */     this.ds = dgs;
/*   35 */     this.adw = ADObject;
/*      */   }
/*      */   
/*      */   void receive(int Length, DataToArrayConverter dtac, String NameReceived) throws ADwinCommunicationError {
/*   39 */     if (this.adw.adl != null) {
/*   40 */       this.adw.adl.enter("DataFieldTransfer.receive (" + Length + ", <DTAC>, \"" + NameReceived + "\")");
/*      */     }
/*      */ 
/*      */     
/*   44 */     int WordsReceived = 0;
/*   45 */     int CurrentBlock = 0;
/*   46 */     int NumBlockRetryLeft = this.adw.AllowedErrors;
/*      */     
/*   48 */     byte[] DataBytes = new byte[1408];
/*   49 */     byte[] Confirmation = new byte[32];
/*   50 */     DatagramPacket dp = new DatagramPacket(DataBytes, 1408);
/*   51 */     DatagramPacket ConfirmationPacket = new DatagramPacket(Confirmation, 32, this.Connection, this.adw.Port);
/*      */     
/*      */     try {
/*   54 */       this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/*   55 */     } catch (IOException ioe) {
/*   56 */       if (this.adw.adl != null) {
/*   57 */         this.adw.adl.leave();
/*      */       }
/*   59 */       throw new ADwinCommunicationError("Cannot set timeout for socket - " + ioe.getMessage(), "Kann Timeout für Socket nicht festlegen - " + ioe
/*   60 */           .getMessage(), this.adw.Language, 2000);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   70 */     while (WordsReceived < Length) {
/*   71 */       boolean[] RecvdPackets = new boolean[this.adw.DataBlockSize];
/*   72 */       for (int n = 0; n < this.adw.DataBlockSize; n++) {
/*   73 */         RecvdPackets[n] = false;
/*      */       }
/*      */       
/*   76 */       int NumPacketsMissing = (Length - WordsReceived - 1) / 350 + 1;
/*   77 */       if (NumPacketsMissing > this.adw.DataBlockSize) {
/*   78 */         NumPacketsMissing = this.adw.DataBlockSize;
/*      */       }
/*      */       
/*   81 */       CurrentBlock++;
/*      */       
/*   83 */       for (int Packet = 0; Packet < NumPacketsMissing; ) {
/*   84 */         boolean SomethingReceived = true;
/*      */         try {
/*   86 */           this.ds.receive(dp);
/*   87 */         } catch (SocketTimeoutException ste) {
/*   88 */           if (this.adw.adl != null) {
/*   89 */             this.adw.adl.message("Timeout beim empfangen vom DATA", 50);
/*      */           }
/*      */           
/*   92 */           SomethingReceived = false;
/*   93 */         } catch (IOException ioe) {
/*   94 */           if (this.adw.adl != null) {
/*   95 */             this.adw.adl.message("IOException -> ADwinCommunicationError in DataFieldTransfer.receive", 1);
/*      */             
/*   97 */             this.adw.adl.leave();
/*      */           } 
/*   99 */           throw new ADwinCommunicationError("I/O-Exception: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  100 */               .getMessage(), this.adw.Language, 2000);
/*      */         } 
/*      */ 
/*      */         
/*  104 */         if (SomethingReceived) {
/*  105 */           int BlockIndex = ADwinDirectDevice.extractInt(DataBytes, 0);
/*  106 */           if (BlockIndex < 0) {
/*  107 */             if (this.adw.adl != null) {
/*  108 */               this.adw.adl.message("Block index < 0 received", 1);
/*  109 */               this.adw.adl.leave();
/*      */             } 
/*  111 */             throw new ADwinCommunicationError("Invalid block index received when receiving " + NameReceived + ".", "Ungültigen Blockindex beim Empfangen von " + NameReceived + " empfangen", this.adw.Language, 2000);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  116 */           if (BlockIndex != CurrentBlock) {
/*  117 */             Packet--;
/*  118 */             if (this.adw.adl != null) {
/*  119 */               this.adw.adl.message("Ungültiger Block-Index (Erwartet: " + CurrentBlock + ", erhalten: " + BlockIndex + ")", 50);
/*      */             }
/*      */           }
/*  122 */           else if (dp.getLength() != 1408) {
/*  123 */             Packet--;
/*  124 */             if (this.adw.adl != null) {
/*  125 */               this.adw.adl.message("Falsche Größe: " + dp.getLength(), 50);
/*      */             }
/*      */           } else {
/*      */             
/*  129 */             int DataWordsCount, PacketIndex = ADwinDirectDevice.extractInt(DataBytes, 4);
/*      */ 
/*      */             
/*  132 */             RecvdPackets[PacketIndex] = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  139 */             if (WordsReceived + (PacketIndex + 1) * 350 <= Length) {
/*  140 */               DataWordsCount = 350;
/*      */             } else {
/*  142 */               DataWordsCount = Length % 350;
/*      */             } 
/*      */             
/*  145 */             dtac.storeBytes(DataBytes, 8, WordsReceived + PacketIndex * 350, DataWordsCount);
/*      */           } 
/*      */ 
/*      */           
/*      */           Packet++;
/*      */         } 
/*      */       } 
/*      */       
/*  153 */       int MaxIndexRecvd = NumPacketsMissing + 1;
/*  154 */       boolean AnythingReceived = false; int i;
/*  155 */       for (i = 0; i < this.adw.DataBlockSize; i++) {
/*  156 */         if (!RecvdPackets[i] && MaxIndexRecvd == NumPacketsMissing + 1) {
/*  157 */           MaxIndexRecvd = i;
/*      */         }
/*  159 */         if (RecvdPackets[i]) {
/*  160 */           AnythingReceived = true;
/*      */         }
/*      */       } 
/*  163 */       if (MaxIndexRecvd > NumPacketsMissing) {
/*  164 */         MaxIndexRecvd = NumPacketsMissing;
/*      */       }
/*  166 */       if (!AnythingReceived) {
/*  167 */         CurrentBlock--;
/*      */       }
/*      */       
/*  170 */       WordsReceived += MaxIndexRecvd * 350;
/*  171 */       if (MaxIndexRecvd == 0) {
/*  172 */         if (this.adw.adl != null) {
/*  173 */           this.adw.adl.message("Keine Pakete empfangen (WordsReceived = " + WordsReceived + ")", 50);
/*      */         }
/*      */ 
/*      */         
/*  177 */         NumBlockRetryLeft--;
/*      */       } else {
/*  179 */         NumBlockRetryLeft = this.adw.AllowedErrors;
/*      */       } 
/*      */       
/*  182 */       if (NumBlockRetryLeft == 0) {
/*  183 */         if (this.adw.adl != null) {
/*  184 */           this.adw.adl.leave();
/*      */         }
/*  186 */         throw new ADwinCommunicationError("Could not receive packets for " + NameReceived + ", number of timeouts exceeded AllowedErrors", "Konnte Pakete für " + NameReceived + " nicht empfangen, Anzahl der erlaubten Timeouts überschritten", this.adw.Language, 2001);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  193 */       if (AnythingReceived) {
/*  194 */         for (i = 0; i < 32; i++) {
/*  195 */           Confirmation[i] = 0;
/*      */         }
/*  197 */         if (MaxIndexRecvd != NumPacketsMissing) {
/*  198 */           ADwinDirectDevice.setInteger(Confirmation, 0, -20);
/*  199 */           ADwinDirectDevice.setInteger(Confirmation, 4, CurrentBlock);
/*  200 */           ADwinDirectDevice.setInteger(Confirmation, 8, MaxIndexRecvd);
/*      */         } else {
/*  202 */           ADwinDirectDevice.setInteger(Confirmation, 0, 0);
/*  203 */           ADwinDirectDevice.setInteger(Confirmation, 4, CurrentBlock);
/*  204 */           ADwinDirectDevice.setInteger(Confirmation, 8, 0);
/*      */         } 
/*      */       } 
/*      */       
/*      */       try {
/*  209 */         this.ds.send(ConfirmationPacket);
/*      */       }
/*  211 */       catch (IOException ioe) {
/*  212 */         if (this.adw.adl != null) {
/*  213 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  214 */           this.adw.adl.leave();
/*      */         } 
/*  216 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  217 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */     } 
/*      */     
/*  221 */     if (this.adw.adl != null) {
/*  222 */       this.adw.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   void receiveADwinX(int Count, DataToArrayConverter dtac, String NameReceived) throws ADwinCommunicationError {
/*      */     int values_per_package;
/*  228 */     if (this.adw.adl != null) {
/*  229 */       this.adw.adl.enter("DataFieldTransfer.receiveADwinX (" + Count + ", <DTAC>, \"" + NameReceived + "\")");
/*      */     }
/*      */ 
/*      */     
/*  233 */     int WordsReceived = 0;
/*  234 */     int CurrentBlock = 0;
/*  235 */     int NumBlockRetryLeft = this.adw.AllowedErrors;
/*  236 */     int bytes_per_value = this.adw.BytesPerValue(dtac.getSourceType());
/*      */     
/*  238 */     if (bytes_per_value == 8) {
/*  239 */       values_per_package = 175;
/*      */     } else {
/*  241 */       values_per_package = 350;
/*      */     } 
/*  243 */     byte[] DataBytes = new byte[1408];
/*  244 */     byte[] Confirmation = new byte[32];
/*  245 */     DatagramPacket dp = new DatagramPacket(DataBytes, 1408);
/*  246 */     DatagramPacket ConfirmationPacket = new DatagramPacket(Confirmation, 32, this.Connection, this.adw.Port);
/*      */     
/*      */     try {
/*  249 */       this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/*  250 */     } catch (IOException ioe) {
/*  251 */       if (this.adw.adl != null) {
/*  252 */         this.adw.adl.leave();
/*      */       }
/*  254 */       throw new ADwinCommunicationError("Cannot set timeout for socket - " + ioe.getMessage(), "Kann Timeout für Socket nicht festlegen - " + ioe
/*  255 */           .getMessage(), this.adw.Language, 2000);
/*      */     } 
/*      */ 
/*      */     
/*  259 */     while (WordsReceived < Count) {
/*  260 */       boolean[] RecvdPackets = new boolean[this.adw.DataBlockSize];
/*  261 */       for (int n = 0; n < this.adw.DataBlockSize; n++) {
/*  262 */         RecvdPackets[n] = false;
/*      */       }
/*      */ 
/*      */       
/*  266 */       int NumPacketsMissing = (Count - WordsReceived - 1) / values_per_package + 1;
/*  267 */       if (NumPacketsMissing > this.adw.DataBlockSize) {
/*  268 */         NumPacketsMissing = this.adw.DataBlockSize;
/*      */       }
/*      */       
/*  271 */       CurrentBlock++;
/*      */       
/*  273 */       for (int Packet = 0; Packet < NumPacketsMissing; ) {
/*  274 */         boolean SomethingReceived = true;
/*      */         try {
/*  276 */           this.ds.receive(dp);
/*  277 */         } catch (SocketTimeoutException ste) {
/*  278 */           if (this.adw.adl != null) {
/*  279 */             this.adw.adl.message("Timeout beim empfangen vom DATA", 50);
/*      */           }
/*      */           
/*  282 */           SomethingReceived = false;
/*  283 */         } catch (IOException ioe) {
/*  284 */           if (this.adw.adl != null) {
/*  285 */             this.adw.adl.message("IOException -> ADwinCommunicationError in DataFieldTransfer.receive", 1);
/*      */             
/*  287 */             this.adw.adl.leave();
/*      */           } 
/*  289 */           throw new ADwinCommunicationError("I/O-Exception: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  290 */               .getMessage(), this.adw.Language, 2000);
/*      */         } 
/*      */ 
/*      */         
/*  294 */         if (SomethingReceived) {
/*  295 */           int BlockIndex = ADwinDirectDevice.extractInt(DataBytes, 0);
/*  296 */           if (BlockIndex < 0) {
/*  297 */             if (this.adw.adl != null) {
/*  298 */               this.adw.adl.message("Block index < 0 received", 1);
/*  299 */               this.adw.adl.leave();
/*      */             } 
/*  301 */             throw new ADwinCommunicationError("Invalid block index received when receiving " + NameReceived + ".", "Ungültigen Blockindex beim Empfangen von " + NameReceived + " empfangen", this.adw.Language, 2000);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  306 */           if (BlockIndex != CurrentBlock) {
/*  307 */             Packet--;
/*  308 */             if (this.adw.adl != null) {
/*  309 */               this.adw.adl.message("Ungültiger Block-Index (Erwartet: " + CurrentBlock + ", erhalten: " + BlockIndex + ")", 50);
/*      */             }
/*      */           }
/*  312 */           else if (dp.getLength() != 1408) {
/*  313 */             Packet--;
/*  314 */             if (this.adw.adl != null) {
/*  315 */               this.adw.adl.message("Falsche Größe: " + dp.getLength(), 50);
/*      */             }
/*      */           } else {
/*      */             
/*  319 */             int DataWordsCount, PacketIndex = ADwinDirectDevice.extractInt(DataBytes, 4);
/*  320 */             RecvdPackets[PacketIndex] = true;
/*      */             
/*  322 */             if (WordsReceived + (PacketIndex + 1) * values_per_package <= Count) {
/*  323 */               DataWordsCount = values_per_package;
/*      */             } else {
/*  325 */               DataWordsCount = Count % values_per_package;
/*      */             } 
/*  327 */             dtac.storeBytes(DataBytes, 8, WordsReceived + PacketIndex * values_per_package, DataWordsCount);
/*      */           } 
/*      */           
/*      */           Packet++;
/*      */         } 
/*      */       } 
/*      */       
/*  334 */       int MaxIndexRecvd = NumPacketsMissing + 1;
/*  335 */       boolean AnythingReceived = false; int i;
/*  336 */       for (i = 0; i < this.adw.DataBlockSize; i++) {
/*  337 */         if (!RecvdPackets[i] && MaxIndexRecvd == NumPacketsMissing + 1) {
/*  338 */           MaxIndexRecvd = i;
/*      */         }
/*  340 */         if (RecvdPackets[i]) {
/*  341 */           AnythingReceived = true;
/*      */         }
/*      */       } 
/*  344 */       if (MaxIndexRecvd > NumPacketsMissing) {
/*  345 */         MaxIndexRecvd = NumPacketsMissing;
/*      */       }
/*  347 */       if (!AnythingReceived) {
/*  348 */         CurrentBlock--;
/*      */       }
/*      */ 
/*      */       
/*  352 */       WordsReceived += MaxIndexRecvd * values_per_package;
/*  353 */       if (MaxIndexRecvd == 0) {
/*  354 */         if (this.adw.adl != null) {
/*  355 */           this.adw.adl.message("Keine Pakete empfangen (WordsReceived = " + WordsReceived + ")", 50);
/*      */         }
/*      */ 
/*      */         
/*  359 */         NumBlockRetryLeft--;
/*      */       } else {
/*  361 */         NumBlockRetryLeft = this.adw.AllowedErrors;
/*      */       } 
/*      */       
/*  364 */       if (NumBlockRetryLeft == 0) {
/*  365 */         if (this.adw.adl != null) {
/*  366 */           this.adw.adl.leave();
/*      */         }
/*  368 */         throw new ADwinCommunicationError("Could not receive packets for " + NameReceived + ", number of timeouts exceeded AllowedErrors", "Konnte Pakete für " + NameReceived + " nicht empfangen, Anzahl der erlaubten Timeouts überschritten", this.adw.Language, 2001);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  375 */       if (AnythingReceived) {
/*  376 */         for (i = 0; i < 32; i++) {
/*  377 */           Confirmation[i] = 0;
/*      */         }
/*  379 */         if (MaxIndexRecvd != NumPacketsMissing) {
/*  380 */           ADwinDirectDevice.setInteger(Confirmation, 0, -20);
/*  381 */           ADwinDirectDevice.setInteger(Confirmation, 4, CurrentBlock);
/*  382 */           ADwinDirectDevice.setInteger(Confirmation, 8, MaxIndexRecvd);
/*      */         } else {
/*  384 */           ADwinDirectDevice.setInteger(Confirmation, 0, 0);
/*  385 */           ADwinDirectDevice.setInteger(Confirmation, 4, CurrentBlock);
/*  386 */           ADwinDirectDevice.setInteger(Confirmation, 8, 0);
/*      */         } 
/*      */       } 
/*      */       
/*      */       try {
/*  391 */         this.ds.send(ConfirmationPacket);
/*      */       }
/*  393 */       catch (IOException ioe) {
/*  394 */         if (this.adw.adl != null) {
/*  395 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  396 */           this.adw.adl.leave();
/*      */         } 
/*  398 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  399 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */     } 
/*      */     
/*  403 */     if (this.adw.adl != null) {
/*  404 */       this.adw.adl.leave();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   int receiveFast(int Count, DataToArrayConverter dtac, int Offset, int ExpectedPacketIndex, int[] WordsReceived) throws ADwinCommunicationError {
/*  410 */     byte[] PacketData = new byte[1416];
/*  411 */     DatagramPacket dp = new DatagramPacket(PacketData, 1416);
/*      */     
/*  413 */     int NumPacketsToReceive = (Count - 1) / 350 + 1;
/*  414 */     boolean[] PacketsRecvd = new boolean[NumPacketsToReceive];
/*  415 */     boolean SomethingReceived = true;
/*      */ 
/*      */     
/*      */     try {
/*  419 */       this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/*  420 */     } catch (IOException ioe) {
/*  421 */       throw new ADwinCommunicationError("Cannot set timeout for socket - " + ioe.getMessage(), "Kann Timeout für Socket nicht festlegen - " + ioe
/*  422 */           .getMessage(), this.adw.Language, 2000);
/*      */     } 
/*      */     
/*      */     int n;
/*  426 */     for (n = 0; n < NumPacketsToReceive && SomethingReceived; n++) {
/*      */       try {
/*  428 */         this.ds.receive(dp);
/*  429 */       } catch (SocketTimeoutException ste) {
/*  430 */         SomethingReceived = false;
/*  431 */       } catch (IOException ioe) {
/*  432 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  433 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  439 */       if (SomethingReceived) {
/*  440 */         if (!this.adw.newTryLater() && ADwinDirectDevice.extractInt(PacketData, 0) == -10) {
/*      */           break;
/*      */         }
/*  443 */         if (ADwinDirectDevice.extractInt(PacketData, 4) != ExpectedPacketIndex) {
/*  444 */           if (this.adw.adl != null) {
/*  445 */             this.adw.adl.message("Falscher Paket-Index empfangen, erwartet: " + ExpectedPacketIndex + ", erhalten: " + ADwinDirectDevice.extractInt(PacketData, 4), 50);
/*      */           }
/*      */           
/*  448 */           n--;
/*      */         } else {
/*      */           int NumDataWords;
/*  451 */           if (ADwinDirectDevice.extractInt(PacketData, 0) != 0) {
/*      */             break;
/*      */           }
/*      */           
/*  455 */           int IndexBlock = ADwinDirectDevice.extractInt(PacketData, 1408);
/*  456 */           PacketsRecvd[IndexBlock] = true;
/*  457 */           if (IndexBlock == NumPacketsToReceive - 1) {
/*  458 */             NumDataWords = Count % 350;
/*  459 */             if (NumDataWords == 0) {
/*  460 */               NumDataWords = 350;
/*      */             }
/*      */           } else {
/*  463 */             NumDataWords = 350;
/*      */           } 
/*      */           
/*  466 */           if (dtac.getSourceType() == 0) {
/*  467 */             dtac.setSourceType(ADwinDirectDevice.extractInt(PacketData, 1412));
/*      */           }
/*  469 */           dtac.storeBytes(PacketData, 8, IndexBlock * 350 + Offset, NumDataWords);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  482 */     for (n = 0; n < NumPacketsToReceive && 
/*  483 */       PacketsRecvd[n]; n++);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  488 */     WordsReceived[0] = n * 350;
/*  489 */     if (SomethingReceived) {
/*  490 */       return ADwinDirectDevice.extractInt(PacketData, 0);
/*      */     }
/*  492 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int receiveFastADwinX(int Count, DataToArrayConverter dtac, int Offset, int ExpectedPacketIndex, int[] WordsReceived) throws ADwinCommunicationError {
/*  499 */     byte[] PacketData = new byte[1416];
/*  500 */     DatagramPacket dp = new DatagramPacket(PacketData, 1416);
/*      */     
/*  502 */     int NumPacketsToReceive = (Count * 2 - 1) / 350 + 1;
/*  503 */     boolean[] PacketsRecvd = new boolean[NumPacketsToReceive];
/*  504 */     boolean SomethingReceived = true;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  509 */       this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/*  510 */     } catch (IOException ioe) {
/*  511 */       throw new ADwinCommunicationError("Cannot set timeout for socket - " + ioe.getMessage(), "Kann Timeout für Socket nicht festlegen - " + ioe
/*  512 */           .getMessage(), this.adw.Language, 2000);
/*      */     } 
/*      */     
/*      */     int n;
/*  516 */     for (n = 0; n < NumPacketsToReceive && SomethingReceived; n++) {
/*      */       try {
/*  518 */         this.ds.receive(dp);
/*  519 */       } catch (SocketTimeoutException ste) {
/*  520 */         SomethingReceived = false;
/*  521 */       } catch (IOException ioe) {
/*  522 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  523 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  529 */       if (SomethingReceived) {
/*  530 */         if (!this.adw.newTryLater() && ADwinDirectDevice.extractInt(PacketData, 0) == -10) {
/*      */           break;
/*      */         }
/*  533 */         if (ADwinDirectDevice.extractInt(PacketData, 4) != ExpectedPacketIndex) {
/*  534 */           if (this.adw.adl != null) {
/*  535 */             this.adw.adl.message("Falscher Paket-Index empfangen, erwartet: " + ExpectedPacketIndex + ", erhalten: " + ADwinDirectDevice.extractInt(PacketData, 4), 50);
/*      */           }
/*      */           
/*  538 */           n--;
/*      */         } else {
/*      */           
/*  541 */           if (ADwinDirectDevice.extractInt(PacketData, 0) != 0) {
/*      */             break;
/*      */           }
/*      */           
/*  545 */           if (dtac.getSourceType() == 0) {
/*  546 */             dtac.setSourceType(ADwinDirectDevice.extractInt(PacketData, 1412));
/*  547 */             if (dtac.getSourceType() != 6) {
/*  548 */               NumPacketsToReceive = (Count - 1) / 350 + 1;
/*      */             }
/*      */           } 
/*      */           
/*  552 */           int IndexBlock = ADwinDirectDevice.extractInt(PacketData, 1408);
/*  553 */           PacketsRecvd[IndexBlock] = true;
/*  554 */           if (dtac.getSourceType() == 6) {
/*  555 */             int NumDataWords; if (IndexBlock == NumPacketsToReceive - 1) {
/*  556 */               NumDataWords = Count % 175;
/*  557 */               if (NumDataWords == 0) {
/*  558 */                 NumDataWords = 175;
/*      */               }
/*      */             } else {
/*  561 */               NumDataWords = 175;
/*      */             } 
/*  563 */             dtac.storeBytes(PacketData, 8, IndexBlock * 175 + Offset, NumDataWords);
/*      */           } else {
/*      */             int NumDataWords;
/*      */             
/*  567 */             if (IndexBlock == NumPacketsToReceive - 1) {
/*  568 */               NumDataWords = Count % 350;
/*  569 */               if (NumDataWords == 0) {
/*  570 */                 NumDataWords = 350;
/*      */               }
/*      */             } else {
/*  573 */               NumDataWords = 350;
/*      */             } 
/*  575 */             dtac.storeBytes(PacketData, 8, IndexBlock * 350 + Offset, NumDataWords);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  590 */     for (n = 0; n < NumPacketsToReceive && 
/*  591 */       PacketsRecvd[n]; n++);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  596 */     WordsReceived[0] = n * 350;
/*  597 */     if (SomethingReceived) {
/*  598 */       return ADwinDirectDevice.extractInt(PacketData, 0);
/*      */     }
/*  600 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void send(int ByteCount, byte[] Data, String NameSend, int requestPacketIndex) throws ADwinCommunicationError {
/*  606 */     if (this.adw.adl != null) {
/*  607 */       this.adw.adl.enter("DataFieldTransfer.send (" + ByteCount + ", <byte[]>, \"" + NameSend + "\")");
/*      */     }
/*      */     
/*  610 */     byte[] PacketData = new byte[1408];
/*  611 */     byte[] ConfirmData = new byte[32];
/*  612 */     DatagramPacket dp = new DatagramPacket(PacketData, PacketData.length, this.Connection, this.adw.Port);
/*  613 */     DatagramPacket ConfPacket = new DatagramPacket(ConfirmData, 32);
/*      */     
/*  615 */     int BytesLeftToSend = ByteCount;
/*  616 */     int Block = 0;
/*  617 */     int NumBlockErrors = 0;
/*  618 */     int DataIndex = 0;
/*  619 */     boolean InvalidBlockIndexRecvd = false;
/*      */     
/*  621 */     while (BytesLeftToSend > 0) {
/*  622 */       int NumPackets = (BytesLeftToSend - 1) / 1400 + 1;
/*  623 */       if (NumPackets > this.adw.DataBlockSize) {
/*  624 */         NumPackets = this.adw.DataBlockSize;
/*      */       }
/*  626 */       for (int Packet = 0; Packet < NumPackets && !InvalidBlockIndexRecvd; Packet++) {
/*      */         int length;
/*  628 */         if (DataIndex + (Packet + 1) * 350 * 4 > ByteCount) {
/*  629 */           length = BytesLeftToSend % 1400;
/*  630 */           if (length == 0) {
/*  631 */             length = 1400;
/*      */           }
/*      */         } else {
/*  634 */           length = 1400;
/*      */         } 
/*      */         
/*  637 */         for (int n = 0; n < length; n++) {
/*  638 */           PacketData[n + 8] = Data[n + DataIndex + Packet * 350 * 4];
/*      */         }
/*      */         
/*  641 */         ADwinDirectDevice.setInteger(PacketData, 0, Block + 1);
/*  642 */         ADwinDirectDevice.setInteger(PacketData, 4, Packet);
/*      */         
/*      */         try {
/*  645 */           this.ds.send(dp);
/*      */         }
/*  647 */         catch (IOException ioe) {
/*  648 */           if (this.adw.adl != null) {
/*  649 */             this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  650 */             this.adw.adl.leave();
/*      */           } 
/*  652 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  653 */               .getMessage(), this.adw.Language, 2000);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  658 */       InvalidBlockIndexRecvd = false;
/*  659 */       boolean ConfirmationReceived = false;
/*      */       try {
/*  661 */         this.ds.setSoTimeout(this.adw.MaxPacketDelay * 2 + this.adw.ADwTimeout);
/*  662 */         this.ds.receive(ConfPacket);
/*  663 */         ConfirmationReceived = true;
/*  664 */       } catch (SocketTimeoutException ste) {
/*  665 */         if (this.adw.adl != null) {
/*  666 */           this.adw.adl.message("SocketTimeoutException beim Warten auf Bestätigung", 50);
/*      */         }
/*      */       }
/*  669 */       catch (IOException ioe) {
/*  670 */         if (this.adw.adl != null) {
/*  671 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  672 */           this.adw.adl.leave();
/*      */         } 
/*  674 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  675 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */       
/*  679 */       if (!ConfirmationReceived || ADwinDirectDevice.extractInt(ConfirmData, 4) != Block + 1) {
/*  680 */         if (ConfirmationReceived) {
/*  681 */           int packetIndex = ADwinDirectDevice.extractInt(ConfirmData, 4);
/*  682 */           int packetStatus = ADwinDirectDevice.extractInt(ConfirmData, 0);
/*  683 */           if (packetIndex == requestPacketIndex) {
/*  684 */             if (this.adw.adl != null) {
/*  685 */               this.adw.adl.message("SetData - Paket mit BlockIndex == requestPacketIndex (= " + packetIndex + ") empfangen, Status = " + packetStatus, 50);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*  690 */             switch (packetStatus) {
/*      */               case 1:
/*  692 */                 if (this.adw.adl != null) {
/*  693 */                   this.adw.adl.leave();
/*      */                 }
/*  695 */                 throw new ADwinCommunicationError("Timeout to link when trying to send " + NameSend, "Timeout beim Schreiben zum ADwin-System beim senden von " + NameSend, this.adw.Language, 1);
/*      */ 
/*      */               
/*      */               case 2:
/*  699 */                 if (this.adw.adl != null) {
/*  700 */                   this.adw.adl.leave();
/*      */                 }
/*  702 */                 throw new ADwinCommunicationError("Timeout from link when trying to send " + NameSend, "Timeout beim Lesen vom ADwin-System beim senden von " + NameSend, this.adw.Language, 2);
/*      */ 
/*      */               
/*      */               case 5:
/*  706 */                 if (this.adw.adl != null) {
/*  707 */                   this.adw.adl.leave();
/*      */                 }
/*  709 */                 throw new ADwinCommunicationError("Too many block errors when sending " + NameSend, "Zu viele fehlerhafte Blöcke beim Senden von " + NameSend, this.adw.Language, 2000);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           } 
/*  716 */           if (packetIndex == Block && NumBlockErrors > 1) {
/*      */ 
/*      */ 
/*      */             
/*  720 */             if (this.adw.adl != null) {
/*  721 */               this.adw.adl.message("Bestätigung für alten Block erhalten, sende den gleichen Block nochmal.", 50);
/*      */             }
/*      */             
/*  724 */             NumBlockErrors++;
/*  725 */             if (NumBlockErrors > this.adw.AllowedErrors) {
/*  726 */               if (this.adw.adl != null) {
/*  727 */                 this.adw.adl.message("Zu viele Fehler auf einmal -> Exception", 1);
/*  728 */                 this.adw.adl.leave();
/*      */               } 
/*  730 */               throw new ADwinCommunicationError("Cannot send " + NameSend, "Kann " + NameSend + " nicht senden", this.adw.Language, 2000);
/*      */             } 
/*      */ 
/*      */             
/*  734 */             InvalidBlockIndexRecvd = true;
/*      */             continue;
/*      */           } 
/*  737 */           if (this.adw.adl != null) {
/*  738 */             this.adw.adl.message("Für Bestätigung: Erwartet: " + (Block + 1) + ", erhalten: " + ADwinDirectDevice.extractInt(ConfirmData, 4), 50);
/*      */           }
/*      */           
/*  741 */           InvalidBlockIndexRecvd = true;
/*      */         } 
/*      */         
/*  744 */         NumBlockErrors++;
/*  745 */         if (NumBlockErrors > this.adw.AllowedErrors) {
/*  746 */           if (this.adw.adl != null) {
/*  747 */             this.adw.adl.message("Zu viele Fehler auf einmal -> Exception", 1);
/*  748 */             this.adw.adl.leave();
/*      */           } 
/*  750 */           throw new ADwinCommunicationError("Cannot send " + NameSend, "Kann " + NameSend + " nicht senden", this.adw.Language, 2000);
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*  755 */       Block++;
/*  756 */       NumBlockErrors = 0;
/*  757 */       if (ADwinDirectDevice.extractInt(ConfirmData, 0) == 5) {
/*  758 */         if (this.adw.adl != null) {
/*  759 */           this.adw.adl.message("Error 5...", 1);
/*  760 */           this.adw.adl.leave();
/*      */         } 
/*  762 */         throw new ADwinCommunicationError("Too many block errors when sending " + NameSend, "Zu viele fehlerhafte Blöcke beim Senden von " + NameSend, this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */       
/*  766 */       if (ADwinDirectDevice.extractInt(ConfirmData, 0) != 0) {
/*  767 */         int FirstPacketMissing = ADwinDirectDevice.extractInt(ConfirmData, 8);
/*  768 */         BytesLeftToSend -= FirstPacketMissing * 350 * 4;
/*  769 */         DataIndex += FirstPacketMissing * 350 * 4; continue;
/*      */       } 
/*  771 */       BytesLeftToSend -= this.adw.DataBlockSize * 350 * 4;
/*  772 */       DataIndex += this.adw.DataBlockSize * 350 * 4;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  777 */     if (this.adw.adl != null) {
/*  778 */       this.adw.adl.leave();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void getArraySH(int packetIndex, int count, DataToArrayConverter dtac, InetAddress addr, int port) throws ADwinCommunicationError {
/*  784 */     GetDataSHQueue gdshq = new GetDataSHQueue(40, packetIndex, this.ds, this.adw, addr, port);
/*  785 */     gdshq.getArraySH(count, dtac);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readFifo(int FifoNr, int Type, int NumWords, DataToArrayConverter dtac, int DtacOffset) throws ADwinCommunicationError {
/*  792 */     if (this.adw.adl != null) {
/*  793 */       this.adw.adl.enter("DataFieldTransfer.readFifo (" + FifoNr + ", " + Type + ", " + NumWords + ", <DTAC>, " + DtacOffset + ")");
/*      */     }
/*      */     
/*  796 */     int CMD_GET_FIFO_RETRY = 124;
/*  797 */     int CMD_GET_FIFO = 24;
/*      */     
/*  799 */     boolean EverythingReceived = false;
/*  800 */     boolean Retry = false;
/*  801 */     int SentIndex = 0;
/*  802 */     int RetryIndex = 0;
/*  803 */     byte[] PacketData = new byte[1408];
/*  804 */     DatagramPacket dp = new DatagramPacket(PacketData, 1408);
/*  805 */     int ErrorsLeft = this.adw.AllowedErrors;
/*  806 */     int TryLatersLeft = this.adw.NumWaits;
/*      */     
/*  808 */     int PacketsToReceive = (NumWords - 1) / 350 + 1;
/*  809 */     if (dtac.getSourceType() == 6)
/*  810 */       PacketsToReceive = (NumWords - 1) / 175 + 1; 
/*  811 */     while (!EverythingReceived) {
/*  812 */       boolean SomethingReceived; if (ErrorsLeft < 0) {
/*  813 */         if (this.adw.adl != null) {
/*  814 */           this.adw.adl.leave();
/*      */         }
/*  816 */         throw new ADwinCommunicationError("Too many errors", "zu viele Fehler", this.adw.Language, 2001);
/*      */       } 
/*      */       
/*  819 */       if (TryLatersLeft < 0) {
/*  820 */         if (this.adw.adl != null) {
/*  821 */           this.adw.adl.leave();
/*      */         }
/*  823 */         throw new ADwinCommunicationError("Too many try-later-packets", "zu viele Try-Later-Pakete", this.adw.Language, 16);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  828 */       Objects.requireNonNull(this.adw); ADwinCommand adwc = new ADwinCommand(this.adw.version, 3000447, this.adw.Port);
/*  829 */       adwc.setPwd(this.adw.Password);
/*  830 */       adwc.setTimeout(this.adw.ADwTimeout);
/*  831 */       int[] Values = { Type, FifoNr + (this.adw.DataBlockSize << 16), 0, NumWords };
/*  832 */       adwc.setValues(Values);
/*  833 */       if (Retry) {
/*  834 */         Values[2] = RetryIndex;
/*  835 */         adwc.setValues(Values);
/*  836 */         adwc.setPacketIndex(SentIndex);
/*  837 */         adwc.setCommand(124);
/*      */       } else {
/*  839 */         Values[2] = 0;
/*  840 */         adwc.setValues(Values);
/*  841 */         adwc.setPacketIndex(RetryIndex = SentIndex = this.adw.incGetCurrentIndex());
/*  842 */         adwc.setCommand(24);
/*      */       } 
/*      */       
/*      */       try {
/*  846 */         this.ds.send(adwc.getDatagram(this.Connection));
/*  847 */       } catch (IOException ioe) {
/*  848 */         if (this.adw.adl != null) {
/*  849 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  850 */           this.adw.adl.leave();
/*      */         } 
/*  852 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  853 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  859 */         this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/*  860 */         this.ds.receive(dp);
/*  861 */       } catch (SocketTimeoutException ste) {
/*  862 */         if (this.adw.adl != null) {
/*  863 */           this.adw.adl.message("Timeout beim warten auf 1. Datenpaket", 50);
/*      */         }
/*  865 */         Retry = true;
/*  866 */         ErrorsLeft--;
/*      */         continue;
/*  868 */       } catch (IOException ioe) {
/*  869 */         if (this.adw.adl != null) {
/*  870 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  871 */           this.adw.adl.leave();
/*      */         } 
/*  873 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  874 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */       
/*  878 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -10) {
/*  879 */         if (this.adw.adl != null) {
/*  880 */           this.adw.adl.tryLater(SentIndex, this.adw.NumWaits - TryLatersLeft);
/*      */         }
/*      */         try {
/*  883 */           Thread.sleep(this.adw.WaitTime);
/*  884 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/*  887 */         TryLatersLeft--;
/*  888 */         ErrorsLeft = this.adw.AllowedErrors;
/*      */         continue;
/*      */       } 
/*  891 */       TryLatersLeft = this.adw.NumWaits;
/*  892 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -41) {
/*  893 */         if (this.adw.adl != null) {
/*  894 */           this.adw.adl.message("Fehler -41 => Anfrage wird nochmal verschickt", 50);
/*      */         }
/*  896 */         Retry = false;
/*      */         continue;
/*      */       } 
/*  899 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -32) {
/*  900 */         if (this.adw.adl != null) {
/*  901 */           this.adw.adl.message("No more data in fifo", 1);
/*      */         }
/*  903 */         throw new ADwinCommunicationError("Not enough data in fifo", "Nicht genug Daten im Fifo", this.adw.Language, 102);
/*      */       } 
/*      */       
/*  906 */       if (ADwinDirectDevice.extractInt(PacketData, 0) < 0) {
/*  907 */         if (this.adw.adl != null) {
/*  908 */           this.adw.adl.message("Fehler " + ADwinDirectDevice.extractInt(PacketData, 0) + " => Retry-Paket wird verschickt", 50);
/*      */         }
/*      */         
/*  911 */         Retry = true;
/*  912 */         ErrorsLeft--;
/*      */         continue;
/*      */       } 
/*  915 */       Retry = false;
/*      */ 
/*      */       
/*  918 */       boolean[] RecvdPackets = new boolean[PacketsToReceive];
/*  919 */       for (int n = 0; n < PacketsToReceive; n++) {
/*  920 */         RecvdPackets[n] = false;
/*      */       }
/*      */       
/*      */       do {
/*  924 */         if (ADwinDirectDevice.extractInt(PacketData, 0) == SentIndex) {
/*  925 */           int NumDataWords, PacketIndex = ADwinDirectDevice.extractInt(PacketData, 4);
/*      */           
/*  927 */           if (PacketIndex != PacketsToReceive - 1) {
/*  928 */             NumDataWords = 350;
/*      */           } else {
/*  930 */             NumDataWords = NumWords % 350;
/*      */           } 
/*  932 */           if (NumDataWords == 0) {
/*  933 */             NumDataWords = 350;
/*      */           }
/*      */           
/*  936 */           if (dtac.getSourceType() == 6) {
/*  937 */             if (NumDataWords >= 350) {
/*      */               
/*  939 */               dtac.storeBytes(PacketData, 8, DtacOffset + PacketIndex * 175, NumDataWords / 2);
/*      */             } else {
/*  941 */               dtac.storeBytes(PacketData, 8, DtacOffset + PacketIndex * 175, NumDataWords);
/*      */             } 
/*      */           } else {
/*      */             
/*  945 */             dtac.storeBytes(PacketData, 8, DtacOffset + PacketIndex * 350, NumDataWords);
/*  946 */           }  RecvdPackets[PacketIndex] = true;
/*      */ 
/*      */           
/*  949 */           EverythingReceived = true;
/*  950 */           for (int i = 0; i < PacketsToReceive; i++) {
/*  951 */             EverythingReceived = (EverythingReceived && RecvdPackets[i]);
/*      */           }
/*  953 */           if (EverythingReceived) {
/*      */             break;
/*      */           }
/*  956 */         } else if (this.adw.adl != null) {
/*  957 */           this.adw.adl.message("Falscher Paket-Index empfangen (erhalten: " + ADwinDirectDevice.extractInt(PacketData, 0) + ", erwartet: " + SentIndex + ")", 50);
/*      */         } 
/*      */ 
/*      */         
/*  961 */         SomethingReceived = true;
/*      */         try {
/*  963 */           this.ds.receive(dp);
/*  964 */         } catch (SocketTimeoutException ste) {
/*  965 */           SomethingReceived = false;
/*  966 */         } catch (IOException ioe) {
/*  967 */           if (this.adw.adl != null) {
/*  968 */             this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/*  969 */             this.adw.adl.leave();
/*      */           } 
/*  971 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  972 */               .getMessage(), this.adw.Language, 2000);
/*      */         }
/*      */       
/*  975 */       } while (SomethingReceived);
/*      */       
/*  977 */       if (!EverythingReceived) {
/*  978 */         if (this.adw.adl != null) {
/*  979 */           this.adw.adl.message("Nicht alles empfangen => Retry", 50);
/*      */         }
/*  981 */         ErrorsLeft--;
/*  982 */         Retry = true;
/*      */       } 
/*      */     } 
/*  985 */     if (this.adw.adl != null) {
/*  986 */       this.adw.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   void readFifo_angepasst(int FifoNr, int Type, int NumWords, DataToArrayConverter dtac, int DtacOffset) throws ADwinCommunicationError {
/*      */     int values_per_package;
/*  992 */     if (this.adw.adl != null) {
/*  993 */       this.adw.adl.enter("DataFieldTransfer.readFifo (" + FifoNr + ", " + Type + ", " + NumWords + ", <DTAC>, " + DtacOffset + ")");
/*      */     }
/*      */ 
/*      */     
/*  997 */     int CMD_GET_FIFO_RETRY = 124;
/*  998 */     int CMD_GET_FIFO = 24;
/*      */     
/* 1000 */     int bytes_per_value = this.adw.BytesPerValue(Type);
/*      */     
/* 1002 */     if (bytes_per_value == 8) {
/* 1003 */       values_per_package = 175;
/*      */     } else {
/* 1005 */       values_per_package = 350;
/*      */     } 
/*      */ 
/*      */     
/* 1009 */     float SizeFactor = 1.0F;
/* 1010 */     if (bytes_per_value == 8) {
/* 1011 */       SizeFactor = 2.0F;
/*      */     }
/* 1013 */     boolean EverythingReceived = false;
/* 1014 */     boolean Retry = false;
/* 1015 */     int SentIndex = 0;
/* 1016 */     int RetryIndex = 0;
/* 1017 */     byte[] PacketData = new byte[1408];
/* 1018 */     DatagramPacket dp = new DatagramPacket(PacketData, 1408);
/* 1019 */     int ErrorsLeft = this.adw.AllowedErrors;
/* 1020 */     int TryLatersLeft = this.adw.NumWaits;
/* 1021 */     int PacketsToReceive = (int)((NumWords * SizeFactor - 1.0F) / values_per_package + 1.0F);
/* 1022 */     while (!EverythingReceived) {
/* 1023 */       boolean SomethingReceived; if (ErrorsLeft < 0) {
/* 1024 */         if (this.adw.adl != null) {
/* 1025 */           this.adw.adl.leave();
/*      */         }
/* 1027 */         throw new ADwinCommunicationError("Too many errors", "zu viele Fehler", this.adw.Language, 2001);
/*      */       } 
/*      */       
/* 1030 */       if (TryLatersLeft < 0) {
/* 1031 */         if (this.adw.adl != null) {
/* 1032 */           this.adw.adl.leave();
/*      */         }
/* 1034 */         throw new ADwinCommunicationError("Too many try-later-packets", "zu viele Try-Later-Pakete", this.adw.Language, 16);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1039 */       Objects.requireNonNull(this.adw); ADwinCommand adwc = new ADwinCommand(this.adw.version, 3000447, this.adw.Port);
/* 1040 */       adwc.setPwd(this.adw.Password);
/* 1041 */       adwc.setTimeout(this.adw.ADwTimeout);
/* 1042 */       int[] Values = { Type, FifoNr + (this.adw.DataBlockSize << 16), 0, NumWords };
/* 1043 */       adwc.setValues(Values);
/* 1044 */       if (Retry) {
/* 1045 */         Values[2] = RetryIndex;
/* 1046 */         adwc.setValues(Values);
/* 1047 */         adwc.setPacketIndex(SentIndex);
/* 1048 */         adwc.setCommand(124);
/*      */       } else {
/* 1050 */         Values[2] = 0;
/* 1051 */         adwc.setValues(Values);
/* 1052 */         adwc.setPacketIndex(RetryIndex = SentIndex = this.adw.incGetCurrentIndex());
/* 1053 */         adwc.setCommand(24);
/*      */       } 
/*      */       
/*      */       try {
/* 1057 */         this.ds.send(adwc.getDatagram(this.Connection));
/* 1058 */       } catch (IOException ioe) {
/* 1059 */         if (this.adw.adl != null) {
/* 1060 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/* 1061 */           this.adw.adl.leave();
/*      */         } 
/* 1063 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1064 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1070 */         this.ds.setSoTimeout(this.adw.MaxPacketDelay);
/* 1071 */         this.ds.receive(dp);
/* 1072 */       } catch (SocketTimeoutException ste) {
/* 1073 */         if (this.adw.adl != null) {
/* 1074 */           this.adw.adl.message("Timeout beim warten auf 1. Datenpaket", 50);
/*      */         }
/* 1076 */         Retry = true;
/* 1077 */         ErrorsLeft--;
/*      */         continue;
/* 1079 */       } catch (IOException ioe) {
/* 1080 */         if (this.adw.adl != null) {
/* 1081 */           this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/* 1082 */           this.adw.adl.leave();
/*      */         } 
/* 1084 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1085 */             .getMessage(), this.adw.Language, 2000);
/*      */       } 
/*      */ 
/*      */       
/* 1089 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -10) {
/* 1090 */         if (this.adw.adl != null) {
/* 1091 */           this.adw.adl.tryLater(SentIndex, this.adw.NumWaits - TryLatersLeft);
/*      */         }
/*      */         try {
/* 1094 */           Thread.sleep(this.adw.WaitTime);
/* 1095 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/* 1098 */         TryLatersLeft--;
/* 1099 */         ErrorsLeft = this.adw.AllowedErrors;
/*      */         continue;
/*      */       } 
/* 1102 */       TryLatersLeft = this.adw.NumWaits;
/* 1103 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -41) {
/* 1104 */         if (this.adw.adl != null) {
/* 1105 */           this.adw.adl.message("Fehler -41 => Anfrage wird nochmal verschickt", 50);
/*      */         }
/* 1107 */         Retry = false;
/*      */         continue;
/*      */       } 
/* 1110 */       if (ADwinDirectDevice.extractInt(PacketData, 0) == -32) {
/* 1111 */         if (this.adw.adl != null) {
/* 1112 */           this.adw.adl.message("No more data in fifo", 1);
/*      */         }
/* 1114 */         throw new ADwinCommunicationError("Not enough data in fifo", "Nicht genug Daten im Fifo", this.adw.Language, 102);
/*      */       } 
/*      */       
/* 1117 */       if (ADwinDirectDevice.extractInt(PacketData, 0) < 0) {
/* 1118 */         if (this.adw.adl != null) {
/* 1119 */           this.adw.adl.message("Fehler " + ADwinDirectDevice.extractInt(PacketData, 0) + " => Retry-Paket wird verschickt", 50);
/*      */         }
/*      */         
/* 1122 */         Retry = true;
/* 1123 */         ErrorsLeft--;
/*      */         continue;
/*      */       } 
/* 1126 */       Retry = false;
/*      */ 
/*      */       
/* 1129 */       boolean[] RecvdPackets = new boolean[PacketsToReceive];
/* 1130 */       for (int n = 0; n < PacketsToReceive; n++) {
/* 1131 */         RecvdPackets[n] = false;
/*      */       }
/*      */       
/*      */       do {
/* 1135 */         if (ADwinDirectDevice.extractInt(PacketData, 0) == SentIndex) {
/* 1136 */           int NumDataWords, PacketIndex = ADwinDirectDevice.extractInt(PacketData, 4);
/*      */           
/* 1138 */           if (PacketIndex != PacketsToReceive - 1) {
/* 1139 */             NumDataWords = values_per_package;
/*      */           } else {
/* 1141 */             NumDataWords = NumWords % values_per_package;
/*      */           } 
/* 1143 */           if (NumDataWords == 0) {
/* 1144 */             NumDataWords = values_per_package;
/*      */           }
/* 1146 */           dtac.storeBytes(PacketData, 8, DtacOffset + PacketIndex * values_per_package, NumDataWords);
/* 1147 */           RecvdPackets[PacketIndex] = true;
/*      */ 
/*      */           
/* 1150 */           EverythingReceived = true;
/* 1151 */           for (int i = 0; i < PacketsToReceive; i++) {
/* 1152 */             EverythingReceived = (EverythingReceived && RecvdPackets[i]);
/*      */           }
/* 1154 */           if (EverythingReceived) {
/*      */             break;
/*      */           }
/* 1157 */         } else if (this.adw.adl != null) {
/* 1158 */           this.adw.adl.message("Falscher Paket-Index empfangen (erhalten: " + ADwinDirectDevice.extractInt(PacketData, 0) + ", erwartet: " + SentIndex + ")", 50);
/*      */         } 
/*      */ 
/*      */         
/* 1162 */         SomethingReceived = true;
/*      */         try {
/* 1164 */           this.ds.receive(dp);
/* 1165 */         } catch (SocketTimeoutException ste) {
/* 1166 */           SomethingReceived = false;
/* 1167 */         } catch (IOException ioe) {
/* 1168 */           if (this.adw.adl != null) {
/* 1169 */             this.adw.adl.message("IOException -> ADwinCommunicationError", 1);
/* 1170 */             this.adw.adl.leave();
/*      */           } 
/* 1172 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1173 */               .getMessage(), this.adw.Language, 2000);
/*      */         }
/*      */       
/* 1176 */       } while (SomethingReceived);
/*      */       
/* 1178 */       if (!EverythingReceived) {
/* 1179 */         if (this.adw.adl != null) {
/* 1180 */           this.adw.adl.message("Nicht alles empfangen => Retry", 50);
/*      */         }
/* 1182 */         ErrorsLeft--;
/* 1183 */         Retry = true;
/*      */       } 
/*      */     } 
/* 1186 */     if (this.adw.adl != null)
/* 1187 */       this.adw.adl.leave(); 
/*      */   }
/*      */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataFieldTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */