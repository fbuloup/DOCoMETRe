/*    */ package de.adwin.driver;
/*    */ 
/*    */ import java.net.DatagramPacket;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ADwinCommand
/*    */ {
/*    */   private final byte[] Data;
/* 23 */   private int Version = 0;
/*    */   private final int Port;
/*    */   
/*    */   public ADwinCommand(int Version, int DLLVersion, int Port) {
/* 27 */     this.Version = Version;
/* 28 */     this.Port = Port;
/* 29 */     this.Data = new byte[((Version >= 252 && Version <= 259) || Version >= 264) ? 56 : 52];
/* 30 */     setTimeout(1000);
/* 31 */     setPwd("");
/* 32 */     if (this.Data.length == 56)
/*    */     {
/* 34 */       for (int n = 0; n < 4; n++)
/*    */       {
/* 36 */         this.Data[n + 52] = (byte)(DLLVersion << (3 - n) * 8 >>> 24);
/*    */       }
/*    */     }
/* 39 */     this.Data[44] = 32;
/*    */   }
/*    */   
/*    */   public int getCommand() {
/* 43 */     return ADwinDirectDevice.extractInt(this.Data, 0);
/*    */   }
/*    */   
/*    */   public void setCommand(int Command) {
/* 47 */     for (int n = 0; n < 4; n++) {
/* 48 */       this.Data[n] = (byte)(Command << (3 - n) * 8 >>> 24);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setPacketIndex(int Index) {
/* 53 */     for (int n = 0; n < 4; n++) {
/* 54 */       this.Data[n + 4] = (byte)(Index << (3 - n) * 8 >>> 24);
/*    */     }
/*    */   }
/*    */   
/*    */   public final void setPwd(String Pwd) {
/* 59 */     int n = 0;
/* 60 */     for (n = 0; n < 9 && n < Pwd.length(); n++) {
/* 61 */       this.Data[n + 8] = (byte)Pwd.charAt(n);
/*    */     }
/*    */     
/* 64 */     this.Data[n + 8] = 0;
/*    */   }
/*    */   
/*    */   public void setValues(int[] Values) {
/* 68 */     for (int i = 0; i < 4; i++) {
/* 69 */       for (int n = 0; n < 4; n++) {
/* 70 */         this.Data[n + 20 + i * 4] = (byte)(Values[i] << (3 - n) * 8 >>> 24);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setLink(int Link) {
/* 76 */     for (int n = 0; n < 4; n++) {
/* 77 */       this.Data[n + 36] = (byte)(Link << (3 - n) * 8 >>> 24);
/*    */     }
/*    */   }
/*    */   
/*    */   public final void setTimeout(int Timeout) {
/* 82 */     for (int n = 0; n < 4; n++) {
/* 83 */       this.Data[n + 40] = (byte)(Timeout << (3 - n) * 8 >>> 24);
/*    */     }
/*    */   }
/*    */   
/*    */   public DatagramPacket getDatagram(InetAddress addr) {
/* 88 */     return new DatagramPacket(this.Data, ((this.Version >= 252 && this.Version <= 259) || this.Version >= 264) ? 56 : 52, addr, this.Port);
/*    */   }
/*    */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */