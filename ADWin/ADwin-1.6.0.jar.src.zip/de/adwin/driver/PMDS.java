/*    */ package de.adwin.driver;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.DatagramPacket;
/*    */ import java.net.DatagramSocket;
/*    */ import java.net.SocketException;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PMDS
/*    */   extends DatagramSocket
/*    */ {
/*    */   private final Random r;
/*    */   private final ADwinDirectDevice add;
/* 28 */   double PercentLoss = 0.0D;
/*    */   
/*    */   PMDS(int Port, ADwinDirectDevice add) throws SocketException {
/* 31 */     super(Port);
/* 32 */     this.r = new Random();
/* 33 */     this.add = add;
/*    */   }
/*    */   
/*    */   public void send(DatagramPacket dp) throws IOException {
/* 37 */     if (!Thread.holdsLock(this)) {
/* 38 */       throw new Error();
/*    */     }
/* 40 */     if (this.r.nextInt(1000) > 10.0D * this.PercentLoss) {
/* 41 */       super.send(dp);
/* 42 */     } else if (this.add.adl != null) {
/* 43 */       this.add.adl.message("Verlust von Paket (vom PC) " + ADwinDirectDevice.extractInt(dp.getData(), 4), 1);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void receive(DatagramPacket dp) throws IOException {
/* 48 */     if (!Thread.holdsLock(this)) {
/* 49 */       throw new Error();
/*    */     }
/* 51 */     super.receive(dp);
/* 52 */     if (this.r.nextInt(1000) < 10.0D * this.PercentLoss) {
/* 53 */       if (this.add.adl != null) {
/* 54 */         this.add.adl.message("Verlust von Paket (vom ADwin-System) " + ADwinDirectDevice.extractInt(dp.getData(), 4), 1);
/*    */       }
/* 56 */       super.receive(dp);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\PMDS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */