/*      */ package de.adwin.driver;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.MissingResourceException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ADwinDevice
/*      */ {
/*      */   public static final int LANGID_ENGLISH = 1;
/*      */   public static final int LANGID_GERMAN = 2;
/*      */   public static final int LANGID_SYSDEFAULT = 0;
/*      */   
/*      */   private static class Dev
/*      */   {
/*      */     InetAddress IP;
/*      */     String Password;
/*      */     int Timeout;
/*      */     int ADTimeout;
/*      */     int AllowedErrors;
/*      */     int WaitTime;
/*      */     int Blocksize;
/*      */     
/*      */     private Dev() {}
/*      */     
/*   42 */     int NumWaits = 10000000;
/*      */     
/*      */     int Hostlink;
/*      */     
/*      */     int Port;
/*      */   }
/*      */   
/*      */   public enum first_pcarray_index_t
/*      */   {
/*   51 */     zero,
/*   52 */     one;
/*      */   }
/*      */   
/*   55 */   private static final HashMap Devices = new HashMap<>();
/*      */   private int LangID;
/*   57 */   private NamedMutex nm = null;
/*   58 */   private int CurrentDeviceNo = 0;
/*   59 */   private ADwinDirectDevice add = null;
/*      */   
/*      */   private boolean UseFileLocks = false;
/*   62 */   private int NAN_test = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ADwinDevice() {
/*      */     try {
/*   72 */       if (Locale.getDefault().getISO3Language().compareTo("deu") != 0) {
/*   73 */         this.LangID = 1;
/*      */       } else {
/*   75 */         this.LangID = 2;
/*      */       } 
/*   77 */     } catch (MissingResourceException mre) {
/*   78 */       this.LangID = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Add_Entry(int deviceNo, InetAddress ipAddressADwinSystem, String password, int tcpipServerDeviceNo, int port) {
/*  108 */     Add_Entry(deviceNo, ipAddressADwinSystem, password, 1000, 1000, 3, 20, 100, 5, tcpipServerDeviceNo, port);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Add_Entry(int deviceNo, InetAddress ipAddressADwinSystem, String password, int tcpipServerDeviceNo, int port, int networkTimeout) {
/*  139 */     Add_Entry(deviceNo, ipAddressADwinSystem, password, networkTimeout, networkTimeout, 3, 20, 100, 5, tcpipServerDeviceNo, port);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Add_Entry(int DevNo, InetAddress IP, String Password, int Timeout, int ADTimeout, int AllowedErrors, int NumWaits, int WaitTime, int Blocksize, int Hostlink, int Port) throws IllegalArgumentException {
/*  146 */     synchronized (Devices) {
/*  147 */       if (DevNo < 0) {
/*  148 */         throw new IllegalArgumentException("Only positive device numbers are allowed");
/*      */       }
/*  150 */       if (Devices.get(Integer.valueOf(DevNo)) != null) {
/*  151 */         throw new IllegalArgumentException("Device-No " + DevNo + " already exists");
/*      */       }
/*  153 */       Dev tmp = new Dev();
/*  154 */       tmp.IP = IP;
/*  155 */       tmp.Password = Password;
/*  156 */       tmp.Timeout = Timeout;
/*  157 */       tmp.ADTimeout = ADTimeout;
/*  158 */       tmp.AllowedErrors = AllowedErrors;
/*  159 */       tmp.NumWaits = NumWaits;
/*  160 */       tmp.WaitTime = WaitTime;
/*  161 */       tmp.Blocksize = Blocksize;
/*  162 */       tmp.Hostlink = Hostlink;
/*  163 */       tmp.Port = Port;
/*  164 */       Devices.put(Integer.valueOf(DevNo), tmp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean Remove_Entry(int DevNo) {
/*  178 */     synchronized (Devices) {
/*  179 */       return (Devices.remove(Integer.valueOf(DevNo)) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Use_FileLocks(boolean Usage) throws ADwinCommunicationError {
/*  203 */     this.UseFileLocks = Usage;
/*  204 */     if (!this.UseFileLocks && this.nm != null) {
/*  205 */       this.nm.close();
/*  206 */       this.nm = null;
/*  207 */     } else if (this.UseFileLocks && this.nm == null && this.CurrentDeviceNo > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  212 */       this.nm = new NamedMutex(this.CurrentDeviceNo, this.LangID);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_Language(int LanguageID) {
/*      */     try {
/*  224 */       if (LanguageID != 1 && LanguageID != 2) {
/*  225 */         if (Locale.getDefault().getISO3Language().compareTo("deu") != 0) {
/*  226 */           this.LangID = 1;
/*      */         } else {
/*  228 */           this.LangID = 2;
/*      */         } 
/*      */       } else {
/*  231 */         this.LangID = LanguageID;
/*      */       } 
/*  233 */     } catch (MissingResourceException mre) {
/*  234 */       this.LangID = 1;
/*      */     } 
/*  236 */     if (this.add != null) {
/*  237 */       this.add.Language = this.LangID;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] Get_Known_DeviceNo() {
/*      */     int[] Devs;
/*  249 */     synchronized (Devices) {
/*  250 */       Object[] KeySet = Devices.keySet().toArray();
/*  251 */       Devs = new int[Devices.size()];
/*  252 */       for (int n = 0; n < Devs.length; n++) {
/*  253 */         Devs[n] = ((Integer)KeySet[n]).intValue();
/*      */       }
/*      */     } 
/*      */     
/*  257 */     return Devs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_DeviceNo(int DevNo) throws ADwinCommunicationError {
/*  273 */     synchronized (Devices) {
/*      */ 
/*      */       
/*  276 */       Dev d = (Dev)Devices.get(Integer.valueOf(DevNo));
/*      */       
/*  278 */       if (d == null) {
/*  279 */         throw new IllegalArgumentException((this.LangID == 2) ? ("Device " + DevNo + " nicht in der Device-Tabelle") : (
/*  280 */             "Device " + DevNo + " is not in the device table"));
/*      */       }
/*  282 */       if (this.UseFileLocks && this.CurrentDeviceNo != DevNo) {
/*  283 */         if (this.nm != null) {
/*  284 */           this.nm.close();
/*      */         }
/*  286 */         this.nm = new NamedMutex(DevNo, this.LangID);
/*      */       } 
/*  288 */       this.CurrentDeviceNo = DevNo;
/*      */       try {
/*  290 */         if (this.UseFileLocks) {
/*  291 */           this.nm.enter();
/*      */         }
/*  293 */         this.add = new ADwinDirectDevice(d.IP, d.Port, d.Password, d.AllowedErrors, d.Timeout, d.Blocksize, d.ADTimeout, d.NumWaits, d.WaitTime, d.Hostlink);
/*      */       }
/*  295 */       catch (SocketException se) {
/*  296 */         throw new ADwinCommunicationError("The socket used to communicate with the ADwin system could not be created (" + se + ")", "Der Socket, der zur Kommunikation mit dem ADwin-System verwendet wird, konnte nicht erstellt werden (" + se + ")", this.LangID, 2000);
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/*  301 */         if (this.UseFileLocks) {
/*  302 */           this.nm.leave();
/*      */         }
/*      */       } 
/*  305 */       this.add.Language = this.LangID;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Get_DeviceNo() {
/*  316 */     return this.CurrentDeviceNo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Get_Par(int Index) throws ADwinCommunicationError {
/*  333 */     if (this.CurrentDeviceNo <= 0) {
/*  334 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  336 */     if (this.UseFileLocks) {
/*  337 */       this.nm.enter();
/*      */     }
/*  339 */     int Par = 0;
/*      */     try {
/*  341 */       Par = this.add.getPar(Index);
/*      */     } finally {
/*  343 */       if (this.UseFileLocks) {
/*  344 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  347 */     return Par;
/*      */   }
/*      */ 
/*      */   
/*      */   public void GetData_Packed(int DataNo, int[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  352 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  355 */     if (Count < 0) {
/*  356 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  358 */     if (Data.length < Count) {
/*  359 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  361 */     if (this.CurrentDeviceNo <= 0) {
/*  362 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  364 */     if (this.UseFileLocks) {
/*  365 */       this.nm.enter();
/*      */     }
/*  367 */     int RealCount = Count / 2 + (FirstIndex % 2 | Count % 2);
/*  368 */     int RealFirstIndex = FirstIndex / 2;
/*      */     try {
/*  370 */       int[] IntData = this.add.getDataInt(DataNo, RealFirstIndex, RealFirstIndex + RealCount - 1);
/*  371 */       for (int n = 0; n < Count; n++) {
/*  372 */         Data[n] = IntData[(FirstIndex % 2 & n % 2) + n / 2] << (FirstIndex + n + 1) % 2 * 16 >> 16;
/*      */       }
/*      */     } finally {
/*  375 */       if (this.UseFileLocks) {
/*  376 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void GetFifo_Packed(int FifoNo, int[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  383 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  386 */     if (Count < 0) {
/*  387 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  389 */     if (Data.length < Count) {
/*  390 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  392 */     if (this.CurrentDeviceNo <= 0) {
/*  393 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  395 */     if (this.UseFileLocks) {
/*  396 */       this.nm.enter();
/*      */     }
/*  398 */     int RealCount = Count / 2 + Count % 2;
/*      */     try {
/*  400 */       int[] IntData = this.add.getFifoInt(FifoNo, RealCount);
/*  401 */       for (int n = 0; n < Count; n++) {
/*  402 */         Data[n] = IntData[n / 2] << (n + 1) % 2 * 16 >> 16;
/*      */       }
/*      */     } finally {
/*  405 */       if (this.UseFileLocks) {
/*  406 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Processor_Type() throws ADwinCommunicationError {
/*  422 */     if (this.CurrentDeviceNo <= 0) {
/*  423 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  425 */     if (this.UseFileLocks) {
/*  426 */       this.nm.enter();
/*      */     }
/*  428 */     int ProcessorType = 0;
/*      */     try {
/*  430 */       ProcessorType = this.add.getProcessorType();
/*      */     } finally {
/*  432 */       if (this.UseFileLocks) {
/*  433 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  436 */     return ProcessorType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Int(int DataNo, int[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  458 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  461 */     if (Count < 0) {
/*  462 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  464 */     if (Data.length < Count) {
/*  465 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  467 */     if (this.CurrentDeviceNo <= 0) {
/*  468 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  470 */     if (this.UseFileLocks) {
/*  471 */       this.nm.enter();
/*      */     }
/*  473 */     int[] d = null;
/*      */     try {
/*  475 */       d = this.add.getDataInt(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  477 */       if (this.UseFileLocks) {
/*  478 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  481 */     System.arraycopy(d, 0, Data, 0, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void GetData_Long(int DataNo, int[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  505 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  508 */     if (Count < 0) {
/*  509 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  511 */     if (Data.length < Count) {
/*  512 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  514 */     if (this.CurrentDeviceNo <= 0) {
/*  515 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  517 */     if (this.UseFileLocks) {
/*  518 */       this.nm.enter();
/*      */     }
/*  520 */     int[] d = null;
/*      */     try {
/*  522 */       d = this.add.getDataInt(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  524 */       if (this.UseFileLocks) {
/*  525 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  528 */     System.arraycopy(d, 0, Data, 0, Count);
/*      */   }
/*      */ 
/*      */   
/*      */   public void GetData_Long(int DataNo, long[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  533 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  536 */     if (Count < 0) {
/*  537 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  539 */     if (Data.length < Count) {
/*  540 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  542 */     if (this.CurrentDeviceNo <= 0) {
/*  543 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  545 */     if (this.UseFileLocks) {
/*  546 */       this.nm.enter();
/*      */     }
/*  548 */     long[] d = null;
/*      */     try {
/*  550 */       d = this.add.getDataLong(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  552 */       if (this.UseFileLocks) {
/*  553 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  556 */     System.arraycopy(d, 0, Data, 0, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void GetData_Long(int DataNo, int[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  581 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  584 */     if (Count < 0) {
/*  585 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  587 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/*  588 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  590 */     if (this.CurrentDeviceNo <= 0) {
/*  591 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  593 */     if (this.UseFileLocks) {
/*  594 */       this.nm.enter();
/*      */     }
/*  596 */     int[] d = null;
/*      */     try {
/*  598 */       d = this.add.getDataInt(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  600 */       if (this.UseFileLocks) {
/*  601 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  604 */     System.arraycopy(d, 0, Data, FirstArrayIndex.ordinal(), Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Long(int DataNo, long[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  627 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  630 */     if (Count < 0) {
/*  631 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  633 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/*  634 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  636 */     if (this.CurrentDeviceNo <= 0) {
/*  637 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  639 */     if (this.UseFileLocks) {
/*  640 */       this.nm.enter();
/*      */     }
/*  642 */     long[] d = null;
/*      */     try {
/*  644 */       d = this.add.getDataLong(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  646 */       if (this.UseFileLocks) {
/*  647 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  650 */     System.arraycopy(d, 0, Data, FirstArrayIndex.ordinal(), Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Float(int DataNo, float[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  671 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  674 */     if (Count < 0) {
/*  675 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  677 */     if (Data.length < Count) {
/*  678 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  680 */     if (this.CurrentDeviceNo <= 0) {
/*  681 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  683 */     if (this.UseFileLocks) {
/*  684 */       this.nm.enter();
/*      */     }
/*  686 */     float[] d = null;
/*      */     try {
/*  688 */       d = this.add.getDataFloat(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  690 */       if (this.UseFileLocks) {
/*  691 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  694 */     System.arraycopy(d, 0, Data, 0, Count);
/*  695 */     test_float_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Float(int DataNo, float[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  718 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  721 */     if (Count < 0) {
/*  722 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  724 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/*  725 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  727 */     if (this.CurrentDeviceNo <= 0) {
/*  728 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  730 */     if (this.UseFileLocks) {
/*  731 */       this.nm.enter();
/*      */     }
/*  733 */     float[] d = null;
/*      */     try {
/*  735 */       d = this.add.getDataFloat(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  737 */       if (this.UseFileLocks) {
/*  738 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  741 */     System.arraycopy(d, 0, Data, FirstArrayIndex.ordinal(), Count);
/*  742 */     test_float_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Double(int DataNo, double[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  764 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  767 */     if (Count < 0) {
/*  768 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  770 */     if (Data.length < Count) {
/*  771 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  773 */     if (this.CurrentDeviceNo <= 0) {
/*  774 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  776 */     if (this.UseFileLocks) {
/*  777 */       this.nm.enter();
/*      */     }
/*  779 */     double[] d = null;
/*      */     try {
/*  781 */       d = this.add.getDataDouble(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  783 */       if (this.UseFileLocks) {
/*  784 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  787 */     System.arraycopy(d, 0, Data, 0, Count);
/*  788 */     test_double_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetData_Double(int DataNo, double[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/*  812 */     if (Count == 0) {
/*      */       return;
/*      */     }
/*  815 */     if (Count < 0) {
/*  816 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/*  818 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/*  819 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/*  821 */     if (this.CurrentDeviceNo <= 0) {
/*  822 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  824 */     if (this.UseFileLocks) {
/*  825 */       this.nm.enter();
/*      */     }
/*  827 */     double[] d = null;
/*      */     try {
/*  829 */       d = this.add.getDataDouble(DataNo, FirstIndex, FirstIndex + Count - 1);
/*      */     } finally {
/*  831 */       if (this.UseFileLocks) {
/*  832 */         this.nm.leave();
/*      */       }
/*      */     } 
/*  835 */     System.arraycopy(d, 0, Data, FirstArrayIndex.ordinal(), Count);
/*  836 */     test_double_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Long(int DataNo, int[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/*  856 */     if (Count <= 0) {
/*  857 */       throw new IllegalArgumentException();
/*      */     }
/*  859 */     if (Data.length < Count) {
/*  860 */       throw new IllegalArgumentException();
/*      */     }
/*  862 */     if (this.CurrentDeviceNo <= 0) {
/*  863 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  865 */     if (this.UseFileLocks) {
/*  866 */       this.nm.enter();
/*      */     }
/*      */     try {
/*  869 */       this.add.setDataInt(DataNo, Data, FirstIndex, Count);
/*      */     } finally {
/*  871 */       if (this.UseFileLocks) {
/*  872 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Long(int DataNo, long[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/*  894 */     if (Count <= 0) {
/*  895 */       throw new IllegalArgumentException();
/*      */     }
/*  897 */     if (Data.length < Count) {
/*  898 */       throw new IllegalArgumentException();
/*      */     }
/*  900 */     if (this.CurrentDeviceNo <= 0) {
/*  901 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  903 */     if (this.UseFileLocks) {
/*  904 */       this.nm.enter();
/*      */     }
/*      */     try {
/*  907 */       this.add.setDataLong(DataNo, Data, FirstIndex, Count);
/*      */     } finally {
/*  909 */       if (this.UseFileLocks) {
/*  910 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Long(int DataNo, int[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     int[] d;
/*  935 */     if (Count <= 0) {
/*  936 */       throw new IllegalArgumentException();
/*      */     }
/*  938 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/*  939 */       throw new IllegalArgumentException();
/*      */     }
/*  941 */     if (this.CurrentDeviceNo <= 0) {
/*  942 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  944 */     if (this.UseFileLocks) {
/*  945 */       this.nm.enter();
/*      */     }
/*  947 */     if (FirstArrayIndex == first_pcarray_index_t.one) {
/*  948 */       d = new int[Count];
/*  949 */       System.arraycopy(Data, 1, d, 0, Count);
/*      */     } else {
/*  951 */       d = Data;
/*      */     } 
/*      */     try {
/*  954 */       this.add.setDataInt(DataNo, d, FirstIndex, Count);
/*      */     } finally {
/*  956 */       if (this.UseFileLocks) {
/*  957 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Float(int DataNo, float[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/*  979 */     if (Count <= 0) {
/*  980 */       throw new IllegalArgumentException();
/*      */     }
/*  982 */     if (Data.length < Count) {
/*  983 */       throw new IllegalArgumentException();
/*      */     }
/*  985 */     if (this.CurrentDeviceNo <= 0) {
/*  986 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*  988 */     if (this.UseFileLocks) {
/*  989 */       this.nm.enter();
/*      */     }
/*      */     try {
/*  992 */       this.add.setDataFloat(DataNo, Data, FirstIndex, Count);
/*      */     } finally {
/*  994 */       if (this.UseFileLocks) {
/*  995 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Float(int DataNo, float[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     float[] d;
/* 1020 */     if (Count <= 0) {
/* 1021 */       throw new IllegalArgumentException();
/*      */     }
/* 1023 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/* 1024 */       throw new IllegalArgumentException();
/*      */     }
/* 1026 */     if (this.CurrentDeviceNo <= 0) {
/* 1027 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1029 */     if (this.UseFileLocks) {
/* 1030 */       this.nm.enter();
/*      */     }
/* 1032 */     if (FirstArrayIndex == first_pcarray_index_t.one) {
/* 1033 */       d = new float[Count];
/* 1034 */       System.arraycopy(Data, 1, d, 0, Count);
/*      */     } else {
/* 1036 */       d = Data;
/*      */     } 
/*      */     try {
/* 1039 */       this.add.setDataFloat(DataNo, d, FirstIndex, Count);
/*      */     } finally {
/* 1041 */       if (this.UseFileLocks) {
/* 1042 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Double(int DataNo, double[] Data, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1064 */     if (Count <= 0) {
/* 1065 */       throw new IllegalArgumentException();
/*      */     }
/* 1067 */     if (Data.length < Count) {
/* 1068 */       throw new IllegalArgumentException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/* 1070 */     if (this.CurrentDeviceNo <= 0) {
/* 1071 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1073 */     if (this.UseFileLocks) {
/* 1074 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1077 */       this.add.setDataDouble(DataNo, Data, FirstIndex, Count);
/*      */     } finally {
/* 1079 */       if (this.UseFileLocks) {
/* 1080 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_Double(int DataNo, double[] Data, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     double[] d;
/* 1105 */     if (Count <= 0) {
/* 1106 */       throw new IllegalArgumentException();
/*      */     }
/* 1108 */     if (Data.length < Count + FirstArrayIndex.ordinal()) {
/* 1109 */       throw new IllegalArgumentException();
/*      */     }
/* 1111 */     if (this.CurrentDeviceNo <= 0) {
/* 1112 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1114 */     if (this.UseFileLocks) {
/* 1115 */       this.nm.enter();
/*      */     }
/* 1117 */     if (FirstArrayIndex == first_pcarray_index_t.one) {
/* 1118 */       d = new double[Count];
/* 1119 */       System.arraycopy(Data, 1, d, 0, Count);
/*      */     } else {
/* 1121 */       d = Data;
/*      */     } 
/*      */     try {
/* 1124 */       this.add.setDataDouble(DataNo, d, FirstIndex, Count);
/*      */     } finally {
/* 1126 */       if (this.UseFileLocks) {
/* 1127 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_Par(int Index, int Value) throws ADwinCommunicationError {
/* 1145 */     if (this.CurrentDeviceNo <= 0) {
/* 1146 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1148 */     if (this.UseFileLocks) {
/* 1149 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1152 */       this.add.setPar(Index, Value);
/*      */     } finally {
/* 1154 */       if (this.UseFileLocks) {
/* 1155 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_Par_Block(int[] Array, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1174 */     if (Count <= 0) {
/* 1175 */       throw new IllegalArgumentException();
/*      */     }
/* 1177 */     if (Array.length < Count) {
/* 1178 */       throw new IllegalArgumentException();
/*      */     }
/* 1180 */     if (this.CurrentDeviceNo <= 0) {
/* 1181 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1183 */     if (this.UseFileLocks) {
/* 1184 */       this.nm.enter();
/*      */     }
/* 1186 */     int[] Params = null;
/*      */     try {
/* 1188 */       Params = this.add.getParIntBlock(FirstIndex, Count);
/*      */     } finally {
/* 1190 */       if (this.UseFileLocks) {
/* 1191 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1194 */     System.arraycopy(Params, 0, Array, 0, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_Par_Block(int[] Array, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/* 1213 */     if (Count <= 0) {
/* 1214 */       throw new IllegalArgumentException();
/*      */     }
/* 1216 */     if (Array.length < Count + FirstArrayIndex.ordinal()) {
/* 1217 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1220 */     if (this.CurrentDeviceNo <= 0) {
/* 1221 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1223 */     if (this.UseFileLocks) {
/* 1224 */       this.nm.enter();
/*      */     }
/* 1226 */     int[] Params = null;
/*      */     try {
/* 1228 */       Params = this.add.getParIntBlock(FirstIndex, Count);
/*      */     } finally {
/* 1230 */       if (this.UseFileLocks) {
/* 1231 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1234 */     System.arraycopy(Params, 0, Array, FirstArrayIndex.ordinal(), Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_Block(float[] Array, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1251 */     if (Count <= 0) {
/* 1252 */       throw new IllegalArgumentException();
/*      */     }
/* 1254 */     if (Array.length < Count) {
/* 1255 */       throw new IllegalArgumentException();
/*      */     }
/* 1257 */     if (this.CurrentDeviceNo <= 0) {
/* 1258 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1260 */     if (this.UseFileLocks) {
/* 1261 */       this.nm.enter();
/*      */     }
/* 1263 */     float[] Params = null;
/*      */     try {
/* 1265 */       Params = this.add.getParFloatBlock(FirstIndex, Count);
/*      */     } finally {
/* 1267 */       if (this.UseFileLocks) {
/* 1268 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1271 */     System.arraycopy(Params, 0, Array, 0, Count);
/* 1272 */     test_float_buffer_qnan(Array, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_Block(float[] Array, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/* 1290 */     if (Count <= 0) {
/* 1291 */       throw new IllegalArgumentException();
/*      */     }
/* 1293 */     if (Array.length < Count + FirstArrayIndex.ordinal()) {
/* 1294 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1297 */     if (this.CurrentDeviceNo <= 0) {
/* 1298 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1300 */     if (this.UseFileLocks) {
/* 1301 */       this.nm.enter();
/*      */     }
/* 1303 */     float[] Params = null;
/*      */     try {
/* 1305 */       Params = this.add.getParFloatBlock(FirstIndex, Count);
/*      */     } finally {
/* 1307 */       if (this.UseFileLocks) {
/* 1308 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1311 */     System.arraycopy(Params, 0, Array, FirstArrayIndex.ordinal(), Count);
/* 1312 */     test_float_buffer_qnan(Array, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_Block_Double(double[] Array, int FirstIndex, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1329 */     if (Count <= 0) {
/* 1330 */       throw new IllegalArgumentException();
/*      */     }
/* 1332 */     if (Array.length < Count) {
/* 1333 */       throw new IllegalArgumentException();
/*      */     }
/* 1335 */     if (this.CurrentDeviceNo <= 0) {
/* 1336 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1338 */     if (this.UseFileLocks) {
/* 1339 */       this.nm.enter();
/*      */     }
/* 1341 */     double[] Params = null;
/*      */     try {
/* 1343 */       Params = this.add.getParFloatBlockDouble(FirstIndex, Count);
/*      */     } finally {
/* 1345 */       if (this.UseFileLocks) {
/* 1346 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1349 */     System.arraycopy(Params, 0, Array, 0, Count);
/* 1350 */     test_double_buffer_qnan(Array, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_Block_Double(double[] Array, int FirstIndex, int Count, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError, IllegalArgumentException {
/* 1368 */     if (Count <= 0) {
/* 1369 */       throw new IllegalArgumentException();
/*      */     }
/* 1371 */     if (Array.length < Count + FirstArrayIndex.ordinal()) {
/* 1372 */       throw new IllegalArgumentException();
/*      */     }
/* 1374 */     if (this.CurrentDeviceNo <= 0) {
/* 1375 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1377 */     if (this.UseFileLocks) {
/* 1378 */       this.nm.enter();
/*      */     }
/* 1380 */     double[] Params = null;
/*      */     try {
/* 1382 */       Params = this.add.getParFloatBlockDouble(FirstIndex, Count);
/*      */     } finally {
/* 1384 */       if (this.UseFileLocks) {
/* 1385 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1388 */     System.arraycopy(Params, 0, Array, FirstArrayIndex.ordinal(), Count);
/* 1389 */     test_double_buffer_qnan(Array, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Data_Length(int DataNo) throws ADwinCommunicationError {
/* 1403 */     if (this.CurrentDeviceNo <= 0) {
/* 1404 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1406 */     if (this.UseFileLocks) {
/* 1407 */       this.nm.enter();
/*      */     }
/* 1409 */     int Length = 0;
/*      */     try {
/* 1411 */       Length = this.add.getDataLength(DataNo) - 1;
/*      */     } finally {
/* 1413 */       if (this.UseFileLocks) {
/* 1414 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1417 */     return Length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Fifo_Empty(int FifoNo) throws ADwinCommunicationError {
/* 1434 */     if (this.CurrentDeviceNo <= 0) {
/* 1435 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1437 */     if (this.UseFileLocks) {
/* 1438 */       this.nm.enter();
/*      */     }
/* 1440 */     int FreeElements = 0;
/*      */     try {
/* 1442 */       FreeElements = this.add.getFifoFree(FifoNo);
/*      */     } finally {
/* 1444 */       if (this.UseFileLocks) {
/* 1445 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1448 */     return FreeElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Fifo_Full(int FifoNo) throws ADwinCommunicationError {
/* 1466 */     if (this.CurrentDeviceNo <= 0) {
/* 1467 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1469 */     if (this.UseFileLocks) {
/* 1470 */       this.nm.enter();
/*      */     }
/* 1472 */     int UsedElements = 0;
/*      */     try {
/* 1474 */       UsedElements = this.add.getFifoUsed(FifoNo);
/*      */     } finally {
/* 1476 */       if (this.UseFileLocks) {
/* 1477 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1480 */     return UsedElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Fifo_Clear(int FifoNo) throws ADwinCommunicationError {
/* 1495 */     if (this.CurrentDeviceNo <= 0) {
/* 1496 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1498 */     if (this.UseFileLocks) {
/* 1499 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1502 */       this.add.clearFifo(FifoNo);
/*      */     } finally {
/* 1504 */       if (this.UseFileLocks) {
/* 1505 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetFifo_Long(int FifoNo, int[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1526 */     if (Count <= 0) {
/* 1527 */       throw new IllegalArgumentException();
/*      */     }
/* 1529 */     if (Data.length < Count) {
/* 1530 */       throw new IllegalArgumentException();
/*      */     }
/* 1532 */     if (this.CurrentDeviceNo <= 0) {
/* 1533 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1535 */     if (this.UseFileLocks) {
/* 1536 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1539 */       this.add.setFifoInt(FifoNo, Count, Data);
/*      */     } finally {
/* 1541 */       if (this.UseFileLocks) {
/* 1542 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetFifo_Float(int FifoNo, float[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1563 */     if (Count <= 0) {
/* 1564 */       throw new IllegalArgumentException();
/*      */     }
/* 1566 */     if (Data.length < Count) {
/* 1567 */       throw new IllegalArgumentException();
/*      */     }
/* 1569 */     if (this.CurrentDeviceNo <= 0) {
/* 1570 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1572 */     if (this.UseFileLocks) {
/* 1573 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1576 */       this.add.setFifoFloat(FifoNo, Count, Data);
/*      */     } finally {
/* 1578 */       if (this.UseFileLocks) {
/* 1579 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetFifo_Double(int FifoNo, double[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException {
/* 1600 */     if (Count <= 0) {
/* 1601 */       throw new IllegalArgumentException();
/*      */     }
/* 1603 */     if (Data.length < Count) {
/* 1604 */       throw new IllegalArgumentException();
/*      */     }
/* 1606 */     if (this.CurrentDeviceNo <= 0) {
/* 1607 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1609 */     if (this.UseFileLocks) {
/* 1610 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1613 */       this.add.setFifoDouble(FifoNo, Count, Data);
/*      */     } finally {
/* 1615 */       if (this.UseFileLocks) {
/* 1616 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_Par_All(int[] Array) throws ADwinCommunicationError {
/* 1632 */     Get_Par_Block(Array, 1, 80);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_Par_All(int[] Array, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError {
/* 1650 */     Get_Par_Block(Array, 1, 80, FirstArrayIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_All(float[] Array) throws ADwinCommunicationError {
/* 1664 */     Get_FPar_Block(Array, 1, 80);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_All(float[] Array, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError {
/* 1680 */     Get_FPar_Block(Array, 1, 80, FirstArrayIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_All_Double(double[] Array) throws ADwinCommunicationError {
/* 1695 */     Get_FPar_Block_Double(Array, 1, 80);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Get_FPar_All_Double(double[] Array, first_pcarray_index_t FirstArrayIndex) throws ADwinCommunicationError {
/* 1711 */     Get_FPar_Block_Double(Array, 1, 80, FirstArrayIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetFifo_Long(int FifoNo, int[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/* 1729 */     if (Count == 0) {
/*      */       return;
/*      */     }
/* 1732 */     if (Count < 0) {
/* 1733 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/* 1735 */     if (Data.length < Count) {
/* 1736 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/* 1738 */     if (this.CurrentDeviceNo <= 0) {
/* 1739 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1741 */     if (this.UseFileLocks) {
/* 1742 */       this.nm.enter();
/*      */     }
/* 1744 */     int[] Dat = null;
/*      */     try {
/* 1746 */       Dat = this.add.getFifoInt(FifoNo, Count);
/*      */     } finally {
/* 1748 */       if (this.UseFileLocks) {
/* 1749 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1752 */     System.arraycopy(Dat, 0, Data, 0, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetFifo_Float(int FifoNo, float[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/* 1770 */     if (Count == 0) {
/*      */       return;
/*      */     }
/* 1773 */     if (Count < 0) {
/* 1774 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/* 1776 */     if (Data.length < Count) {
/* 1777 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/* 1779 */     if (this.CurrentDeviceNo <= 0) {
/* 1780 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1782 */     if (this.UseFileLocks) {
/* 1783 */       this.nm.enter();
/*      */     }
/* 1785 */     float[] Dat = null;
/*      */     try {
/* 1787 */       Dat = this.add.getFifoFloat(FifoNo, Count);
/*      */     } finally {
/* 1789 */       if (this.UseFileLocks) {
/* 1790 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1793 */     System.arraycopy(Dat, 0, Data, 0, Count);
/* 1794 */     test_float_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void GetFifo_Double(int FifoNo, double[] Data, int Count) throws ADwinCommunicationError, IllegalArgumentException, IndexOutOfBoundsException {
/* 1812 */     if (Count == 0) {
/*      */       return;
/*      */     }
/* 1815 */     if (Count < 0) {
/* 1816 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/* 1818 */     if (Data.length < Count) {
/* 1819 */       throw new IndexOutOfBoundsException((this.LangID == 1) ? "Data too small" : "Das Data ist zu klein");
/*      */     }
/* 1821 */     if (this.CurrentDeviceNo <= 0) {
/* 1822 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1824 */     if (this.UseFileLocks) {
/* 1825 */       this.nm.enter();
/*      */     }
/* 1827 */     double[] Dat = null;
/*      */     try {
/* 1829 */       Dat = this.add.getFifoDouble(FifoNo, Count);
/*      */     } finally {
/* 1831 */       if (this.UseFileLocks) {
/* 1832 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1835 */     System.arraycopy(Dat, 0, Data, 0, Count);
/* 1836 */     test_double_buffer_qnan(Data, Count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float Get_FPar(int Index) throws ADwinCommunicationError {
/* 1853 */     if (this.CurrentDeviceNo <= 0) {
/* 1854 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1856 */     if (this.UseFileLocks) {
/* 1857 */       this.nm.enter();
/*      */     }
/* 1859 */     float fpar = 0.0F;
/*      */     try {
/* 1861 */       fpar = this.add.getFPar(Index);
/*      */     } finally {
/* 1863 */       if (this.UseFileLocks) {
/* 1864 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1867 */     return test_float_buffer_qnan(fpar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double Get_FPar_Double(int Index) throws ADwinCommunicationError {
/* 1884 */     if (this.CurrentDeviceNo <= 0) {
/* 1885 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1887 */     if (this.UseFileLocks) {
/* 1888 */       this.nm.enter();
/*      */     }
/* 1890 */     double fpar = 0.0D;
/*      */     try {
/* 1892 */       fpar = this.add.getFParDouble(Index);
/*      */     } finally {
/* 1894 */       if (this.UseFileLocks) {
/* 1895 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1898 */     return test_double_buffer_qnan(fpar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_FPar(int Index, float Value) throws ADwinCommunicationError {
/* 1914 */     if (this.CurrentDeviceNo <= 0) {
/* 1915 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1917 */     if (this.UseFileLocks) {
/* 1918 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1921 */       this.add.setFPar(Index, Value);
/*      */     } finally {
/* 1923 */       if (this.UseFileLocks) {
/* 1924 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_FPar_Double(int Index, double Value) throws ADwinCommunicationError {
/* 1943 */     if (this.CurrentDeviceNo <= 0) {
/* 1944 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1946 */     if (this.UseFileLocks) {
/* 1947 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 1950 */       this.add.setFParDouble(Index, Value);
/*      */     } finally {
/* 1952 */       if (this.UseFileLocks) {
/* 1953 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Workload() throws ADwinCommunicationError {
/* 1968 */     if (this.CurrentDeviceNo <= 0) {
/* 1969 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 1971 */     if (this.UseFileLocks) {
/* 1972 */       this.nm.enter();
/*      */     }
/* 1974 */     int wl = 0;
/*      */     try {
/* 1976 */       wl = this.add.getWorkload();
/*      */     } finally {
/* 1978 */       if (this.UseFileLocks) {
/* 1979 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 1982 */     return wl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Free_Mem(int Mem_Spec) throws ADwinCommunicationError {
/* 2022 */     if (this.CurrentDeviceNo <= 0) {
/* 2023 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2025 */     if (this.UseFileLocks) {
/* 2026 */       this.nm.enter();
/*      */     }
/* 2028 */     int mem = 0;
/*      */     try {
/* 2030 */       mem = this.add.getFreeMem(Mem_Spec);
/*      */     } finally {
/* 2032 */       if (this.UseFileLocks) {
/* 2033 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2036 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Load_Process(String Filename) throws ADwinCommunicationError {
/* 2050 */     if (this.CurrentDeviceNo <= 0) {
/* 2051 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2053 */     if (this.UseFileLocks) {
/* 2054 */       this.nm.enter();
/*      */     }
/* 2056 */     if (!(new File(Filename)).isFile()) {
/* 2057 */       throw new ADwinCommunicationError("File not Found - " + Filename, "Datei nicht gefunden - " + Filename, this.LangID, 200);
/*      */     }
/*      */     try {
/* 2060 */       this.add.loadProcessFile(Filename);
/* 2061 */     } catch (FileNotFoundException fnfe) {
/* 2062 */       throw new ADwinCommunicationError("File not Found - " + Filename, "Datei nicht gefunden - " + Filename, this.LangID, 200);
/* 2063 */     } catch (IOException ioe) {
/* 2064 */       throw new ADwinCommunicationError("Error when reading " + Filename + "(" + ioe.getMessage() + ")", "Fehler beim Lesen von " + Filename + "(" + ioe
/* 2065 */           .getMessage() + ")", this.LangID, 200);
/*      */     } finally {
/*      */       
/* 2068 */       if (this.UseFileLocks) {
/* 2069 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Start_Process(int ProcessNo) throws ADwinCommunicationError {
/* 2087 */     if (this.CurrentDeviceNo <= 0) {
/* 2088 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2090 */     if (this.UseFileLocks) {
/* 2091 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2094 */       this.add.startProcess(ProcessNo);
/*      */     } finally {
/* 2096 */       if (this.UseFileLocks) {
/* 2097 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Stop_Process(int ProcessNo) throws ADwinCommunicationError {
/* 2114 */     if (this.CurrentDeviceNo <= 0) {
/* 2115 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2117 */     if (this.UseFileLocks) {
/* 2118 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2121 */       this.add.stopProcess(ProcessNo);
/*      */     } finally {
/* 2123 */       if (this.UseFileLocks) {
/* 2124 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Clear_Process(int ProcessNo) throws ADwinCommunicationError {
/* 2145 */     if (this.CurrentDeviceNo <= 0) {
/* 2146 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2148 */     if (this.UseFileLocks) {
/* 2149 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2152 */       this.add.clearProcess(ProcessNo);
/*      */     } finally {
/* 2154 */       if (this.UseFileLocks) {
/* 2155 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Process_Status(int ProcessNo) throws ADwinCommunicationError {
/* 2189 */     if (this.CurrentDeviceNo <= 0) {
/* 2190 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2192 */     if (this.UseFileLocks) {
/* 2193 */       this.nm.enter();
/*      */     }
/* 2195 */     int State = 0;
/*      */     try {
/* 2197 */       State = this.add.getProcessState(ProcessNo);
/*      */     } finally {
/* 2199 */       if (this.UseFileLocks) {
/* 2200 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2203 */     return State;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Boot(String Filename) throws ADwinCommunicationError {
/* 2221 */     if (this.CurrentDeviceNo <= 0) {
/* 2222 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*      */     
/* 2225 */     int ProcessorInt = getProcessorInt(Filename);
/* 2226 */     if (ProcessorInt == -1) {
/* 2227 */       throw new ADwinCommunicationError("Invalid BTL-File: " + Filename, "Ungültige BTL: " + Filename, this.LangID, 204);
/*      */     }
/*      */ 
/*      */     
/* 2231 */     if (this.UseFileLocks) {
/* 2232 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2235 */       this.add.bootFile(Filename, ProcessorInt);
/* 2236 */     } catch (FileNotFoundException fnfe) {
/* 2237 */       throw new ADwinCommunicationError("File " + Filename + " not found", "Datei " + Filename + " nicht gefunden", this.LangID, 200);
/*      */     }
/* 2239 */     catch (IOException ioe) {
/* 2240 */       throw new ADwinCommunicationError("Error when reading " + Filename + "(" + ioe.getMessage() + ")", "Fehler beim Lesen von " + Filename + "(" + ioe
/* 2241 */           .getMessage() + ")", this.LangID, 205);
/*      */     } finally {
/*      */       
/* 2244 */       if (this.UseFileLocks) {
/* 2245 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String GetData_String(int DataNo) throws ADwinCommunicationError {
/*      */     String str;
/* 2265 */     if (this.CurrentDeviceNo <= 0) {
/* 2266 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2268 */     if (this.UseFileLocks) {
/* 2269 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2272 */       str = this.add.getString(DataNo);
/*      */     } finally {
/* 2274 */       if (this.UseFileLocks) {
/* 2275 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2278 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int GetData_String(int DataNo, char[] Data, int MaxCount) throws ADwinCommunicationError {
/* 2297 */     if (Data.length < MaxCount) {
/* 2298 */       return 0;
/*      */     }
/* 2300 */     int n = 0;
/*      */     
/* 2302 */     if (this.CurrentDeviceNo <= 0) {
/* 2303 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2305 */     if (this.UseFileLocks) {
/* 2306 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2309 */       String str = this.add.getString(DataNo);
/* 2310 */       for (n = 0; n < MaxCount && n < str.length(); n++) {
/* 2311 */         Data[n] = str.charAt(n);
/*      */       }
/*      */     } finally {
/*      */       
/* 2315 */       if (this.UseFileLocks) {
/* 2316 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2319 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SetData_String(int DataNo, String Data) throws ADwinCommunicationError, IllegalArgumentException {
/* 2336 */     if (Data.length() == 0) {
/* 2337 */       throw new IllegalArgumentException();
/*      */     }
/* 2339 */     if (this.CurrentDeviceNo <= 0) {
/* 2340 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2342 */     if (this.UseFileLocks) {
/* 2343 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2346 */       this.add.setString(DataNo, Data);
/*      */     } finally {
/* 2348 */       if (this.UseFileLocks) {
/* 2349 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int String_Length(int DataNo) throws ADwinCommunicationError {
/*      */     int len;
/* 2368 */     if (this.CurrentDeviceNo <= 0) {
/* 2369 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2371 */     if (this.UseFileLocks) {
/* 2372 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2375 */       len = this.add.getStringLength(DataNo);
/*      */     } finally {
/* 2377 */       if (this.UseFileLocks) {
/* 2378 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2381 */     return len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_Globaldelay(int ProcessNo, int Globaldelay) throws ADwinCommunicationError {
/* 2391 */     Set_Processdelay(ProcessNo, Globaldelay);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Set_Processdelay(int ProcessNo, int Processdelay) throws ADwinCommunicationError {
/* 2408 */     if (this.CurrentDeviceNo <= 0) {
/* 2409 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2411 */     if (this.UseFileLocks) {
/* 2412 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2415 */       this.add.setGlobalDelay(ProcessNo, Processdelay);
/*      */     } finally {
/* 2417 */       if (this.UseFileLocks) {
/* 2418 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Get_Globaldelay(int ProcessNo) throws ADwinCommunicationError {
/* 2431 */     return Get_Processdelay(ProcessNo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Get_Processdelay(int ProcessNo) throws ADwinCommunicationError {
/*      */     int Globaldelay;
/* 2453 */     if (this.CurrentDeviceNo <= 0) {
/* 2454 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2456 */     if (this.UseFileLocks) {
/* 2457 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2460 */       Globaldelay = this.add.getGlobalDelay(ProcessNo);
/*      */     } finally {
/* 2462 */       if (this.UseFileLocks) {
/* 2463 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2466 */     return Globaldelay;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDebugListener(ADwinDebugListener adl) {
/* 2471 */     this.add.adl = adl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Test_Version() throws ADwinCommunicationError {
/*      */     int RetVal;
/* 2486 */     if (this.CurrentDeviceNo <= 0) {
/* 2487 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2489 */     if (this.UseFileLocks) {
/* 2490 */       this.nm.enter();
/*      */     }
/*      */     
/*      */     try {
/* 2494 */       if (this.add != null)
/*      */       
/* 2496 */       { RetVal = this.add.test_version(); }
/*      */       else
/* 2498 */       { RetVal = 3; } 
/* 2499 */     } catch (ADwinCommunicationError awce) {
/* 2500 */       RetVal = 3;
/*      */     } 
/* 2502 */     if (this.UseFileLocks) {
/* 2503 */       this.nm.leave();
/*      */     }
/* 2505 */     return RetVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void Data2File(String Filename, int DataNo, int Startindex, int Count, int Mode) throws ADwinCommunicationError {
/* 2524 */     if (this.CurrentDeviceNo <= 0) {
/* 2525 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2527 */     FileOutputStream fos = null;
/* 2528 */     if (Mode != 0 && Mode != 1) {
/* 2529 */       throw new IllegalArgumentException((this.LangID == 1) ? "Mode must be 0 or 1" : "Mode muss 0 oder 1 sein");
/*      */     }
/*      */     try {
/* 2532 */       fos = new FileOutputStream(Filename, (Mode != 0));
/* 2533 */     } catch (FileNotFoundException fnfe) {
/* 2534 */       throw new ADwinCommunicationError("File not Found (" + fnfe.getMessage() + ")", "Datei nicht gefunden (" + fnfe.getMessage() + ")", this.LangID, 200);
/*      */     } 
/*      */     
/* 2537 */     if (Count <= 0) {
/* 2538 */       throw new IllegalArgumentException((this.LangID == 1) ? "Count must be > 0" : "Count muss > 0 sein");
/*      */     }
/* 2540 */     if (this.UseFileLocks)
/* 2541 */       this.nm.enter();  try {
/*      */       float[] f; int[] i;
/*      */       byte[] b;
/* 2544 */       int n, DataType = this.add.getDataType(DataNo);
/* 2545 */       switch (DataType) {
/*      */         case 5:
/* 2547 */           f = this.add.getDataFloat(DataNo, Startindex, Startindex + Count - 1);
/* 2548 */           b = new byte[Count * 4];
/* 2549 */           for (n = 0; n < Count; n++) {
/* 2550 */             ADwinDirectDevice.setInteger(b, n * 4, Float.floatToIntBits(f[n]));
/*      */           }
/*      */           
/*      */           try {
/* 2554 */             fos.write(b, 0, Count * 4);
/* 2555 */           } catch (IOException ioe) {
/* 2556 */             throw new ADwinCommunicationError("Error when writing to file " + Filename, "Fehler beim Schreiben zur Datei " + Filename, this.LangID, 205);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/* 2562 */           i = this.add.getDataInt(DataNo, Startindex, Startindex + Count - 1);
/* 2563 */           b = new byte[Count * 4];
/* 2564 */           for (n = 0; n < Count; n++) {
/* 2565 */             ADwinDirectDevice.setInteger(b, n * 4, i[n]);
/*      */           }
/*      */           try {
/* 2568 */             fos.write(b, 0, Count * 4);
/* 2569 */           } catch (IOException ioe) {
/* 2570 */             throw new ADwinCommunicationError("Error when writing to file " + Filename, "Fehler beim Schreiben zur Datei " + Filename, this.LangID, 205);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2576 */           throw new ADwinCommunicationError("Invalid Type of Data_" + DataNo, "Data_" + DataNo + " hat einen ungültigen Typ", this.LangID, 100);
/*      */       } 
/*      */     
/*      */     } finally {
/* 2580 */       if (this.UseFileLocks) {
/* 2581 */         this.nm.leave();
/*      */       }
/*      */       try {
/* 2584 */         fos.close();
/* 2585 */       } catch (IOException ioe) {
/* 2586 */         throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe.getMessage(), this.LangID, 205);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void File2Data(String Filename, int DataType, int DataNo, int Startindex) throws ADwinCommunicationError, IllegalArgumentException {
/* 2616 */     if (this.CurrentDeviceNo <= 0) {
/* 2617 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2619 */     if (this.UseFileLocks)
/* 2620 */       this.nm.enter();  try {
/*      */       byte[] Binary; int Count; int[] iData;
/*      */       float[] fData;
/*      */       double[] dData;
/*      */       try {
/* 2625 */         FileInputStream fis = new FileInputStream(Filename);
/* 2626 */         Binary = new byte[fis.available()];
/* 2627 */         fis.read(Binary);
/* 2628 */         fis.close();
/* 2629 */         if (Binary.length == 0) {
/* 2630 */           throw new ADwinCommunicationError("The file is not valid.", "Die Datei ist ungültig.", this.LangID, 203);
/*      */         }
/* 2632 */       } catch (FileNotFoundException e) {
/* 2633 */         throw new ADwinCommunicationError("File not found.", "Datei konnte nicht gefunden werden.", this.LangID, 200);
/* 2634 */       } catch (IOException e) {
/* 2635 */         throw new ADwinCommunicationError("The file is not valid.", "Die Datei ist ungültig.", this.LangID, 203);
/*      */       } 
/*      */ 
/*      */       
/* 2639 */       switch (DataType) {
/*      */         case 3:
/* 2641 */           Count = Binary.length / 4;
/* 2642 */           iData = new int[Count];
/* 2643 */           this.add.convert_data_from_stream_to_int(Binary, iData, Count);
/* 2644 */           this.add.setDataInt(DataNo, iData, 1, Count);
/*      */           break;
/*      */         case 5:
/* 2647 */           Count = Binary.length / 4;
/* 2648 */           fData = new float[Count];
/* 2649 */           this.add.convert_data_from_stream_to_float(Binary, fData, Count);
/* 2650 */           this.add.setDataFloat(DataNo, fData, 1, Count);
/*      */           break;
/*      */         case 6:
/* 2653 */           Count = Binary.length / 8;
/* 2654 */           dData = new double[Count];
/* 2655 */           this.add.convert_data_from_stream_to_double(Binary, dData, Count);
/* 2656 */           this.add.setDataDouble(DataNo, dData, 1, Count);
/*      */           break;
/*      */         default:
/* 2659 */           throw new IllegalArgumentException((this.LangID == 2) ? "Als DataType 3, 5 oder 6 angeben!" : "DataType must be 3, 5 or 6!");
/*      */       } 
/*      */     } finally {
/* 2662 */       if (this.UseFileLocks) {
/* 2663 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int Data_Type(int DataNo) throws ADwinCommunicationError {
/* 2677 */     if (this.CurrentDeviceNo <= 0) {
/* 2678 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2680 */     if (this.UseFileLocks) {
/* 2681 */       this.nm.enter();
/*      */     }
/* 2683 */     int dtype = 0;
/*      */     try {
/* 2685 */       dtype = this.add.getDataType(DataNo);
/*      */     } finally {
/* 2687 */       if (this.UseFileLocks) {
/* 2688 */         this.nm.leave();
/*      */       }
/*      */     } 
/* 2691 */     return dtype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ADwinDevice Get_Copy() {
/* 2703 */     ADwinDevice a = new ADwinDevice();
/* 2704 */     a.Set_Language(this.LangID);
/*      */     try {
/* 2706 */       a.Use_FileLocks(this.UseFileLocks);
/* 2707 */     } catch (ADwinCommunicationError ace) {
/*      */ 
/*      */ 
/*      */       
/* 2711 */       System.out.println(ace.getMessage());
/*      */     } 
/* 2713 */     return a;
/*      */   }
/*      */ 
/*      */   
/*      */   private int getProcessorInt(String Filename) {
/* 2718 */     int ProcessorInt = -1;
/* 2719 */     String btl = Filename.toLowerCase();
/* 2720 */     if (btl.endsWith("adwin121.btl")) {
/* 2721 */       return 9;
/*      */     }
/*      */     
/* 2724 */     char ProcessorChar = btl.charAt(Filename.length() - 5);
/* 2725 */     if (ProcessorChar >= '0' && ProcessorChar <= '9') {
/* 2726 */       ProcessorInt = ProcessorChar - 48;
/*      */     }
/* 2728 */     return ProcessorInt;
/*      */   }
/*      */ 
/*      */   
/*      */   public void Boot(byte[] File, String Filename) throws ADwinCommunicationError, IOException {
/* 2733 */     if (this.CurrentDeviceNo <= 0) {
/* 2734 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/*      */     
/* 2737 */     int ProcessorInt = getProcessorInt(Filename);
/* 2738 */     if (ProcessorInt == -1) {
/* 2739 */       this.nm.leave();
/* 2740 */       throw new ADwinCommunicationError("Invalid BTL-File: " + Filename, "Ungültige BTL: " + Filename, this.LangID, 204);
/*      */     } 
/*      */ 
/*      */     
/* 2744 */     if (this.UseFileLocks) {
/* 2745 */       this.nm.enter();
/*      */     }
/*      */     
/* 2748 */     try { if (Filename.toLowerCase().endsWith("121.btl")) {
/* 2749 */         this.add.bootArrayADwinX(File, Filename, ProcessorInt);
/*      */       } else {
/* 2751 */         this.add.bootArray(File, Filename, ProcessorInt);
/*      */       }  }
/* 2753 */     finally { if (this.UseFileLocks) {
/* 2754 */         this.nm.leave();
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void Load_Process(byte[] file, String fileName) throws ADwinCommunicationError {
/* 2761 */     if (this.CurrentDeviceNo <= 0) {
/* 2762 */       throw new ADwinCommunicationError("No device set yet", "Noch keine Device-Nummer gesetzt", this.LangID, 0);
/*      */     }
/* 2764 */     if (this.UseFileLocks) {
/* 2765 */       this.nm.enter();
/*      */     }
/*      */     try {
/* 2768 */       this.add.loadProcessArray(file, fileName);
/* 2769 */     } catch (IOException ioe) {
/* 2770 */       throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe.getMessage(), this.LangID, 2000);
/*      */     } finally {
/* 2772 */       if (this.UseFileLocks) {
/* 2773 */         this.nm.leave();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void Boot(URL btl) throws ADwinCommunicationError, IOException {
/* 2780 */     Boot(loadURL(btl), btl.toString());
/*      */   }
/*      */ 
/*      */   
/*      */   public void Load_Process(URL process) throws ADwinCommunicationError {
/* 2785 */     Load_Process(loadURL(process), process.toString());
/*      */   }
/*      */   private byte[] loadURL(URL url) throws ADwinCommunicationError {
/*      */     try {
/*      */       int bytesReadThisTime;
/* 2790 */       InputStream is = url.openStream();
/* 2791 */       byte[] resource = new byte[is.available()];
/* 2792 */       int bytesRead = 0;
/*      */       
/*      */       do {
/* 2795 */         bytesReadThisTime = is.read(resource, bytesRead, resource.length - bytesRead);
/* 2796 */         bytesRead += bytesReadThisTime;
/* 2797 */       } while (bytesReadThisTime > 0);
/*      */       
/* 2799 */       is.close();
/* 2800 */       return resource;
/* 2801 */     } catch (IOException ioe) {
/* 2802 */       throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe.getMessage(), this.LangID, 200);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SanitizeFloatingPointValues(int flag) {
/* 2812 */     if (flag == 1) {
/* 2813 */       this.NAN_test = 1;
/*      */     } else {
/* 2815 */       this.NAN_test = 0;
/*      */     } 
/*      */   }
/*      */   float test_float_buffer_qnan(float value) {
/* 2819 */     if (this.NAN_test == 0)
/* 2820 */       return value; 
/* 2821 */     if (value == Float.NEGATIVE_INFINITY)
/* 2822 */       return Float.MIN_VALUE; 
/* 2823 */     if (Float.isNaN(value) || Float.isInfinite(value))
/* 2824 */       return Float.MAX_VALUE; 
/* 2825 */     return value;
/*      */   }
/*      */   
/*      */   void test_float_buffer_qnan(float[] values, int count) {
/* 2829 */     if (this.NAN_test == 0)
/* 2830 */       return;  for (int i = 0; i < count; i++) {
/* 2831 */       if (Float.isNaN(values[i]))
/* 2832 */         values[i] = Float.MAX_VALUE; 
/* 2833 */       if (values[i] == Float.NEGATIVE_INFINITY)
/* 2834 */         values[i] = Float.MIN_VALUE; 
/* 2835 */       if (Float.isNaN(values[i]) || Float.isInfinite(values[i]))
/* 2836 */         values[i] = Float.MAX_VALUE; 
/*      */     } 
/*      */   }
/*      */   
/*      */   double test_double_buffer_qnan(double value) {
/* 2841 */     if (this.NAN_test == 0)
/* 2842 */       return value; 
/* 2843 */     if (value == Double.NEGATIVE_INFINITY)
/* 2844 */       return Double.MIN_VALUE; 
/* 2845 */     if (Double.isNaN(value) || Double.isInfinite(value))
/* 2846 */       return Double.MAX_VALUE; 
/* 2847 */     return value;
/*      */   }
/*      */   
/*      */   void test_double_buffer_qnan(double[] values, int count) {
/* 2851 */     if (this.NAN_test == 0)
/* 2852 */       return;  for (int i = 0; i < count; i++) {
/* 2853 */       if (Double.isNaN(values[i]))
/* 2854 */         values[i] = Double.MAX_VALUE; 
/* 2855 */       if (values[i] == Double.NEGATIVE_INFINITY)
/* 2856 */         values[i] = Double.MIN_VALUE; 
/* 2857 */       if (Double.isNaN(values[i]) || Double.isInfinite(values[i]))
/* 2858 */         values[i] = Double.MAX_VALUE; 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */