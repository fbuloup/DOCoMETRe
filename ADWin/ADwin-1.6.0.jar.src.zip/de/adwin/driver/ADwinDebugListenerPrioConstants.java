package de.adwin.driver;

public interface ADwinDebugListenerPrioConstants {
  public static final int PRIO_ERROR_INFO = 1;
  
  public static final int PRIO_INFO = 100;
  
  public static final int PRIO_SPEC_PACKETS = 50;
}


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinDebugListenerPrioConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */