/*      */ package de.adwin.driver;
/*      */ 
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.InterfaceAddress;
/*      */ import java.net.NetworkInterface;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ class ADwinDirectDevice
/*      */   implements ADwinDebugListenerPrioConstants
/*      */ {
/*   28 */   private final int k_3plus1 = 0;
/*   29 */   private final int k_GetPar = 1;
/*   30 */   private final int k_Start = 2;
/*      */   
/*   32 */   private final int k_Stop = 3;
/*   33 */   private final int k_lMemory = 5;
/*   34 */   private final int k_SetPar = 6;
/*   35 */   private final int k_Clear_Data = 9;
/*   36 */   private final int k_GetDataLength = 11;
/*   37 */   private final int k_MemoryAll = 12;
/*   38 */   private final int k_ClearProcess = 14;
/*   39 */   private final int k_ADC = 15;
/*   40 */   private final int k_DAC = 16;
/*   41 */   private final int k_GetDigin = 17;
/*   42 */   private final int k_SetDigout = 18;
/*   43 */   private final int k_GetDigout = 19;
/*   44 */   private final int k_Auslastung = 20;
/*   45 */   private final int k_ClearFifo = 21;
/*   46 */   private final int k_GetFifoEmpty = 22;
/*   47 */   private final int k_GetFifoCount = 23;
/*   48 */   private final int k_LadeBin = 4;
/*   49 */   private final int k_GetDataStringSize = 44;
/*   50 */   private final int k_GetDataInfo = 45;
/*   51 */   private final int k_GetDataType = 100;
/*   52 */   private final int k_GetData = 7;
/*   53 */   private final int k_GetDataShiftedHandshake = 107;
/*   54 */   private final int k_GetDatasmall = 207;
/*   55 */   private final int k_SetData = 8;
/*   56 */   private final int k_SetDataLastStatus = 108;
/*   57 */   private final int k_CreateData = 10;
/*   58 */   private final int k_GetParAll = 13;
/*   59 */   private final int k_GetFifo = 24;
/*   60 */   private final int k_GetFifoRetry = 124;
/*   61 */   private final int k_SetFifo = 25;
/*   62 */   private final int k_SetFifoRetry = 125;
/*   63 */   private final int k_Boot = 50;
/*   64 */   private final int k_ARMVersion = 1000;
/*   65 */   private final int k_TestVersion = 255;
/*   66 */   private final int k_Authenticate = 300;
/*   67 */   private final int k_GetMemoryDSP = 1000000;
/*      */ 
/*      */   
/*   70 */   private final int k_ok = 0;
/*   71 */   private final int k_Data_is_to_small = 100;
/*   72 */   private final int k_Fifo_is_to_small = 101;
/*   73 */   private final int k_Fifo_to_less_data = 102;
/*   74 */   private final int k_Mem_Error = 150;
/*   75 */   private final int k_File_not_found = 200;
/*   76 */   private final int k_File_not_binaer = 202;
/*   77 */   private final int k_File_not_valid = 203;
/*   78 */   private final int k_File_not_btl = 204;
/*   79 */   private final int k_WrongBinFile = 205;
/*   80 */   private final int k_error_tcp_error = 2000;
/*   81 */   private final int k_error_tcp_timout_read = 2001;
/*   82 */   private final int k_error_tcp_password = 2002;
/*      */   
/*   84 */   private final int VAL_GET_PAR = 1;
/*   85 */   private final int CMD_GET_VERSION = 255;
/*   86 */   private final int CMD_GET_DATA_TYPE = 100;
/*   87 */   private final int CMD_VAL_GET_DATA = 7;
/*   88 */   private final int VAL_GET_DATA_LENGTH = 11;
/*   89 */   private final int CMD_GET_DATA_SMALL = 207;
/*   90 */   private final int CMD_LOAD_BINARY = 4;
/*   91 */   private final int VAL_START = 2;
/*   92 */   private final int VAL_STOP = 3;
/*   93 */   private final int CMD_BOOT = 50;
/*   94 */   private final int CMD_SET_DATA = 8;
/*   95 */   private final int VAL_SET_PAR = 6;
/*      */ 
/*      */   
/*   98 */   private final int CMD_SET_FIFO = 25;
/*   99 */   private final int CMD_SET_FIFO_RETRY = 125;
/*  100 */   private final int CMD_VAL_WORKLOAD = 20;
/*  101 */   private final int VAL_MEMORY = 5;
/*  102 */   private final int VAL_MEMORY_ALL = 12;
/*  103 */   private final int VAL_CLEAR_PROCESS = 14;
/*  104 */   private final int CMD_GET_PAR_BLOCK = 13;
/*  105 */   private final int VAL_GET_FIFO_FREE = 22;
/*  106 */   private final int VAL_GET_FIFO_COUNT = 23;
/*  107 */   private final int VAL_CLEAR_FIFO = 21;
/*  108 */   private final int CMD_VAL_ARMVERSION = 1000;
/*  109 */   private final int CMD_SETDATA_STATUS = 108;
/*  110 */   private final int CMD_GET_DATA_SH = 107;
/*      */   
/*  112 */   private final int CMD_AUTHENTICATE = 300;
/*      */   
/*      */   private final DatagramSocket ds;
/*      */   
/*  116 */   private volatile int currentPacketIndex = 1;
/*      */   
/*      */   private final InetAddress Connection;
/*      */   
/*      */   final String Password;
/*      */   
/*      */   static final int DATATYPE_BYTE = 1;
/*      */   
/*      */   static final int DATATYPE_SHORT = 2;
/*      */   
/*      */   static final int DATATYPE_INT = 3;
/*      */   
/*      */   static final int DATATYPE_LONG = 4;
/*      */   
/*      */   static final int DATATYPE_FLOAT = 5;
/*      */   static final int DATATYPE_DOUBLE = 6;
/*      */   static final int DATATYPE_INT64 = 7;
/*      */   static final int DATATYPE_STRING = 8;
/*      */   static final int DATATYPE_PACKED_INT = 2;
/*      */   static final int GETDATASH_MIN_REQ = 6;
/*      */   static final int GETDATASH_MAX_REQ = 30;
/*      */   static final int GETDATASH_QUEUE_SIZE = 40;
/*      */   final int AllowedErrors;
/*      */   int MaxPacketDelay;
/*      */   final int DataBlockSize;
/*      */   int ADwTimeout;
/*      */   final int NumWaits;
/*      */   final int WaitTime;
/*      */   final int Hostlink;
/*      */   final int Port;
/*  146 */   final int PROCESSOR_T8 = 8;
/*  147 */   final int PROCESSOR_T9 = 9;
/*  148 */   final int PROCESSOR_T10 = 1010;
/*  149 */   final int PROCESSOR_T11 = 1011;
/*  150 */   final int PROCESSOR_T12 = 1012;
/*      */   
/*  152 */   ADwinDebugListener adl = null;
/*  153 */   int Language = 1;
/*      */   
/*      */   volatile int version;
/*      */   
/*  157 */   final int DLLVersion = 3000447;
/*      */ 
/*      */   
/*      */   public class myVARIANT
/*      */   {
/*      */     public short typ;
/*      */     
/*      */     public int idummy;
/*      */     
/*      */     public short sdummy;
/*      */     public long val;
/*      */   }
/*  169 */   final int MY_VARIANT_EMPTY = 0;
/*  170 */   final int MY_VARIANT_NULL = 1;
/*  171 */   final int MY_VARIANT_INT16 = 2;
/*  172 */   final int MY_VARIANT_INT32 = 3;
/*  173 */   final int MY_VARIANT_FLOAT = 4;
/*  174 */   final int MY_VARIANT_DOUBLE = 5;
/*      */   
/*  176 */   final int SMALL_REQ_SIZE = 10240;
/*  177 */   final int ADWIN_TCP_MAGIC_FLAG_REQUEST = 1118650900;
/*  178 */   final int ADWIN_TCP_MAGIC_FLAG_RESPONSE = 1118650963;
/*  179 */   final int ADWIN_HTONL = 1;
/*  180 */   final int ADWIN_NTOHL = 2;
/*      */   
/*      */   enum adwin_data_type_t {
/*  183 */     ADWIN_DATA_TYPE_INVALID,
/*  184 */     ADWIN_BYTE,
/*  185 */     ADWIN_SHORT,
/*  186 */     ADWIN_LONG,
/*  187 */     ADWIN_INTEGER,
/*  188 */     ADWIN_FLOAT,
/*  189 */     ADWIN_DOUBLE,
/*  190 */     ADWIN_INT64,
/*  191 */     ADWIN_STRING,
/*  192 */     ADWIN_VARIANT;
/*      */   }
/*      */ 
/*      */   
/*      */   public class adwin_tcp_header_t
/*      */   {
/*      */     public int magic_flag;
/*      */     
/*      */     public int req_count;
/*      */     
/*      */     public int length;
/*      */     
/*      */     public int command_or_status;
/*      */   }
/*      */ 
/*      */   
/*      */   public class adwin_tcp_buffer_t
/*      */   {
/*      */     public int max;
/*      */     
/*      */     public int used;
/*      */     
/*      */     public int do_convert;
/*      */     
/*      */     public byte[] data;
/*      */     public boolean as_char;
/*      */   }
/*      */   
/*      */   public class adwin_tcp_info_t
/*      */   {
/*      */     public InetAddress server_addr;
/*      */     public int firmware_version;
/*      */     public int firmware_version_beta;
/*      */     public int error_number;
/*      */     public int processortype;
/*      */     public boolean connected;
/*      */     public boolean initialized;
/*      */     public Socket socket;
/*      */     public int timeout_ms;
/*      */     public int timeout_size;
/*      */     public int dll_version;
/*      */     public int req_count;
/*      */     public int command;
/*      */     public int status;
/*      */     public ADwinDirectDevice.adwin_tcp_buffer_t req;
/*      */     public int rx_pending;
/*      */     public ADwinDirectDevice.adwin_tcp_buffer_t resp;
/*      */     InputStream stream_in;
/*      */     OutputStream stream_out;
/*      */   }
/*      */   volatile boolean supports_tcp = false;
/*      */   volatile boolean supports_udp = true;
/*      */   static final int ADWIN_TCP_OK = 0;
/*      */   static final int ADWIN_TCP_ERROR = 1;
/*      */   static final int ADWIN_UDP = 2;
/*  247 */   Date last_access = new Date(0L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   volatile adwin_tcp_info_t ati;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ADwinDirectDevice(InetAddress address, int port, String password, int allowedErrors, int maxPacketDelay, int dataBlockSize, int adwinTimeout, int maxTryLater, int tryLaterWaitTime, int hostlink) throws SocketException, ADwinCommunicationError {
/*  265 */     this.Connection = address;
/*  266 */     this.Port = port;
/*  267 */     this.Password = password;
/*  268 */     this.AllowedErrors = allowedErrors;
/*  269 */     this.MaxPacketDelay = maxPacketDelay;
/*  270 */     this.DataBlockSize = dataBlockSize;
/*  271 */     this.ADwTimeout = adwinTimeout;
/*  272 */     this.NumWaits = maxTryLater;
/*  273 */     this.WaitTime = tryLaterWaitTime;
/*  274 */     this.Hostlink = hostlink;
/*  275 */     this.ds = new DatagramSocket(0);
/*      */     
/*  277 */     this.ds.setReceiveBufferSize(140000);
/*      */     
/*  279 */     adwin_tcp_construct();
/*      */ 
/*      */     
/*      */     try {
/*  283 */       this.version = getArmVersion();
/*  284 */     } catch (Exception e) {
/*  285 */       this.version = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean newTryLater() {
/*  296 */     int versionLocal = this.version;
/*  297 */     return ((versionLocal >= 252 && versionLocal <= 259) || versionLocal >= 264);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int incGetCurrentIndex() {
/*  309 */     if (this.adl != null) {
/*  310 */       this.adl.enter("incCurrentIndex");
/*      */     }
/*      */     
/*  313 */     int result = this.currentPacketIndex;
/*  314 */     this.currentPacketIndex++;
/*  315 */     if (this.currentPacketIndex > 2147483646) {
/*  316 */       if (this.adl != null) {
/*  317 */         this.adl.message("Wrapping Packet-Index around...", 100);
/*      */       }
/*  319 */       this.currentPacketIndex = 1;
/*      */     } 
/*      */     
/*  322 */     if (this.adl != null) {
/*  323 */       this.adl.leave();
/*      */     }
/*  325 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readAEIVersionIfUnknown() throws ADwinCommunicationError {
/*  335 */     if (this.version == 0) {
/*  336 */       synchronized (this.ds) {
/*  337 */         if (this.version == 0) {
/*  338 */           this.version = getArmVersion();
/*      */         }
/*      */       } 
/*      */     }
/*  342 */     return this.version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendCommand(ADwinCommand adwc, int Index) throws ADwinCommunicationError {
/*  357 */     if (this.adl != null) {
/*  358 */       this.adl.enter("sendCommand ( ADwinCommand: " + adwc.getCommand() + ", " + Index + ")");
/*      */     }
/*      */     
/*  361 */     adwc.setPacketIndex(Index);
/*  362 */     adwc.setLink(this.Hostlink);
/*      */ 
/*      */     
/*      */     try {
/*  366 */       DatagramPacket d = adwc.getDatagram(this.Connection);
/*  367 */       this.ds.send(d);
/*  368 */     } catch (IOException ioe) {
/*  369 */       if (this.adl != null) {
/*  370 */         this.adl.message("IOException -> ADwinCommunicationError in sendCommand", 100);
/*  371 */         this.adl.leave();
/*      */       } 
/*  373 */       throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe.getMessage(), this.Language, 2000);
/*      */     } 
/*      */     
/*  376 */     if (this.adl != null) {
/*  377 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DatagramPacket sendAndWaitForAnswer32Byte(ADwinCommand adwc, int[] sentIndex) throws ADwinCommunicationError, SocketTimeoutException {
/*  402 */     if (this.adl != null) {
/*  403 */       this.adl.enter("sendAndWaitForAnswer32Byte ( Command: " + adwc.getCommand() + ")");
/*      */     }
/*  405 */     int ResultPacketIndex = 0;
/*  406 */     int SocketTimeouts = 0;
/*  407 */     boolean timeoutOccured = false;
/*  408 */     byte[] PacketData = new byte[32];
/*  409 */     for (int n = 0; n < 32; n++) {
/*  410 */       PacketData[n] = 0;
/*      */     }
/*  412 */     DatagramPacket dp = new DatagramPacket(PacketData, 32);
/*  413 */     int TryLatersLeft = this.NumWaits;
/*  414 */     boolean TryLater = false;
/*      */ 
/*      */     
/*  417 */     synchronized (this.ds) {
/*      */       boolean InvalidPacketIndex; do {
/*  419 */         if (timeoutOccured && !TryLater && 
/*  420 */           this.adl != null) {
/*  421 */           this.adl.sendAgain(ResultPacketIndex, 0, adwc.getCommand());
/*      */         }
/*      */ 
/*      */         
/*  425 */         ResultPacketIndex = incGetCurrentIndex();
/*  426 */         sendCommand(adwc, ResultPacketIndex);
/*      */         
/*  428 */         InvalidPacketIndex = false;
/*  429 */         timeoutOccured = false;
/*  430 */         TryLater = false;
/*      */         try {
/*  432 */           this.ds.setSoTimeout(this.MaxPacketDelay);
/*  433 */           while (extractInt(PacketData, 4) != ResultPacketIndex && !TryLater) {
/*  434 */             this.ds.receive(dp);
/*  435 */             int status = extractInt(PacketData, 0);
/*  436 */             int packetIndexReceived = extractInt(PacketData, 4);
/*  437 */             if (this.adl != null) {
/*  438 */               if (status == -10) {
/*  439 */                 this.adl.tryLater(ResultPacketIndex, this.NumWaits - TryLatersLeft);
/*  440 */               } else if (packetIndexReceived != ResultPacketIndex) {
/*  441 */                 this.adl.recvAgain(ResultPacketIndex, packetIndexReceived, adwc.getCommand());
/*      */               } 
/*      */             }
/*  444 */             if (status == -10 && (!newTryLater() || packetIndexReceived == ResultPacketIndex)) {
/*  445 */               if (this.adl != null) {
/*  446 */                 this.adl.tryLater(packetIndexReceived, this.NumWaits - TryLatersLeft);
/*      */               }
/*  448 */               TryLater = true;
/*  449 */               TryLatersLeft--;
/*      */               try {
/*  451 */                 Thread.sleep(this.WaitTime);
/*  452 */               } catch (InterruptedException interruptedException) {}
/*      */               continue;
/*      */             } 
/*  455 */             if (packetIndexReceived != ResultPacketIndex) {
/*  456 */               if (this.adl != null) {
/*  457 */                 this.adl.message("Erwarteter Paket-Index: " + ResultPacketIndex + ", erhaltener P.-I.: " + extractInt(PacketData, 4), 50);
/*      */               }
/*      */               
/*  460 */               InvalidPacketIndex = true; continue;
/*  461 */             }  if (status == 5)
/*      */             {
/*  463 */               if (this.adl != null) {
/*  464 */                 this.adl.message("Fehler 5 aufgetreten, wird behandelt wie Socket-Timeout", 50);
/*      */               }
/*      */               
/*  467 */               timeoutOccured = true;
/*      */             }
/*      */           
/*      */           } 
/*  471 */         } catch (SocketTimeoutException ste) {
/*  472 */           if (SocketTimeouts > this.AllowedErrors) {
/*      */             
/*  474 */             if (this.adl != null) {
/*  475 */               this.adl.message("SocketTimeoutException", 1);
/*  476 */               this.adl.leave();
/*      */             } 
/*  478 */             throw ste;
/*      */           } 
/*  480 */           if (this.adl != null) {
/*  481 */             this.adl.message("Nichts empfangen....", 50);
/*      */           }
/*  483 */           timeoutOccured = true;
/*  484 */           SocketTimeouts++;
/*      */         }
/*  486 */         catch (IOException ioe) {
/*  487 */           if (this.adl != null) {
/*  488 */             this.adl.message("I/O-Error: " + ioe.getMessage(), 1);
/*  489 */             this.adl.leave();
/*      */           } 
/*  491 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/*  492 */               .getMessage(), this.Language, 2000);
/*      */         } 
/*  494 */       } while ((timeoutOccured || TryLater) && TryLatersLeft > 0 && !InvalidPacketIndex);
/*      */     } 
/*      */     
/*  497 */     if (TryLatersLeft <= 0) {
/*  498 */       throw new ADwinCommunicationError("Too many Try-Later Packets received", "Zu viele Try-Later-Pakete empfangen", this.Language, 16);
/*      */     }
/*      */ 
/*      */     
/*  502 */     if (this.adl != null) {
/*  503 */       this.adl.leave();
/*      */     }
/*  505 */     if (sentIndex != null) {
/*  506 */       sentIndex[0] = ResultPacketIndex;
/*      */     }
/*  508 */     return dp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DatagramPacket getVersionInfo() throws ADwinCommunicationError {
/*      */     DatagramPacket dp;
/*  525 */     if (this.adl != null) {
/*  526 */       this.adl.enter("getVersionInfo ()");
/*      */     }
/*  528 */     int[] Values = { 0, 0, 0, 0 };
/*      */     
/*  530 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/*  531 */     adwc.setCommand(255);
/*  532 */     adwc.setTimeout(this.ADwTimeout);
/*  533 */     adwc.setValues(Values);
/*  534 */     adwc.setPwd(this.Password);
/*      */ 
/*      */     
/*      */     try {
/*  538 */       dp = sendAndWaitForAnswer32Byte(adwc, null);
/*  539 */     } catch (SocketTimeoutException ste) {
/*  540 */       if (this.adl != null) {
/*  541 */         this.adl.message("SocketTimeoutException->ADwinCommunicationError in getVersionInfo ()", 1);
/*      */         
/*  543 */         this.adl.leave();
/*      */       } 
/*  545 */       throw new ADwinCommunicationError("No Answer on request for version info, " + ste.getMessage(), "Keine Antwort auf die Frage nach der Versions-Info, " + ste
/*  546 */           .getMessage(), this.Language, 2001);
/*      */     } 
/*      */ 
/*      */     
/*  550 */     if (this.adl != null) {
/*  551 */       this.adl.leave();
/*      */     }
/*  553 */     return dp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void setInteger(byte[] Buffer, int Index, int Value) {
/*  566 */     for (int n = 0; n < 4; n++) {
/*  567 */       Buffer[n + Index] = (byte)(Value << (3 - n) * 8 >>> 24);
/*      */     }
/*      */   }
/*      */   
/*      */   static void setLong(byte[] Buffer, int Index, long Value) {
/*  572 */     for (int n = 0; n < 8; n++) {
/*  573 */       Buffer[n + Index] = (byte)(int)(Value << (7 - n) * 8 >>> 56L);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int extractInt(byte[] b, int IndexFrom) {
/*  587 */     return (b[IndexFrom] & 0xFF) + (b[IndexFrom + 1] << 8 & 0xFF00) + (b[IndexFrom + 2] << 16 & 0xFF0000) + (b[IndexFrom + 3] << 24 & 0xFF000000);
/*      */   }
/*      */ 
/*      */   
/*      */   public static long extractLong(byte[] b, int IndexFrom) {
/*  592 */     long result = 0L;
/*  593 */     for (int i = 0; i < 8; i++) {
/*  594 */       result <<= 8L;
/*  595 */       result |= (b[IndexFrom + i] & 0xFF);
/*      */     } 
/*  597 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int reverseByteOrder(int i) {
/*  610 */     int res = 0;
/*      */     
/*  612 */     for (int n = 0; n < 4; n++) {
/*  613 */       byte b = (byte)(i >>> 8 * (3 - n));
/*  614 */       res |= b << n * 8 & 255 << n * 8;
/*      */     } 
/*  616 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataToArrayConverter getDataFast(int DataNr, int IndexFirst, int IndexLast, int DataType) throws ADwinCommunicationError {
/*      */     DataToByteArray dataToByteArray;
/*      */     DataToArrayConverter dtac;
/*  639 */     if (this.adl != null) {
/*  640 */       this.adl.enter("getDataFast (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ", " + DataType + ")");
/*      */     }
/*      */ 
/*      */     
/*  644 */     int OrigIndexFirst = IndexFirst;
/*  645 */     int[] Values = new int[4];
/*  646 */     Values[0] = DataType;
/*  647 */     Values[1] = DataNr + (IndexLast - IndexFirst + 1 << 16);
/*  648 */     Values[2] = IndexFirst;
/*  649 */     Values[3] = IndexLast - IndexFirst + 1;
/*  650 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/*  651 */     adwc.setValues(Values);
/*  652 */     adwc.setCommand(207);
/*  653 */     adwc.setPwd(this.Password);
/*      */     
/*  655 */     int ErrorCode = -10;
/*  656 */     DataFieldTransfer dtfa = new DataFieldTransfer(this.Connection, this.ds, this);
/*  657 */     int[] NumWordsReceived = new int[1];
/*      */     
/*  659 */     switch (DataType) {
/*      */       case 1:
/*  661 */         dataToByteArray = new DataToByteArray(IndexLast - IndexFirst + 1, 0);
/*      */       case 2:
/*  663 */         dtac = new DataToIntArray((IndexLast - IndexFirst + 1) / 2 + 1, 0);
/*      */         break;
/*      */       case 5:
/*  666 */         dtac = new DataToFloatArray(IndexLast - IndexFirst + 1, 0);
/*      */         break;
/*      */       default:
/*  669 */         dtac = new DataToIntArray(IndexLast - IndexFirst + 1, 0);
/*      */         break;
/*      */     } 
/*      */     
/*  673 */     synchronized (this.ds) {
/*  674 */       for (int n = 0; n < this.NumWaits && ErrorCode == -10; n++) {
/*  675 */         int ResultPacketIndex = incGetCurrentIndex();
/*  676 */         sendCommand(adwc, ResultPacketIndex);
/*  677 */         ErrorCode = dtfa.receiveFast(IndexLast - IndexFirst + 1, dtac, IndexFirst - OrigIndexFirst, ResultPacketIndex, NumWordsReceived);
/*      */         
/*  679 */         if (NumWordsReceived[0] < IndexLast - IndexFirst + 1) {
/*  680 */           if (ErrorCode == -10) {
/*  681 */             if (this.adl != null) {
/*  682 */               this.adl.tryLater(0, ResultPacketIndex);
/*      */             }
/*      */             try {
/*  685 */               Thread.sleep(this.WaitTime);
/*  686 */             } catch (InterruptedException interruptedException) {}
/*      */           }
/*  688 */           else if (ErrorCode != 0) {
/*  689 */             if (ErrorCode == -5) {
/*  690 */               throw new ADwinCommunicationError("Wrong Password", "Falsches Passwort", this.Language, 2002);
/*      */             }
/*  692 */             if (ErrorCode == 1) {
/*  693 */               throw new ADwinCommunicationError("timeout to link", "Timeout beim Schreiben zum Link", this.Language, 1);
/*      */             }
/*  695 */             if (ErrorCode == 2) {
/*  696 */               throw new ADwinCommunicationError("timeout from link", "Timeout beim Lesen vom Link", this.Language, 2);
/*      */             }
/*  698 */             throw new ADwinCommunicationError("Error on ADwin System: " + ErrorCode, "Fehler " + ErrorCode + " auf dem ADwin-System", this.Language, 
/*      */                 
/*  700 */                 (ErrorCode > 0) ? ErrorCode : 2000);
/*      */           } 
/*  702 */           IndexFirst += NumWordsReceived[0];
/*  703 */           Values[2] = IndexFirst;
/*  704 */           Values[3] = IndexLast - IndexFirst + 1;
/*  705 */           Values[1] = DataNr + (IndexLast - IndexFirst + 1 << 16);
/*  706 */           adwc.setValues(Values);
/*  707 */           ErrorCode = -10;
/*  708 */           if (NumWordsReceived[0] > 0) {
/*  709 */             n = 0;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  714 */     if (ErrorCode != 0) {
/*  715 */       if (this.adl != null) {
/*  716 */         this.adl.message("Error Code " + ErrorCode + " -> ADwinCommunicationError in getDataFast...", 1);
/*      */       }
/*      */       
/*  719 */       if (this.adl != null) {
/*  720 */         this.adl.leave();
/*      */       }
/*  722 */       if (ErrorCode == -5) {
/*  723 */         throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */       }
/*  725 */       if (ErrorCode == -31) {
/*  726 */         throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */       }
/*  728 */       throw new ADwinCommunicationError("Unable to load DATA_" + DataNr + " (fast method)", "Kann DATA_" + DataNr + " nicht mit schneller Methode lesen", this.Language, 
/*      */           
/*  730 */           (ErrorCode == -10) ? 16 : 2000);
/*      */     } 
/*      */     
/*  733 */     if (this.adl != null) {
/*  734 */       this.adl.leave();
/*      */     }
/*  736 */     return dtac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataToArrayConverter getDataFastADwinX(int DataNr, int IndexFirst, int IndexLast, int DataType) throws ADwinCommunicationError {
/*      */     DataToArrayConverter dtac;
/*  761 */     if (this.adl != null) {
/*  762 */       this.adl.enter("getDataFastADwinX (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ", )");
/*      */     }
/*  764 */     int count = IndexLast - IndexFirst + 1;
/*  765 */     int bytes_per_value = BytesPerValue(DataType);
/*  766 */     int byte_count = count * bytes_per_value;
/*      */ 
/*      */     
/*  769 */     int OrigIndexFirst = IndexFirst;
/*  770 */     int[] Values = new int[4];
/*  771 */     Values[0] = 0;
/*  772 */     Values[1] = DataNr + (count << 16);
/*  773 */     Values[2] = IndexFirst;
/*  774 */     Values[3] = count;
/*  775 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/*  776 */     adwc.setValues(Values);
/*  777 */     adwc.setCommand(207);
/*  778 */     adwc.setPwd(this.Password);
/*      */     
/*  780 */     int ErrorCode = -10;
/*  781 */     DataFieldTransfer dtfa = new DataFieldTransfer(this.Connection, this.ds, this);
/*  782 */     int[] NumWordsReceived = new int[1];
/*      */     
/*  784 */     switch (DataType) {
/*      */ 
/*      */       
/*      */       case 8:
/*  788 */         dtac = new DataToByteArray(count, 0);
/*      */         break;
/*      */       case 5:
/*  791 */         dtac = new DataToFloatArray(count, 0);
/*      */         break;
/*      */       case 6:
/*  794 */         dtac = new DataToDoubleArray(count, 0);
/*      */         break;
/*      */       case 7:
/*  797 */         dtac = new DataToInt64Array(count, 0);
/*      */         break;
/*      */       default:
/*  800 */         dtac = new DataToIntArray(count, 0);
/*      */         break;
/*      */     } 
/*  803 */     synchronized (this.ds) {
/*  804 */       for (int n = 0; n < this.NumWaits && ErrorCode == -10; n++) {
/*  805 */         int ResultPacketIndex = incGetCurrentIndex();
/*  806 */         sendCommand(adwc, ResultPacketIndex);
/*      */         
/*  808 */         ErrorCode = dtfa.receiveFastADwinX(count, dtac, IndexFirst - OrigIndexFirst, ResultPacketIndex, NumWordsReceived);
/*  809 */         if (NumWordsReceived[0] < count) {
/*  810 */           if (ErrorCode == -10) {
/*  811 */             if (this.adl != null) {
/*  812 */               this.adl.tryLater(0, ResultPacketIndex);
/*      */             }
/*      */             try {
/*  815 */               Thread.sleep(this.WaitTime);
/*  816 */             } catch (InterruptedException interruptedException) {}
/*      */           }
/*  818 */           else if (ErrorCode != 0) {
/*  819 */             if (ErrorCode == -5) {
/*  820 */               throw new ADwinCommunicationError("Wrong Password", "Falsches Passwort", this.Language, 2002);
/*      */             }
/*  822 */             if (ErrorCode == 1) {
/*  823 */               throw new ADwinCommunicationError("timeout to link", "Timeout beim Schreiben zum Link", this.Language, 1);
/*      */             }
/*  825 */             if (ErrorCode == 2) {
/*  826 */               throw new ADwinCommunicationError("timeout from link", "Timeout beim Lesen vom Link", this.Language, 2);
/*      */             }
/*  828 */             throw new ADwinCommunicationError("Error on ADwin System: " + ErrorCode, "Fehler " + ErrorCode + " auf dem ADwin-System", this.Language, 
/*      */                 
/*  830 */                 (ErrorCode > 0) ? ErrorCode : 2000);
/*      */           } 
/*  832 */           IndexFirst += NumWordsReceived[0];
/*  833 */           Values[2] = IndexFirst;
/*  834 */           Values[3] = count;
/*  835 */           Values[1] = DataNr + (count << 16);
/*  836 */           adwc.setValues(Values);
/*  837 */           ErrorCode = -10;
/*  838 */           if (NumWordsReceived[0] > 0) {
/*  839 */             n = 0;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  844 */     if (ErrorCode != 0) {
/*  845 */       if (this.adl != null) {
/*  846 */         this.adl.message("Error Code " + ErrorCode + " -> ADwinCommunicationError in getDataFast...", 1);
/*      */       }
/*      */       
/*  849 */       if (this.adl != null) {
/*  850 */         this.adl.leave();
/*      */       }
/*  852 */       if (ErrorCode == -5) {
/*  853 */         throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */       }
/*  855 */       if (ErrorCode == -31) {
/*  856 */         throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */       }
/*  858 */       throw new ADwinCommunicationError("Unable to load DATA_" + DataNr + " (fast method)", "Kann DATA_" + DataNr + " nicht mit schneller Methode lesen", this.Language, 
/*      */           
/*  860 */           (ErrorCode == -10) ? 16 : 2000);
/*      */     } 
/*      */     
/*  863 */     if (this.adl != null) {
/*  864 */       this.adl.leave();
/*      */     }
/*  866 */     return dtac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataToArrayConverter getData(int DataNr, int IndexFirst, int IndexLast, int PCDataType) throws ADwinCommunicationError {
/*  889 */     if (this.adl != null) {
/*  890 */       this.adl.enter("getData (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ", " + PCDataType + ")");
/*      */     }
/*      */     
/*  893 */     int versionLocal = readAEIVersionIfUnknown();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  904 */     if (IndexFirst > IndexLast) {
/*  905 */       if (this.adl != null) {
/*  906 */         this.adl.leave();
/*      */       }
/*  908 */       throw new IllegalArgumentException((this.Language == 1) ? ("reading DATA_" + DataNr + ": Only a positive number of elements can be retrieved!") : (
/*  909 */           "Nur eine positive Anzahl von Elementen kann aus DATA_" + DataNr + " gelesen werden"));
/*      */     } 
/*      */ 
/*      */     
/*  913 */     if (IndexLast - IndexFirst + 1 <= 350 * this.DataBlockSize && versionLocal >= 250) {
/*  914 */       DataToArrayConverter dtac = getDataFast(DataNr, IndexFirst, IndexLast, PCDataType);
/*  915 */       if (this.adl != null) {
/*  916 */         this.adl.leave();
/*      */       }
/*  918 */       return dtac;
/*      */     } 
/*  920 */     if (versionLocal >= 266 && versionLocal < 400) {
/*  921 */       DataToArrayConverter dtac = getDataSH(DataNr, IndexFirst, IndexLast, PCDataType);
/*  922 */       if (this.adl != null) {
/*  923 */         this.adl.leave();
/*      */       }
/*  925 */       return dtac;
/*      */     } 
/*      */     
/*  928 */     synchronized (this.ds) {
/*  929 */       DataToArrayConverter dtac; int SourceDataType = getDataType(DataNr);
/*  930 */       if (SourceDataType == 4) {
/*  931 */         SourceDataType = 3;
/*      */       }
/*  933 */       if (SourceDataType == 2) {
/*  934 */         SourceDataType = 3;
/*      */       }
/*      */ 
/*      */       
/*  938 */       if (SourceDataType != 3 && SourceDataType != 5) {
/*  939 */         if (this.adl != null) {
/*  940 */           this.adl.message("error... Unknown Data-Type of Data " + DataNr + ".", 1);
/*      */           
/*  942 */           this.adl.leave();
/*      */         } 
/*  944 */         throw new ADwinCommunicationError("Unknown type of DATA_" + DataNr + "!", "DATA_" + DataNr + " hat keinen bekannten Datentyp", this.Language, 100);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  949 */       if (PCDataType == 3) {
/*  950 */         dtac = new DataToIntArray(IndexLast - IndexFirst + 1, SourceDataType);
/*  951 */       } else if (PCDataType == 5) {
/*  952 */         dtac = new DataToFloatArray(IndexLast - IndexFirst + 1, SourceDataType);
/*  953 */       } else if (PCDataType == 2) {
/*  954 */         dtac = new DataToIntArray((IndexLast - IndexFirst + 1) / 2 + 1, SourceDataType);
/*      */       } else {
/*  956 */         throw new ADwinCommunicationError("Unknown type of DATA_" + DataNr + "!", "DATA_" + DataNr + " hat keinen bekannten Datentyp", this.Language, 100);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  962 */       int[] Values = new int[4];
/*  963 */       if (is_adwinx(this.version)) {
/*  964 */         Values[0] = 0;
/*      */       } else {
/*  966 */         Values[0] = PCDataType;
/*  967 */       }  Values[1] = DataNr + (this.DataBlockSize << 16);
/*  968 */       Values[2] = IndexFirst;
/*  969 */       Values[3] = IndexLast - IndexFirst + 1;
/*      */       
/*  971 */       int RequestState = standardCall(7, Values, 0, "", "DATA_" + DataNr, "", "DATA_" + DataNr, false, null);
/*      */       
/*  973 */       if (RequestState != 0) {
/*  974 */         if (this.adl != null) {
/*  975 */           this.adl.message("Fehler: " + RequestState + "... ", 1);
/*  976 */           this.adl.leave();
/*      */         } 
/*  978 */         if (RequestState == -5) {
/*  979 */           throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */         }
/*  981 */         throw new ADwinCommunicationError("Unable to load DATA_" + DataNr, "Kann DATA_" + DataNr + " nicht laden", this.Language, 
/*  982 */             (RequestState == -10) ? 16 : 2000);
/*      */       } 
/*      */       
/*  985 */       DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/*  986 */       if (PCDataType == 2) {
/*  987 */         dft.receive((IndexLast - IndexFirst + 1) / 2, dtac, "DATA_" + DataNr);
/*      */       } else {
/*  989 */         dft.receive(IndexLast - IndexFirst + 1, dtac, "DATA_" + DataNr);
/*      */       } 
/*      */       
/*  992 */       if (this.adl != null) {
/*  993 */         this.adl.leave();
/*      */       }
/*  995 */       return dtac;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataToArrayConverter getDataADwinX(int DataNr, int IndexFirst, int IndexLast, int PCDataType) throws ADwinCommunicationError {
/* 1012 */     if (this.adl != null) {
/* 1013 */       this.adl.enter("getDataDoubleADwinX(" + DataNr + ", " + IndexFirst + ", " + IndexLast + ", )");
/*      */     }
/* 1015 */     if (IndexFirst > IndexLast) {
/* 1016 */       if (this.adl != null) {
/* 1017 */         this.adl.leave();
/*      */       }
/* 1019 */       throw new IllegalArgumentException((this.Language == 1) ? ("reading DATA_" + DataNr + ": Only a positive number of elements can be retrieved!") : (
/* 1020 */           "Nur eine positive Anzahl von Elementen kann aus DATA_" + DataNr + " gelesen werden"));
/*      */     } 
/*      */ 
/*      */     
/* 1024 */     int count = IndexLast - IndexFirst + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     if (count <= 175) {
/* 1034 */       DataToArrayConverter dtac = getDataFastADwinX(DataNr, IndexFirst, IndexLast, PCDataType);
/* 1035 */       if (this.adl != null) {
/* 1036 */         this.adl.leave();
/*      */       }
/* 1038 */       return dtac;
/*      */     } 
/*      */     
/* 1041 */     synchronized (this.ds) {
/* 1042 */       DataToArrayConverter dtac; int SourceDataType = getDataType(DataNr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1057 */       if (SourceDataType < 3 || SourceDataType > 7) {
/*      */         
/* 1059 */         if (this.adl != null) {
/* 1060 */           this.adl.message("error... Unknown Data-Type of Data " + DataNr + ".", 1);
/*      */           
/* 1062 */           this.adl.leave();
/*      */         } 
/* 1064 */         throw new ADwinCommunicationError("Unknown type of DATA_" + DataNr + "!", "DATA_" + DataNr + " hat keinen bekannten Datentyp", this.Language, 100);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1070 */       switch (PCDataType) {
/*      */         case 3:
/* 1072 */           dtac = new DataToIntArray(count, SourceDataType);
/*      */           break;
/*      */         case 5:
/* 1075 */           dtac = new DataToFloatArray(count, SourceDataType);
/*      */           break;
/*      */         case 6:
/* 1078 */           dtac = new DataToDoubleArray(count, SourceDataType);
/*      */           break;
/*      */         case 7:
/* 1081 */           dtac = new DataToInt64Array(count, SourceDataType);
/*      */           break;
/*      */         default:
/* 1084 */           if (this.adl != null) {
/* 1085 */             this.adl.message("error... Data-Type not supported.", 1);
/* 1086 */             this.adl.leave();
/*      */           } 
/* 1088 */           throw new ADwinCommunicationError("Data-Type not supported.", "Datentyp wird nicht unterstützt.", this.Language, 100);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1094 */       int[] Values = new int[4];
/* 1095 */       Values[0] = 0;
/* 1096 */       if (SourceDataType == 6)
/* 1097 */         Values[0] = 6; 
/* 1098 */       if (SourceDataType == 7) {
/* 1099 */         Values[0] = 7;
/*      */       }
/* 1101 */       Values[1] = DataNr + (this.DataBlockSize << 16);
/* 1102 */       Values[2] = IndexFirst;
/* 1103 */       Values[3] = IndexLast - IndexFirst + 1;
/*      */       
/* 1105 */       int RequestState = standardCall(7, Values, 0, "", "DATA_" + DataNr, "", "DATA_" + DataNr, false, null);
/*      */       
/* 1107 */       if (RequestState != 0) {
/* 1108 */         if (this.adl != null) {
/* 1109 */           this.adl.message("Fehler: " + RequestState + "... ", 1);
/* 1110 */           this.adl.leave();
/*      */         } 
/* 1112 */         if (RequestState == -5) {
/* 1113 */           throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */         }
/* 1115 */         throw new ADwinCommunicationError("Unable to load DATA_" + DataNr, "Kann DATA_" + DataNr + " nicht laden", this.Language, 
/* 1116 */             (RequestState == -10) ? 16 : 2000);
/*      */       } 
/*      */       
/* 1119 */       DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/* 1120 */       dft.receiveADwinX(count, dtac, "DATA_" + DataNr);
/*      */       
/* 1122 */       if (this.adl != null) {
/* 1123 */         this.adl.leave();
/*      */       }
/* 1125 */       return dtac;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private DataToArrayConverter getDataSH(int DataNr, int IndexFirst, int IndexLast, int DataType) throws ADwinCommunicationError {
/* 1131 */     if (this.adl != null) {
/* 1132 */       this.adl.enter("getDataSH (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ", " + DataType + ")");
/*      */     }
/*      */     
/* 1135 */     int[] values = new int[4];
/* 1136 */     int[] sentPacketIndex = new int[1];
/* 1137 */     values[0] = reverseByteOrder(DataNr << 16 | 0x1E);
/* 1138 */     values[1] = reverseByteOrder(IndexFirst);
/* 1139 */     values[2] = reverseByteOrder(IndexLast - IndexFirst + 1);
/* 1140 */     values[3] = 0;
/* 1141 */     synchronized (this.ds) {
/* 1142 */       int start; DataToArrayConverter dtac; int r1_status = standardCall(107, values, 0, "Unable to read DATA_" + DataNr, "DATA_" + DataNr, "Kann DATA_" + DataNr + " nicht lesen", "DATA_" + DataNr, true, sentPacketIndex);
/*      */       
/* 1144 */       if (r1_status == -31) {
/* 1145 */         if (this.adl != null) {
/* 1146 */           this.adl.leave();
/*      */         }
/* 1148 */         throw new ADwinCommunicationError("Unable to read Data_" + DataNr, "Data_" + DataNr + " kann nicht gelesen werden", this.Language, 100);
/* 1149 */       }  if (r1_status != 0) {
/* 1150 */         if (this.adl != null) {
/* 1151 */           this.adl.leave();
/*      */         }
/* 1153 */         throw new ADwinCommunicationError("Unable to read Data_" + DataNr, "Data_" + DataNr + " kann nicht gelesen werden", this.Language, r1_status);
/*      */       } 
/*      */       
/* 1156 */       boolean processorT11 = (reverseByteOrder(values[1]) == 2);
/* 1157 */       int sourceType = values[0];
/* 1158 */       if (sourceType != 5) {
/* 1159 */         sourceType = 3;
/*      */       }
/*      */ 
/*      */       
/* 1163 */       int length = IndexLast - IndexFirst + 1;
/* 1164 */       if (processorT11) {
/* 1165 */         int misalignment = IndexFirst - 1 & 0x3;
/* 1166 */         start = IndexFirst - misalignment;
/* 1167 */         length = 4 * (length + misalignment + 3 >>> 2);
/*      */       } else {
/* 1169 */         start = IndexFirst;
/*      */       } 
/*      */ 
/*      */       
/* 1173 */       if (DataType == 3) {
/* 1174 */         dtac = new DataToIntArray(IndexLast - IndexFirst + 1, sourceType);
/* 1175 */       } else if (DataType == 2) {
/* 1176 */         dtac = new DataToIntArray((IndexLast - IndexFirst + 1) / 2 + 1, sourceType);
/* 1177 */       } else if (DataType == 5) {
/* 1178 */         dtac = new DataToFloatArray(IndexLast - IndexFirst + 1, sourceType);
/*      */       } else {
/* 1180 */         throw new IllegalArgumentException("invalid data type given.");
/*      */       } 
/* 1182 */       dtac.setOffset(IndexFirst - start);
/*      */       
/* 1184 */       DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/* 1185 */       if (DataType == 2) {
/* 1186 */         dft.getArraySH(sentPacketIndex[0], length / 2, dtac, this.Connection, this.Port);
/*      */       } else {
/* 1188 */         dft.getArraySH(sentPacketIndex[0], length, dtac, this.Connection, this.Port);
/*      */       } 
/*      */       
/* 1191 */       if (this.adl != null) {
/* 1192 */         this.adl.leave();
/*      */       }
/* 1194 */       return dtac;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getSetDataStatus(int SetDataPacketIndex) throws ADwinCommunicationError {
/* 1199 */     if (this.adl != null) {
/* 1200 */       this.adl.enter("getSetDataStatus (" + SetDataPacketIndex + ")");
/*      */     }
/* 1202 */     int[] Values = new int[4];
/* 1203 */     Values[0] = SetDataPacketIndex;
/* 1204 */     Values[3] = 0; Values[2] = 0; Values[1] = 0;
/*      */     
/* 1206 */     int RetVal = standardCall(108, Values, 8, "Unable to read status of last Set_Data.", "Status of last Set_Data", "Kann Status vom letzten Set_Data nicht lesen", "Status vom letzten Set_Data", false, null);
/*      */     
/* 1208 */     if (this.adl != null) {
/* 1209 */       this.adl.leave();
/*      */     }
/* 1211 */     return RetVal;
/*      */   }
/*      */ 
/*      */   
/*      */   private void setData(byte[] Data, int DataNr, int IndexFirst, int IndexLast, int DataType) throws ADwinCommunicationError {
/* 1216 */     if (this.adl != null) {
/* 1217 */       this.adl.enter("setData (byte Data[], " + DataNr + ", " + IndexFirst + ", " + IndexLast + ", " + DataType + ")");
/*      */     }
/*      */     
/* 1220 */     int Count = IndexLast - IndexFirst + 1;
/* 1221 */     int versionLocal = readAEIVersionIfUnknown();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1231 */     if (IndexFirst > IndexLast) {
/* 1232 */       if (this.adl != null) {
/* 1233 */         this.adl.leave();
/*      */       }
/* 1235 */       throw new IllegalArgumentException((this.Language == 1) ? ("setting DATA_" + DataNr + ": Only a positive Number of elements can be set!") : (
/*      */           
/* 1237 */           "Nur eine positive Anzahl von Elementen kann bei DATA_" + DataNr + " gesetzt werden!"));
/*      */     } 
/*      */     
/* 1240 */     int[] sentPacketIndex = new int[1];
/* 1241 */     byte[] ConfirmationData = new byte[32];
/* 1242 */     DatagramPacket ConfPacket = new DatagramPacket(ConfirmationData, 32);
/* 1243 */     int TimeoutsOccured = 0;
/* 1244 */     int NumRetriesForSending = 0;
/*      */     
/* 1246 */     int bytes_per_value = BytesPerValue(DataType);
/* 1247 */     int ByteCount = Count * bytes_per_value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1256 */     int sendType = DataType;
/* 1257 */     if (sendType == 3) sendType = 2;
/*      */ 
/*      */     
/* 1260 */     synchronized (this.ds) {
/*      */       while (true) {
/* 1262 */         int[] Values = new int[4];
/* 1263 */         Values[0] = sendType;
/* 1264 */         Values[1] = DataNr | this.DataBlockSize << 16;
/* 1265 */         Values[2] = IndexFirst;
/* 1266 */         Values[3] = Count;
/*      */         
/* 1268 */         DataFieldTransfer dtfa = new DataFieldTransfer(this.Connection, this.ds, this);
/*      */         try {
/* 1270 */           standardCall(8, Values, 4, "Cannot start setting DATA_" + DataNr, "setting DATA_" + DataNr, "Kann nicht anfangen, DATA_" + DataNr + " zu setzen", "Setzen von DATA_" + DataNr, false, sentPacketIndex);
/*      */ 
/*      */           
/* 1273 */           dtfa.send(ByteCount, Data, "DATA_" + DataNr, sentPacketIndex[0]);
/* 1274 */         } catch (ADwinCommunicationError awce) {
/* 1275 */           if (awce.getCode() == 100) {
/* 1276 */             if (this.adl != null) {
/* 1277 */               this.adl.message("SetData DataTooSmall", 100);
/* 1278 */               this.adl.leave();
/*      */             } 
/* 1280 */             throw new ADwinCommunicationError("The Data is too small", "Das Data-Feld ist zu klein", this.Language, 100);
/*      */           } 
/* 1282 */           if ((versionLocal >= 253 && versionLocal < 260) || versionLocal >= 264) {
/*      */             int stat;
/* 1284 */             if ((stat = getSetDataStatus(sentPacketIndex[0])) == 1) {
/* 1285 */               if (this.adl != null) {
/* 1286 */                 this.adl.message("Exception vom dtfa.sent -> getSetDataStatus war aber OK", 100);
/* 1287 */                 this.adl.leave();
/*      */               } 
/*      */               return;
/*      */             } 
/* 1291 */             if (this.adl != null) {
/* 1292 */               this.adl.message("Exception vom dtfa.send -> getSetDataStatus ergab " + stat, 1);
/* 1293 */               this.adl.leave();
/*      */             } 
/* 1295 */             throw awce;
/*      */           } 
/*      */           
/* 1298 */           if (this.adl != null) {
/* 1299 */             this.adl.message("Retry für's komplette Data (Exception vom dtfa.send)", 1);
/*      */           }
/* 1301 */           if (NumRetriesForSending >= this.AllowedErrors) {
/* 1302 */             throw awce;
/*      */           }
/* 1304 */           NumRetriesForSending++;
/* 1305 */           TimeoutsOccured++;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1311 */           this.ds.receive(ConfPacket);
/* 1312 */           TimeoutsOccured = 0;
/* 1313 */         } catch (SocketTimeoutException ste) {
/* 1314 */           if ((versionLocal >= 253 && versionLocal < 260) || versionLocal >= 264) {
/*      */             int stat;
/* 1316 */             if ((stat = getSetDataStatus(sentPacketIndex[0])) == 1) {
/* 1317 */               if (this.adl != null) {
/* 1318 */                 this.adl.message("Timeout, aber getSetDataStatus war OK", 100);
/* 1319 */                 this.adl.leave();
/*      */               } 
/*      */               return;
/*      */             } 
/* 1323 */             if (this.adl != null) {
/* 1324 */               this.adl.message("Timeout -> getSetDataStatus ergab " + stat, 1);
/* 1325 */               this.adl.leave();
/*      */             } 
/* 1327 */             throw new ADwinCommunicationError("DATA_" + DataNr + " could not be set, " + ste
/* 1328 */                 .getMessage(), "DATA_" + DataNr + " konnte nicht beschrieben werden, " + ste
/* 1329 */                 .getMessage(), this.Language, 2000);
/*      */           } 
/*      */           
/* 1332 */           if (this.adl != null) {
/* 1333 */             this.adl.message("Timeout in setData...", 1);
/*      */           }
/*      */           
/* 1336 */           TimeoutsOccured++;
/* 1337 */           if (TimeoutsOccured > this.AllowedErrors) {
/* 1338 */             if (this.adl != null) {
/* 1339 */               this.adl.leave();
/*      */             }
/* 1341 */             throw new ADwinCommunicationError("DATA_" + DataNr + " could not be set, " + ste
/* 1342 */                 .getMessage(), "DATA_" + DataNr + " konnte nicht beschrieben werden, " + ste
/* 1343 */                 .getMessage(), this.Language, 100);
/*      */           }
/*      */         
/* 1346 */         } catch (IOException ioe) {
/* 1347 */           if (this.adl != null) {
/* 1348 */             this.adl.message("IOException -> ADwinCommunicationError in setData", 1);
/*      */             
/* 1350 */             this.adl.leave();
/*      */           } 
/* 1352 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1353 */               .getMessage(), this.Language, 2000);
/*      */         } 
/*      */         
/* 1356 */         if (TimeoutsOccured <= 0) {
/*      */           
/* 1358 */           if (extractInt(ConfirmationData, 0) != 0) {
/* 1359 */             if (this.adl != null) {
/* 1360 */               this.adl.message("Error Code " + extractInt(ConfirmationData, 0) + " -> ADwinCommunicationError in setData...", 1);
/*      */               
/* 1362 */               this.adl.leave();
/*      */             } 
/* 1364 */             throw new ADwinCommunicationError("Error " + extractInt(ConfirmationData, 0) + " occured when setting DATA_" + DataNr, "Fehler " + 
/*      */                 
/* 1366 */                 extractInt(ConfirmationData, 0) + " aufgetreten beim Setzen von DATA_" + DataNr, this.Language, 
/* 1367 */                 extractInt(ConfirmationData, 0));
/*      */           } 
/* 1369 */           if (this.adl != null)
/* 1370 */             this.adl.leave(); 
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }  } private void readFifo(int FifoNr, int Count, DataToArrayConverter dtac, int Type) throws ADwinCommunicationError {
/*      */     int WordsReceived, ValuesReceived;
/* 1376 */     if (this.adl != null) {
/* 1377 */       this.adl.enter("readFifo (" + FifoNr + ", " + Count + ", <DataToArrayConverter>, " + Type + ")");
/*      */     }
/*      */ 
/*      */     
/* 1381 */     DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/*      */     
/* 1383 */     switch (BytesPerValue(Type)) {
/*      */       case 4:
/* 1385 */         WordsReceived = 0;
/*      */         
/* 1387 */         while (WordsReceived < Count) {
/* 1388 */           int NumWordsToRead; if (Count - WordsReceived > (this.DataBlockSize + 1) * 350) {
/* 1389 */             NumWordsToRead = (this.DataBlockSize + 1) * 350;
/*      */           } else {
/* 1391 */             NumWordsToRead = (Count - WordsReceived) % (this.DataBlockSize + 1) * 350;
/*      */           } 
/* 1393 */           if (NumWordsToRead == 0) {
/* 1394 */             NumWordsToRead = (this.DataBlockSize + 1) * 350;
/*      */           }
/* 1396 */           synchronized (this.ds) {
/* 1397 */             if (is_adwinx(this.version)) {
/* 1398 */               dft.readFifo(FifoNr, 0, NumWordsToRead, dtac, WordsReceived);
/*      */             } else {
/* 1400 */               int tmp = Type;
/* 1401 */               if (tmp == 3) tmp = 2; 
/* 1402 */               dft.readFifo(FifoNr, tmp, NumWordsToRead, dtac, WordsReceived);
/*      */             } 
/*      */           } 
/* 1405 */           WordsReceived += NumWordsToRead;
/*      */         } 
/*      */         break;
/*      */       case 8:
/* 1409 */         ValuesReceived = 0;
/*      */         
/* 1411 */         while (ValuesReceived < Count) {
/* 1412 */           int NumValuesToRead; if (Count - ValuesReceived > (this.DataBlockSize + 1) * 175) {
/* 1413 */             NumValuesToRead = (this.DataBlockSize + 1) * 175;
/*      */           } else {
/* 1415 */             NumValuesToRead = (Count - ValuesReceived) % (this.DataBlockSize + 1) * 175;
/*      */           } 
/* 1417 */           if (NumValuesToRead == 0) {
/* 1418 */             NumValuesToRead = (this.DataBlockSize + 1) * 175;
/*      */           }
/* 1420 */           synchronized (this.ds) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1426 */             dft.readFifo(FifoNr, Type, NumValuesToRead, dtac, ValuesReceived);
/*      */           } 
/* 1428 */           ValuesReceived += NumValuesToRead;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */     
/* 1433 */     if (this.adl != null) {
/* 1434 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeFifo(int FifoNr, int Typ, int count, int NumWords, byte[] Data, int DataOffset) throws ADwinCommunicationError {
/* 1439 */     if (this.adl != null) {
/* 1440 */       this.adl.enter("writeFifo (" + FifoNr + ", " + Typ + ", " + NumWords + ", <byte[]>, " + DataOffset + ")");
/*      */     }
/*      */     
/* 1443 */     int[] Values = new int[4];
/* 1444 */     Values[0] = Typ;
/* 1445 */     Values[1] = FifoNr + (this.DataBlockSize + 1 << 16);
/* 1446 */     Values[2] = 0;
/* 1447 */     Values[3] = count;
/* 1448 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/* 1449 */     adwc.setTimeout(this.ADwTimeout);
/* 1450 */     adwc.setPwd(this.Password);
/*      */     
/* 1452 */     boolean EverythingSent = false;
/* 1453 */     boolean ConfirmationReceived = true;
/* 1454 */     byte[] ConfirmData = new byte[32];
/* 1455 */     int TryLatersLeft = this.NumWaits;
/* 1456 */     int SentIndex = 0, ExpectedPacketIndex = 0;
/* 1457 */     DatagramPacket ConfirmPacket = new DatagramPacket(ConfirmData, 32);
/* 1458 */     int NumAttemptsLeft = this.AllowedErrors;
/* 1459 */     int NumPacketsToSend = (NumWords - 1) / 350 + 1;
/* 1460 */     int ErrorsOccured = 0;
/* 1461 */     boolean RetryActive = false;
/* 1462 */     boolean IllegalPacketIndexRecvd = false;
/*      */     
/* 1464 */     synchronized (this.ds) {
/* 1465 */       while (!EverythingSent && NumAttemptsLeft >= 0) {
/* 1466 */         if (ErrorsOccured > this.AllowedErrors) {
/* 1467 */           if (this.adl != null) {
/* 1468 */             this.adl.message("Too many errors in writeFifo...", 1);
/* 1469 */             this.adl.leave();
/*      */           } 
/* 1471 */           throw new ADwinCommunicationError("Number of errors occured exceeded AllowedErrors in writeFifo when writing to fifo " + FifoNr + ".", "Anzahl der aufgetretenen Fehler übersteigt AllowedErrors beim Schreiben in Fifo " + FifoNr + ".", this.Language, 2001);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1476 */         if (TryLatersLeft <= 0) {
/*      */           break;
/*      */         }
/* 1479 */         if (!IllegalPacketIndexRecvd) {
/* 1480 */           if (!RetryActive) {
/* 1481 */             adwc.setCommand(25);
/* 1482 */             Values[2] = 0;
/* 1483 */             adwc.setPacketIndex(ExpectedPacketIndex = SentIndex = incGetCurrentIndex());
/*      */           } else {
/* 1485 */             if (this.adl != null) {
/* 1486 */               this.adl.sendAgain(SentIndex, 0, 125);
/*      */             }
/* 1488 */             adwc.setCommand(125);
/* 1489 */             Values[2] = SentIndex;
/* 1490 */             adwc.setPacketIndex(ExpectedPacketIndex = incGetCurrentIndex());
/* 1491 */             RetryActive = false;
/*      */           } 
/* 1493 */           adwc.setValues(Values);
/* 1494 */           adwc.setLink(this.Hostlink);
/*      */           
/*      */           try {
/* 1497 */             this.ds.send(adwc.getDatagram(this.Connection));
/* 1498 */           } catch (IOException ioe) {
/* 1499 */             if (this.adl != null) {
/* 1500 */               this.adl.message("IOException -> ADwinCommunicationError when sending in writeFifo", 1);
/* 1501 */               this.adl.leave();
/*      */             } 
/* 1503 */             throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1504 */                 .getMessage(), this.Language, 2000);
/*      */           } 
/*      */         } 
/*      */         
/* 1508 */         IllegalPacketIndexRecvd = false;
/* 1509 */         ConfirmationReceived = true;
/*      */         try {
/* 1511 */           this.ds.setSoTimeout(this.MaxPacketDelay);
/* 1512 */           this.ds.receive(ConfirmPacket);
/* 1513 */         } catch (SocketTimeoutException ste) {
/* 1514 */           if (this.adl != null) {
/* 1515 */             this.adl.message("Timeout...", 100);
/*      */           }
/* 1517 */           ConfirmationReceived = false;
/* 1518 */         } catch (IOException ioe) {
/* 1519 */           if (this.adl != null) {
/* 1520 */             this.adl.message("IOException -> ADwinCommunicationError when receiving in writeFifo", 1);
/* 1521 */             this.adl.leave();
/*      */           } 
/* 1523 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1524 */               .getMessage(), this.Language, 2000);
/*      */         } 
/*      */ 
/*      */         
/* 1528 */         if (ConfirmationReceived && ((
/* 1529 */           !newTryLater() && extractInt(ConfirmData, 0) != -10 && extractInt(ConfirmData, 4) != ExpectedPacketIndex) || (
/* 1530 */           newTryLater() && extractInt(ConfirmData, 4) != ExpectedPacketIndex))) {
/* 1531 */           if (this.adl != null) {
/* 1532 */             this.adl.message("Vor'm Schreiben der Datenpakete: Erwarteter Paket-Index: " + ExpectedPacketIndex + ", erhaltener: " + 
/* 1533 */                 extractInt(ConfirmData, 4) + ".", 1);
/*      */           }
/* 1535 */           IllegalPacketIndexRecvd = true;
/*      */           
/*      */           continue;
/*      */         } 
/* 1539 */         if (ConfirmationReceived) {
/* 1540 */           if (extractInt(ConfirmData, 0) == -10) {
/* 1541 */             if (this.adl != null) {
/* 1542 */               this.adl.tryLater(SentIndex, this.NumWaits - TryLatersLeft);
/*      */             }
/*      */             try {
/* 1545 */               Thread.sleep(this.WaitTime);
/* 1546 */             } catch (InterruptedException interruptedException) {}
/*      */             
/* 1548 */             TryLatersLeft--;
/*      */             continue;
/*      */           } 
/* 1551 */           if (extractInt(ConfirmData, 0) == -41) {
/* 1552 */             ErrorsOccured++;
/* 1553 */             if (this.adl != null) {
/* 1554 */               this.adl.message("Fehler -41 beim Warten auf Bestätigung in writeFifo - wird nochmal ohne Retry versucht", 50);
/*      */             }
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/* 1560 */           if (extractInt(ConfirmData, 0) == -40) {
/* 1561 */             if (this.adl != null) {
/* 1562 */               this.adl.message("Fehler -40: -> Mache weiter...", 50);
/* 1563 */               this.adl.leave();
/*      */             } 
/*      */             
/*      */             return;
/*      */           } 
/* 1568 */           if (extractInt(ConfirmData, 0) < 0 || extractInt(ConfirmData, 0) == 5) {
/* 1569 */             ErrorsOccured++;
/* 1570 */             RetryActive = true;
/* 1571 */             if (this.adl != null) {
/* 1572 */               this.adl.message("Fehler " + extractInt(ConfirmData, 0) + " beim Warten auf Bestätigung zum Anfangen in writeFifo...", 50);
/*      */             }
/*      */             
/*      */             continue;
/*      */           } 
/* 1577 */           if (extractInt(ConfirmData, 0) != 0) {
/* 1578 */             if (this.adl != null) {
/* 1579 */               this.adl.message("Error code " + extractInt(ConfirmData, 0) + " -> ADwinCommunicationError", 1);
/*      */               
/* 1581 */               this.adl.leave();
/*      */             } 
/* 1583 */             throw new ADwinCommunicationError("error " + extractInt(ConfirmData, 0) + " on ADwin System when writing to fifo " + FifoNr, "Fehler " + 
/*      */                 
/* 1585 */                 extractInt(ConfirmData, 0) + " auf dem ADwin-System beim Schreiben von Fifo " + FifoNr + ".", this.Language, 
/* 1586 */                 extractInt(ConfirmData, 0));
/*      */           } 
/* 1588 */           ErrorsOccured = 0;
/*      */           
/* 1590 */           byte[] FifoBytes = new byte[1408];
/* 1591 */           DatagramPacket dp = new DatagramPacket(FifoBytes, 1408, this.Connection, this.Port);
/*      */           
/* 1593 */           for (int Packet = 0; Packet < NumPacketsToSend; Packet++) {
/* 1594 */             int NumDataWords; setInteger(FifoBytes, 0, ExpectedPacketIndex);
/* 1595 */             setInteger(FifoBytes, 4, Packet);
/*      */ 
/*      */             
/* 1598 */             if (Packet != NumPacketsToSend - 1) {
/* 1599 */               NumDataWords = 350;
/*      */             } else {
/* 1601 */               NumDataWords = NumWords % 350;
/*      */             } 
/* 1603 */             if (NumDataWords == 0) {
/* 1604 */               NumDataWords = 350;
/*      */             }
/*      */             
/* 1607 */             for (int n = 0; n < NumDataWords * 4; n++) {
/* 1608 */               FifoBytes[n + 8] = Data[n + Packet * 350 * 4 + DataOffset];
/*      */             }
/*      */ 
/*      */             
/*      */             try {
/* 1613 */               this.ds.send(dp);
/* 1614 */             } catch (IOException ioe) {
/* 1615 */               if (this.adl != null) {
/* 1616 */                 this.adl.message("IOException -> ADwinCommunicationError when sending Data in writeFifo", 1);
/*      */                 
/* 1618 */                 this.adl.leave();
/*      */               } 
/* 1620 */               throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1621 */                   .getMessage(), this.Language, 2000);
/*      */             } 
/*      */           } 
/*      */           
/* 1625 */           ConfirmationReceived = true;
/*      */           try {
/* 1627 */             this.ds.setSoTimeout(this.MaxPacketDelay * 2 + this.ADwTimeout);
/* 1628 */             this.ds.receive(ConfirmPacket);
/* 1629 */           } catch (SocketTimeoutException ste) {
/* 1630 */             if (this.adl != null) {
/* 1631 */               this.adl.message("Timeout when waiting for confirmation....", 100);
/*      */             }
/* 1633 */             ConfirmationReceived = false;
/* 1634 */           } catch (IOException ioe) {
/* 1635 */             if (this.adl != null) {
/* 1636 */               this.adl.message("IOException -> ADwinCommunicationError when receiving confirmation in writeFifo", 1);
/*      */               
/* 1638 */               this.adl.leave();
/*      */             } 
/* 1640 */             throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1641 */                 .getMessage(), this.Language, 2000);
/*      */           } 
/*      */ 
/*      */           
/* 1645 */           if (ConfirmationReceived && extractInt(ConfirmData, 0) == -32) {
/* 1646 */             if (this.adl != null) {
/* 1647 */               this.adl.message("Fifo zu klein", 1);
/*      */             }
/* 1649 */             throw new ADwinCommunicationError("There is not enough space left in fifo " + FifoNr, "Nicht genug Platz übrig in Fifo " + FifoNr, this.Language, 101);
/*      */           } 
/*      */ 
/*      */           
/* 1653 */           if (ConfirmationReceived && (extractInt(ConfirmData, 0) < 0 || 
/* 1654 */             extractInt(ConfirmData, 0) == 5)) {
/* 1655 */             if (this.adl != null) {
/* 1656 */               this.adl.message("Error " + extractInt(ConfirmData, 0) + " in confirmation", 50);
/*      */             }
/*      */             
/* 1659 */             NumAttemptsLeft--;
/* 1660 */             RetryActive = true; continue;
/* 1661 */           }  if (ConfirmationReceived && extractInt(ConfirmData, 0) > 0) {
/* 1662 */             if (this.adl != null) {
/* 1663 */               this.adl.message("Error " + extractInt(ConfirmData, 0) + " -> ADwinCommunicationError in confirmation...", 1);
/*      */ 
/*      */               
/* 1666 */               this.adl.leave();
/*      */             } 
/* 1668 */             throw new ADwinCommunicationError("error on ADwin System when writing Bytes to Fifo " + FifoNr + ", - error " + 
/* 1669 */                 extractInt(ConfirmData, 0), "Fehler " + 
/* 1670 */                 extractInt(ConfirmData, 0) + " auf dem ADwin-System beim Schreiben von Fifo " + FifoNr + ".", this.Language, 
/*      */                 
/* 1672 */                 extractInt(ConfirmData, 0));
/* 1673 */           }  if (ConfirmationReceived) {
/* 1674 */             EverythingSent = true; continue;
/*      */           } 
/* 1676 */           EverythingSent = false;
/* 1677 */           RetryActive = true;
/*      */           continue;
/*      */         } 
/* 1680 */         if (this.adl != null) {
/* 1681 */           this.adl.message("one attempt less left......", 50);
/*      */         }
/* 1683 */         NumAttemptsLeft--;
/* 1684 */         RetryActive = true;
/* 1685 */         IllegalPacketIndexRecvd = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1690 */     if (this.adl != null) {
/* 1691 */       this.adl.leave();
/*      */     }
/* 1693 */     if (!EverythingSent) {
/* 1694 */       throw new ADwinCommunicationError("Could not send everything...", "Es konnte nicht alles gesendet werden...", this.Language, 2000);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getArmVersion() throws ADwinCommunicationError {
/* 1702 */     int supports, Values[] = { 1000, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1711 */     if (this.version > 0 && this.version != 299) {
/* 1712 */       return this.version;
/*      */     }
/*      */     
/* 1715 */     if (this.version == 299) {
/* 1716 */       standardCall(1000, Values, 0, "Unable to determine the version of the ethernet interface", "version of the ethernet interface", "Version des Ethernet-Interfaces konnte nicht bestimmt werden", "Version des Ethernet-Interfaces", true, null);
/*      */ 
/*      */       
/* 1719 */       this.version = Values[0];
/* 1720 */       supports = Values[2];
/*      */     } else {
/* 1722 */       this.version = -1;
/* 1723 */       standardCall(1000, Values, 0, "Unable to determine the version of the ethernet interface", "version of the ethernet interface", "Version des Ethernet-Interfaces konnte nicht bestimmt werden", "Version des Ethernet-Interfaces", true, null);
/*      */ 
/*      */       
/* 1726 */       this.version = Values[0];
/* 1727 */       supports = Values[2];
/*      */       
/* 1729 */       if (this.version == 299) {
/* 1730 */         getArmVersion();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1737 */     if (this.version >= 304 && this.version < 400) {
/* 1738 */       this.supports_tcp = ((supports & 0x1) == 1);
/* 1739 */       this.supports_udp = ((supports >> 1 & 0x1) == 1);
/*      */     } else {
/*      */       
/* 1742 */       this.supports_udp = true;
/* 1743 */       this.supports_tcp = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1753 */     return this.version;
/*      */   }
/*      */   
/*      */   private void getParBlock(int IndexFirst, int NumParams, DataToArrayConverter dtac) throws ADwinCommunicationError {
/* 1757 */     if (this.adl != null) {
/* 1758 */       this.adl.enter("getParBlock (" + IndexFirst + ", " + NumParams + ", <DTAC>)");
/*      */     }
/* 1760 */     int count = NumParams;
/* 1761 */     byte[] PacketData = new byte[1008];
/*      */     
/* 1763 */     if (dtac.SourceType == 6)
/* 1764 */       count = NumParams * 2; 
/* 1765 */     int[] Values = { IndexFirst, count, 0, 0 };
/* 1766 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/* 1767 */     adwc.setCommand(13);
/* 1768 */     adwc.setTimeout(this.ADwTimeout);
/* 1769 */     adwc.setValues(Values);
/* 1770 */     adwc.setPwd(this.Password);
/* 1771 */     DatagramPacket dp = new DatagramPacket(PacketData, 1008);
/*      */     
/* 1773 */     int TryLatersLeft = this.NumWaits;
/* 1774 */     int ErrorsOccured = 0;
/* 1775 */     boolean SuccessfullyReceived = false;
/*      */ 
/*      */     
/* 1778 */     while (!SuccessfullyReceived) {
/* 1779 */       int SentIndex; boolean SomethingReceived; if (TryLatersLeft <= 0) {
/* 1780 */         if (this.adl != null) {
/* 1781 */           this.adl.message("Too many try-laters...", 1);
/* 1782 */           this.adl.leave();
/*      */         } 
/* 1784 */         throw new ADwinCommunicationError("Number of Try-Later-Packets received exceeded NumWaits", "Zu viele Try-Later-Pakete", this.Language, 16);
/*      */       } 
/*      */       
/* 1787 */       if (ErrorsOccured > this.AllowedErrors) {
/* 1788 */         if (this.adl != null) {
/* 1789 */           this.adl.message("Too many errors...", 1);
/* 1790 */           this.adl.leave();
/*      */         } 
/* 1792 */         throw new ADwinCommunicationError("Too many packet errors occured", "Zu viele Paket-Fehler", this.Language, 2000);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1797 */       synchronized (this.ds) {
/*      */         try {
/* 1799 */           adwc.setLink(this.Hostlink);
/* 1800 */           adwc.setPacketIndex(SentIndex = incGetCurrentIndex());
/* 1801 */           this.ds.send(adwc.getDatagram(this.Connection));
/* 1802 */         } catch (IOException ioe) {
/* 1803 */           if (this.adl != null) {
/* 1804 */             this.adl.message("IOException -> ADwinCommunicationError when sending in getParBlock", 1);
/* 1805 */             this.adl.leave();
/*      */           } 
/* 1807 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1808 */               .getMessage(), this.Language, 2000);
/*      */         } 
/*      */ 
/*      */         
/* 1812 */         SomethingReceived = true;
/*      */         
/*      */         do {
/*      */           try {
/* 1816 */             this.ds.setSoTimeout(this.MaxPacketDelay);
/* 1817 */             this.ds.receive(dp);
/* 1818 */           } catch (SocketTimeoutException ste) {
/* 1819 */             if (this.adl != null) {
/* 1820 */               this.adl.message("Timeout when receiving...", 50);
/*      */             }
/* 1822 */             ErrorsOccured++;
/* 1823 */             SomethingReceived = false;
/* 1824 */           } catch (IOException ioe) {
/* 1825 */             if (this.adl != null) {
/* 1826 */               this.adl.message("IOException -> ADwinCommunicationError when receiving in getParBlock", 1);
/*      */               
/* 1828 */               this.adl.leave();
/*      */             } 
/* 1830 */             throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 1831 */                 .getMessage(), this.Language, 2000);
/*      */           } 
/*      */           
/* 1834 */           if (!SomethingReceived || extractInt(PacketData, 4) == SentIndex)
/* 1835 */             continue;  if (this.adl != null) {
/* 1836 */             this.adl.message("Invalid packet index received!", 50);
/*      */           }
/* 1838 */           if (extractInt(PacketData, 0) != -10 || newTryLater())
/* 1839 */             continue;  setInteger(PacketData, 4, SentIndex);
/*      */         
/*      */         }
/* 1842 */         while (SomethingReceived && extractInt(PacketData, 4) != SentIndex);
/*      */       } 
/* 1844 */       if (SomethingReceived) {
/* 1845 */         if (extractInt(PacketData, 0) == 0) {
/* 1846 */           dtac.storeBytes(PacketData, 8, 0, NumParams);
/* 1847 */           SuccessfullyReceived = true; continue;
/* 1848 */         }  if (extractInt(PacketData, 0) == -10) {
/* 1849 */           if (this.adl != null) {
/* 1850 */             this.adl.tryLater(SentIndex, this.NumWaits - TryLatersLeft);
/*      */           }
/*      */           try {
/* 1853 */             Thread.sleep(this.WaitTime);
/* 1854 */           } catch (InterruptedException interruptedException) {}
/*      */           
/* 1856 */           TryLatersLeft--; continue;
/*      */         } 
/* 1858 */         if (this.adl != null) {
/* 1859 */           this.adl.message("Error (" + extractInt(PacketData, 0) + ") ...", 50);
/*      */         }
/*      */         
/* 1862 */         ErrorsOccured++;
/*      */         continue;
/*      */       } 
/* 1865 */       if (this.adl != null) {
/* 1866 */         this.adl.message("Nothing received.... ", 50);
/*      */       }
/* 1868 */       ErrorsOccured++;
/*      */     } 
/*      */ 
/*      */     
/* 1872 */     if (this.adl != null) {
/* 1873 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int standardCall(int Command, int[] Values, int RetOffset, String ErrorMsg, String RequestString, String GerErrorMsg, String GerRequestString, boolean ReturnValues, int[] sentIndex) throws ADwinCommunicationError {
/* 1880 */     if (this.adl != null) {
/* 1881 */       this.adl.enter("standardCall (" + Command + ", {" + Values[0] + ", " + Values[1] + ", " + Values[2] + ", " + Values[3] + "}, " + RetOffset + ", \"" + ErrorMsg + "\", \"" + RequestString + "\", \"" + GerErrorMsg + "\", \"" + GerRequestString + "\", " + ReturnValues + ")");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1886 */     ADwinCommand adwc = new ADwinCommand(this.version, 3000447, this.Port);
/* 1887 */     adwc.setCommand(Command);
/* 1888 */     adwc.setTimeout(this.ADwTimeout);
/* 1889 */     adwc.setValues(Values);
/* 1890 */     adwc.setPwd(this.Password);
/*      */     
/* 1892 */     DatagramPacket ResultPacket = null;
/*      */     
/*      */     try {
/* 1895 */       ResultPacket = sendAndWaitForAnswer32Byte(adwc, sentIndex);
/* 1896 */     } catch (SocketTimeoutException ste) {
/* 1897 */       if (this.adl != null) {
/* 1898 */         this.adl.message("ADwinCommunicationError: No answer... ", 1);
/* 1899 */         this.adl.leave();
/*      */       } 
/* 1901 */       throw new ADwinCommunicationError("No answer on request for " + RequestString + ", " + ste
/* 1902 */           .getMessage(), "Keine Antwort auf die Anfrage nach " + GerRequestString + ", " + ste
/* 1903 */           .getMessage(), this.Language, 2001);
/*      */     } 
/*      */ 
/*      */     
/* 1907 */     byte[] Result = ResultPacket.getData();
/* 1908 */     int iRes = extractInt(Result, 0);
/* 1909 */     if (iRes != 0 && RetOffset != 0) {
/* 1910 */       if (this.adl != null) {
/* 1911 */         this.adl.message("ADwinCommunicationError: Error " + iRes + " on ADwin System", 1);
/*      */         
/* 1913 */         this.adl.leave();
/*      */       } 
/* 1915 */       if (iRes == 1) {
/* 1916 */         throw new ADwinCommunicationError("timeout to link", "Timeout beim Schreiben zum Link", this.Language, 1);
/*      */       }
/* 1918 */       if (iRes == 2) {
/* 1919 */         throw new ADwinCommunicationError("timeout from link", "Timeout beim Lesen vom Link", this.Language, 2);
/*      */       }
/*      */       
/* 1922 */       if (iRes == -5) {
/* 1923 */         throw new ADwinCommunicationError("Wrong Password", "Falsches Passwort", this.Language, 2002);
/*      */       }
/* 1925 */       if (iRes == -30) {
/* 1926 */         throw new ADwinCommunicationError("Wrong Version", "Falsche Version", this.Language, 20);
/*      */       }
/* 1928 */       if (iRes == -31) {
/* 1929 */         throw new ADwinCommunicationError("The Data is too small", "Das Data-Feld ist zu klein", this.Language, 100);
/*      */       }
/* 1931 */       if (iRes == -32) {
/* 1932 */         throw new ADwinCommunicationError("The Fifo has not enough values", "Das Fifo-Feld hat nicht genug Daten", this.Language, 102);
/*      */       }
/*      */       
/* 1935 */       throw new ADwinCommunicationError("Error on ADwin System: " + iRes + " - " + ErrorMsg, "Fehler " + iRes + " auf dem ADwin-System - " + GerErrorMsg, this.Language, 
/*      */           
/* 1937 */           (iRes > 0) ? iRes : 2000);
/* 1938 */     }  if (ReturnValues) {
/* 1939 */       for (int n = 0; n < 4; n++) {
/* 1940 */         Values[n] = extractInt(Result, 8 + n * 4);
/*      */       }
/*      */     }
/*      */     
/* 1944 */     if (this.adl != null) {
/* 1945 */       this.adl.leave();
/*      */     }
/* 1947 */     return extractInt(Result, RetOffset);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int getPar(int Index) throws ADwinCommunicationError {
/* 1952 */     int Values[], RetVal = 0;
/*      */     
/* 1954 */     if (this.adl != null) {
/* 1955 */       this.adl.enter("getPar (" + Index + ")");
/*      */     }
/* 1957 */     if (Index > 200) {
/* 1958 */       if (this.adl != null) {
/* 1959 */         this.adl.leave();
/*      */       }
/* 1961 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of requested parameter out of range (1 <= index <= 80)." : 
/* 1962 */           "Index des verlangten Parameters außerhalb des gültigen Bereichs (1 <= Index <= 80).");
/*      */     } 
/*      */ 
/*      */     
/* 1966 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 1968 */         Values = new int[4];
/* 1969 */         Values[0] = 1;
/* 1970 */         Values[1] = 1000 + Index;
/* 1971 */         Values[3] = 0; Values[2] = 0;
/* 1972 */         RetVal = standardCall(0, Values, 8, "Unable to load PAR_" + Index + ".", "PAR_" + Index, "Kann PAR_" + Index + " nicht laden", "PAR_" + Index, false, null);
/*      */         break;
/*      */       
/*      */       case 0:
/* 1976 */         RetVal = adwin_tcp_get_par(Index);
/*      */         break;
/*      */       default:
/* 1979 */         if (this.adl != null) {
/* 1980 */           this.adl.leave();
/*      */         }
/* 1982 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 1984 */     if (this.adl != null) {
/* 1985 */       this.adl.leave();
/*      */     }
/* 1987 */     return RetVal;
/*      */   } public synchronized float getFPar(int Index) throws ADwinCommunicationError {
/*      */     int[] Values;
/*      */     float fRetVal;
/* 1991 */     int RetVal = 0;
/*      */     
/* 1993 */     if (this.adl != null) {
/* 1994 */       this.adl.enter("getFPar (" + Index + ")");
/*      */     }
/* 1996 */     if (Index < 1 || Index > 80) {
/* 1997 */       if (this.adl != null) {
/* 1998 */         this.adl.leave();
/*      */       }
/* 2000 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of requested float parameter out of range (1 <= index <= 80)." : 
/* 2001 */           "Index des verlangten float-Parameters außerhalb des gültigen Bereichs (1 <= Index <= 80).");
/*      */     } 
/*      */     
/* 2004 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2006 */         Values = new int[4];
/* 2007 */         Values[0] = 1;
/* 2008 */         Values[1] = 1100 + Index;
/* 2009 */         Values[3] = 0; Values[2] = 0;
/*      */         
/* 2011 */         RetVal = standardCall(0, Values, 8, "Unable to load FPAR_" + Index + ".", "FPAR_" + Index, "Kann FPAR_" + Index + " nicht laden", "FPAR_" + Index, false, null);
/*      */         
/* 2013 */         if (this.adl != null) {
/* 2014 */           this.adl.leave();
/*      */         }
/* 2016 */         return Float.intBitsToFloat(RetVal);
/*      */       case 0:
/* 2018 */         fRetVal = adwin_tcp_get_fpar(Index);
/* 2019 */         if (this.adl != null) {
/* 2020 */           this.adl.leave();
/*      */         }
/* 2022 */         return fRetVal;
/*      */     } 
/* 2024 */     if (this.adl != null) {
/* 2025 */       this.adl.leave();
/*      */     }
/* 2027 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   
/*      */   public synchronized double getFParDouble(int Index) throws ADwinCommunicationError {
/*      */     int RetVal;
/*      */     int[] Values;
/*      */     double fRetVal;
/* 2034 */     if (this.adl != null) {
/* 2035 */       this.adl.enter("getFParDouble (" + Index + ")");
/*      */     }
/* 2037 */     if (Index < 1 || Index > 80) {
/* 2038 */       if (this.adl != null) {
/* 2039 */         this.adl.leave();
/*      */       }
/* 2041 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of requested double parameter out of range (1 <= index <= 80)." : 
/* 2042 */           "Index des verlangten double-Parameters außerhalb des gültigen Bereichs (1 <= Index <= 80).");
/*      */     } 
/*      */     
/* 2045 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2048 */         if (is_adwinx(this.version)) {
/* 2049 */           int[] arrayOfInt = new int[4];
/* 2050 */           arrayOfInt[0] = 1;
/* 2051 */           arrayOfInt[1] = 1200 + Index;
/* 2052 */           arrayOfInt[3] = 0; arrayOfInt[2] = 0;
/* 2053 */           standardCall(0, arrayOfInt, 4, "Unable to load FPAR_DOUBLE_" + Index + ".", "FPAR_DOUBLE_" + Index, "Kann FPAR_DOUBLE_" + Index + " nicht setzen", "FPAR_DOUBLE_" + Index, true, null);
/*      */ 
/*      */           
/* 2056 */           if (this.adl != null) {
/* 2057 */             this.adl.leave();
/*      */           }
/* 2059 */           int i1 = Integer.reverseBytes(arrayOfInt[0]);
/* 2060 */           int i2 = Integer.reverseBytes(arrayOfInt[1]);
/* 2061 */           long data = i1 << 32L | i2 & 0xFFFFFFFFL;
/* 2062 */           return Double.longBitsToDouble(Long.reverseBytes(data));
/*      */         } 
/*      */         
/* 2065 */         Values = new int[4];
/* 2066 */         Values[0] = 1;
/* 2067 */         Values[1] = 1100 + Index;
/* 2068 */         Values[3] = 0; Values[2] = 0;
/*      */         
/* 2070 */         RetVal = standardCall(0, Values, 8, "Unable to load FPAR_" + Index + ".", "FPAR_" + Index, "Kann FPAR_" + Index + " nicht laden", "FPAR_" + Index, false, null);
/*      */         
/* 2072 */         if (this.adl != null) {
/* 2073 */           this.adl.leave();
/*      */         }
/* 2075 */         return Float.intBitsToFloat(RetVal);
/*      */       case 0:
/* 2077 */         fRetVal = adwin_tcp_get_fpar_double(Index);
/* 2078 */         if (this.adl != null) {
/* 2079 */           this.adl.leave();
/*      */         }
/* 2081 */         return fRetVal;
/*      */     } 
/* 2083 */     if (this.adl != null) {
/* 2084 */       this.adl.leave();
/*      */     }
/* 2086 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   
/*      */   public synchronized void setPar(int Index, int NewValue) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 2091 */     if (this.adl != null) {
/* 2092 */       this.adl.enter("setPar (" + Index + ", " + NewValue + ")");
/*      */     }
/* 2094 */     if (Index > 9002) {
/* 2095 */       if (this.adl != null) {
/* 2096 */         this.adl.leave();
/*      */       }
/* 2098 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of parameter out of range (1 <= index <= 80)." : 
/* 2099 */           "Index außerhalb des gültigen Bereichs (1 <= Index <= 80)");
/*      */     } 
/* 2101 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2103 */         Values = new int[4];
/* 2104 */         Values[0] = 6;
/* 2105 */         Values[1] = 1000 + Index;
/* 2106 */         Values[2] = NewValue;
/* 2107 */         standardCall(0, Values, 4, "Unable to set PAR_" + Index + ".", "PAR_" + Index, "Kann PAR_" + Index + " nicht setzen", "PAR_" + Index, false, null);
/*      */         break;
/*      */       
/*      */       case 0:
/* 2111 */         adwin_tcp_set_par(Index, NewValue);
/*      */         break;
/*      */       default:
/* 2114 */         if (this.adl != null) {
/* 2115 */           this.adl.leave();
/*      */         }
/* 2117 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2119 */     if (this.adl != null)
/* 2120 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void setFPar(int Index, float NewValue) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 2125 */     if (this.adl != null) {
/* 2126 */       this.adl.enter("setPar (" + Index + ", " + NewValue + ")");
/*      */     }
/* 2128 */     if (Index < 1 || Index > 80) {
/* 2129 */       if (this.adl != null) {
/* 2130 */         this.adl.leave();
/*      */       }
/* 2132 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of parameter out of range" : 
/* 2133 */           "Index des Parameters außerhalb des gültigen Bereichs");
/*      */     } 
/*      */     
/* 2136 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2138 */         Values = new int[4];
/* 2139 */         Values[0] = 6;
/* 2140 */         Values[1] = 1100 + Index;
/* 2141 */         Values[2] = Float.floatToIntBits(NewValue);
/* 2142 */         standardCall(0, Values, 4, "Unable to set FPAR_" + Index + ".", "FPAR_" + Index, "Kann FPAR_" + Index + " nicht setzen", "FPAR_" + Index, false, null);
/*      */         break;
/*      */       
/*      */       case 0:
/* 2146 */         adwin_tcp_set_fpar(Index, NewValue);
/*      */         break;
/*      */       default:
/* 2149 */         if (this.adl != null) {
/* 2150 */           this.adl.leave();
/*      */         }
/* 2152 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2154 */     if (this.adl != null)
/* 2155 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void setFParDouble(int Index, double NewValue) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 2160 */     if (this.adl != null) {
/* 2161 */       this.adl.enter("setPar (" + Index + ", " + NewValue + ")");
/*      */     }
/* 2163 */     if (Index < 1 || Index > 80) {
/* 2164 */       if (this.adl != null) {
/* 2165 */         this.adl.leave();
/*      */       }
/* 2167 */       throw new IllegalArgumentException((this.Language == 1) ? "Index of parameter out of range" : 
/* 2168 */           "Index des Parameters außerhalb des gültigen Bereichs");
/*      */     } 
/*      */     
/* 2171 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2174 */         if (is_adwinx(this.version)) {
/* 2175 */           int[] arrayOfInt = new int[4];
/* 2176 */           arrayOfInt[0] = 6;
/* 2177 */           arrayOfInt[1] = 1200 + Index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2188 */           long data = Long.reverseBytes(Double.doubleToRawLongBits(NewValue));
/* 2189 */           arrayOfInt[2] = Integer.reverseBytes((int)(data >> 32L));
/* 2190 */           arrayOfInt[3] = Integer.reverseBytes((int)data);
/*      */           
/* 2192 */           standardCall(0, arrayOfInt, 4, "Unable to set FPAR_" + Index + ".", "FPAR_" + Index, "Kann FPAR_" + Index + " nicht setzen", "FPAR_" + Index, false, null);
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 2197 */         Values = new int[4];
/* 2198 */         Values[0] = 6;
/* 2199 */         Values[1] = 1100 + Index;
/* 2200 */         Values[2] = Float.floatToIntBits((float)NewValue);
/* 2201 */         standardCall(0, Values, 4, "Unable to set FPAR_" + Index + ".", "FPAR_" + Index, "Kann FPAR_" + Index + " nicht setzen", "FPAR_" + Index, false, null);
/*      */         break;
/*      */       
/*      */       case 0:
/* 2205 */         adwin_tcp_set_fpar_double(Index, NewValue);
/*      */         break;
/*      */       default:
/* 2208 */         if (this.adl != null) {
/* 2209 */           this.adl.leave();
/*      */         }
/* 2211 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2213 */     if (this.adl != null) {
/* 2214 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized int getProcessorType() throws ADwinCommunicationError {
/* 2219 */     if (this.adl != null) {
/* 2220 */       this.adl.enter("getProcessorType ()");
/*      */     }
/*      */     
/* 2223 */     if (adwin_tcp_or_udp() == 0) {
/* 2224 */       int RetVal = this.ati.processortype;
/* 2225 */       if (this.adl != null) {
/* 2226 */         this.adl.leave();
/*      */       }
/* 2228 */       return RetVal;
/*      */     } 
/*      */     
/* 2231 */     byte[] Result = getVersionInfo().getData();
/* 2232 */     if (extractInt(Result, 0) == -5) {
/* 2233 */       throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */     }
/* 2235 */     if (extractInt(Result, 0) > 0) {
/* 2236 */       throw new ADwinCommunicationError("Timeout on the ADwin-System", "Timeout auf dem ADwin-System", this.Language, 
/* 2237 */           extractInt(Result, 0));
/*      */     }
/* 2239 */     if (extractInt(Result, 0) != 0) {
/* 2240 */       throw new ADwinCommunicationError("Error " + extractInt(Result, 0), "Fehler " + extractInt(Result, 0), this.Language, 2000);
/*      */     }
/*      */     
/* 2243 */     int ProcessorType = extractInt(Result, 12);
/*      */     
/* 2245 */     switch (ProcessorType) {
/*      */ 
/*      */       
/*      */       case 146:
/* 2249 */         if (this.adl != null) {
/* 2250 */           this.adl.leave();
/*      */         }
/* 2252 */         return 5;
/*      */       case 1000:
/* 2254 */         if (this.adl != null) {
/* 2255 */           this.adl.leave();
/*      */         }
/* 2257 */         return 9;
/*      */       case 1010:
/* 2259 */         if (this.adl != null) {
/* 2260 */           this.adl.leave();
/*      */         }
/* 2262 */         return 10;
/*      */       case 1011:
/* 2264 */         if (this.adl != null) {
/* 2265 */           this.adl.leave();
/*      */         }
/* 2267 */         return 11;
/*      */     } 
/* 2269 */     if (this.adl != null) {
/* 2270 */       this.adl.leave();
/*      */     }
/* 2272 */     return ProcessorType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getCardType() throws ADwinCommunicationError {
/* 2278 */     if (adwin_tcp_or_udp() == 0) {
/* 2279 */       return -1;
/*      */     }
/*      */     
/* 2282 */     if (this.adl != null) {
/* 2283 */       this.adl.enter("getCardType ()");
/*      */     }
/* 2285 */     byte[] Result = getVersionInfo().getData();
/* 2286 */     if (this.adl != null) {
/* 2287 */       this.adl.leave();
/*      */     }
/* 2289 */     if (extractInt(Result, 0) == -5) {
/* 2290 */       throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */     }
/* 2292 */     if (extractInt(Result, 0) > 0) {
/* 2293 */       throw new ADwinCommunicationError("Timeout on the ADwin-System", "Timeout auf dem ADwin-System", this.Language, 
/* 2294 */           extractInt(Result, 0));
/*      */     }
/* 2296 */     if (extractInt(Result, 0) != 0) {
/* 2297 */       throw new ADwinCommunicationError("Error " + extractInt(Result, 0), "Fehler " + extractInt(Result, 0), this.Language, 2000);
/*      */     }
/*      */     
/* 2300 */     return extractInt(Result, 16);
/*      */   }
/*      */   public synchronized int getDriverVersion() throws ADwinCommunicationError {
/*      */     int values[], ret;
/* 2304 */     if (this.adl != null) {
/* 2305 */       this.adl.enter("getDriverVersion ()");
/*      */     }
/* 2307 */     switch (adwin_tcp_or_udp()) {
/*      */       case 0:
/* 2309 */         values = new int[4];
/* 2310 */         ret = adwin_tcp_testversion(values);
/* 2311 */         if (this.adl != null) {
/* 2312 */           this.adl.leave();
/*      */         }
/* 2314 */         return ret;
/*      */       case 1:
/* 2316 */         if (this.adl != null) {
/* 2317 */           this.adl.leave();
/*      */         }
/* 2319 */         return 3;
/*      */     } 
/* 2321 */     byte[] Result = getVersionInfo().getData();
/* 2322 */     if (this.adl != null) {
/* 2323 */       this.adl.leave();
/*      */     }
/* 2325 */     if (extractInt(Result, 0) == -5) {
/* 2326 */       throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */     }
/* 2328 */     if (extractInt(Result, 0) > 0) {
/* 2329 */       throw new ADwinCommunicationError("Timeout on the ADwin-System", "Timeout auf dem ADwin-System", this.Language, 
/* 2330 */           extractInt(Result, 0));
/*      */     }
/* 2332 */     if (extractInt(Result, 0) != 0) {
/* 2333 */       throw new ADwinCommunicationError("Error " + extractInt(Result, 0), "Fehler " + extractInt(Result, 0), this.Language, 2000);
/*      */     }
/*      */     
/* 2336 */     return extractInt(Result, 20);
/*      */   }
/*      */   
/*      */   public synchronized int test_version() throws ADwinCommunicationError {
/*      */     int[] values;
/* 2341 */     if (this.adl != null) {
/* 2342 */       this.adl.enter("test_version ()");
/*      */     }
/*      */     
/* 2345 */     switch (adwin_tcp_or_udp()) {
/*      */       case 0:
/* 2347 */         values = new int[4];
/* 2348 */         ret = adwin_tcp_testversion(values);
/* 2349 */         if (this.adl != null) {
/* 2350 */           this.adl.leave();
/*      */         }
/* 2352 */         return ret;
/*      */       case 1:
/* 2354 */         if (this.adl != null) {
/* 2355 */           this.adl.leave();
/*      */         }
/* 2357 */         return 3;
/*      */     } 
/* 2359 */     byte[] Result = getVersionInfo().getData();
/* 2360 */     if (this.adl != null) {
/* 2361 */       this.adl.leave();
/*      */     }
/* 2363 */     if (extractInt(Result, 0) == -5) {
/* 2364 */       throw new ADwinCommunicationError("Wrong password", "Falsches Passwort", this.Language, 2002);
/*      */     }
/* 2366 */     if (extractInt(Result, 0) > 0) {
/* 2367 */       throw new ADwinCommunicationError("Timeout on the ADwin-System", "Timeout auf dem ADwin-System", this.Language, 
/* 2368 */           extractInt(Result, 0));
/*      */     }
/* 2370 */     if (extractInt(Result, 0) != 0) {
/* 2371 */       throw new ADwinCommunicationError("Error " + extractInt(Result, 0), "Fehler " + extractInt(Result, 0), this.Language, 2000);
/*      */     }
/*      */     
/* 2374 */     int ret = extractInt(Result, 8);
/* 2375 */     if (ret == 118) {
/* 2376 */       return 0;
/*      */     }
/* 2378 */     return 3;
/*      */   }
/*      */ 
/*      */   
/*      */   int adwin_tcp_testversion(int[] values) throws ADwinCommunicationError {
/* 2383 */     init_ati(255);
/* 2384 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/* 2385 */     resp.max = 16;
/* 2386 */     resp.used = 0;
/* 2387 */     resp.do_convert = 1;
/* 2388 */     resp.data = new byte[16];
/*      */     
/* 2390 */     if (tcp_write_request(this.ati, null) == -1) {
/* 2391 */       return 3;
/*      */     }
/* 2393 */     if (tcp_read_response(this.ati, 16, resp) == -1) {
/* 2394 */       return 3;
/*      */     }
/*      */     
/* 2397 */     for (int i = 0; i < 4; i++) {
/* 2398 */       values[i] = extractInt(resp.data, i * 4);
/*      */     }
/* 2400 */     if (values[0] == 118) {
/* 2401 */       return 0;
/*      */     }
/* 2403 */     return 3;
/*      */   }
/*      */   public synchronized int[] getDataInt(int DataNr, int IndexFirst, int IndexLast) throws ADwinCommunicationError {
/*      */     DataToIntArray dtia;
/*      */     int[] idata;
/* 2408 */     if (this.adl != null) {
/* 2409 */       this.adl.enter("getDataInt (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ")");
/*      */     }
/* 2411 */     int count = IndexLast - IndexFirst + 1;
/*      */     
/* 2413 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2416 */         if (is_adwinx(this.version)) {
/* 2417 */           DataToIntArray dataToIntArray = (DataToIntArray)getDataADwinX(DataNr, IndexFirst, IndexLast, 3);
/* 2418 */           if (this.adl != null) {
/* 2419 */             this.adl.leave();
/*      */           }
/* 2421 */           return dataToIntArray.getArray();
/*      */         } 
/*      */         
/* 2424 */         dtia = (DataToIntArray)getData(DataNr, IndexFirst, IndexLast, 3);
/* 2425 */         if (this.adl != null) {
/* 2426 */           this.adl.leave();
/*      */         }
/* 2428 */         return dtia.getArray();
/*      */       case 0:
/* 2430 */         idata = new int[count];
/* 2431 */         adwin_tcp_get_data_or_fifo_int32(DataNr, idata, IndexFirst, count, 0);
/* 2432 */         return idata;
/*      */     } 
/* 2434 */     if (this.adl != null) {
/* 2435 */       this.adl.leave();
/*      */     }
/* 2437 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   public synchronized long[] getDataLong(int DataNr, int IndexFirst, int IndexLast) throws ADwinCommunicationError {
/*      */     DataToIntArray dtia;
/*      */     long[] tmp, idata;
/* 2442 */     if (this.adl != null) {
/* 2443 */       this.adl.enter("getDataInt (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ")");
/*      */     }
/* 2445 */     int count = IndexLast - IndexFirst + 1;
/*      */     
/* 2447 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2450 */         if (is_adwinx(this.version)) {
/* 2451 */           DataToInt64Array dataToInt64Array = (DataToInt64Array)getDataADwinX(DataNr, IndexFirst, IndexLast, 7);
/* 2452 */           if (this.adl != null) {
/* 2453 */             this.adl.leave();
/*      */           }
/* 2455 */           return dataToInt64Array.getArray();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2461 */         dtia = (DataToIntArray)getData(DataNr, IndexFirst, IndexLast, 3);
/* 2462 */         if (this.adl != null) {
/* 2463 */           this.adl.leave();
/*      */         }
/* 2465 */         tmp = new long[count];
/* 2466 */         convert_data_from_int_to_long(dtia.getArray(), tmp, count);
/* 2467 */         return tmp;
/*      */       case 0:
/* 2469 */         idata = new long[count];
/* 2470 */         adwin_tcp_get_data_or_fifo_int64(DataNr, idata, IndexFirst, count, 0);
/* 2471 */         return idata;
/*      */     } 
/* 2473 */     if (this.adl != null) {
/* 2474 */       this.adl.leave();
/*      */     }
/* 2476 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   public synchronized float[] getDataFloat(int DataNr, int IndexFirst, int IndexLast) throws ADwinCommunicationError {
/*      */     DataToFloatArray dtfa;
/*      */     float[] fdata;
/* 2481 */     if (this.adl != null) {
/* 2482 */       this.adl.enter("getDataFloat (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ")");
/*      */     }
/* 2484 */     int count = IndexLast - IndexFirst + 1;
/*      */     
/* 2486 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2489 */         if (is_adwinx(this.version)) {
/* 2490 */           DataToFloatArray dataToFloatArray = (DataToFloatArray)getDataADwinX(DataNr, IndexFirst, IndexLast, 5);
/* 2491 */           if (this.adl != null) {
/* 2492 */             this.adl.leave();
/*      */           }
/* 2494 */           return dataToFloatArray.getArray();
/*      */         } 
/*      */         
/* 2497 */         dtfa = (DataToFloatArray)getData(DataNr, IndexFirst, IndexLast, 5);
/* 2498 */         if (this.adl != null) {
/* 2499 */           this.adl.leave();
/*      */         }
/* 2501 */         return dtfa.getArray();
/*      */       case 0:
/* 2503 */         fdata = new float[count];
/* 2504 */         adwin_tcp_get_data_or_fifo_float(DataNr, fdata, IndexFirst, count, 0);
/* 2505 */         if (this.adl != null) {
/* 2506 */           this.adl.leave();
/*      */         }
/* 2508 */         return fdata;
/*      */     } 
/* 2510 */     if (this.adl != null) {
/* 2511 */       this.adl.leave();
/*      */     }
/* 2513 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   } public synchronized double[] getDataDouble(int DataNr, int IndexFirst, int IndexLast) throws ADwinCommunicationError {
/*      */     float[] fdata;
/*      */     double[] ddata;
/*      */     DataToFloatArray dtfa;
/* 2518 */     if (this.adl != null) {
/* 2519 */       this.adl.enter("getDataDouble (" + DataNr + ", " + IndexFirst + ", " + IndexLast + ")");
/*      */     }
/* 2521 */     int count = IndexLast - IndexFirst + 1;
/*      */ 
/*      */ 
/*      */     
/* 2525 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 2528 */         if (is_adwinx(this.version)) {
/* 2529 */           DataToDoubleArray dtda = (DataToDoubleArray)getDataADwinX(DataNr, IndexFirst, IndexLast, 6);
/* 2530 */           if (this.adl != null) {
/* 2531 */             this.adl.leave();
/*      */           }
/* 2533 */           return dtda.getArray();
/*      */         } 
/*      */         
/* 2536 */         ddata = new double[count];
/* 2537 */         dtfa = (DataToFloatArray)getData(DataNr, IndexFirst, IndexLast, 5);
/* 2538 */         if (this.adl != null) {
/* 2539 */           this.adl.leave();
/*      */         }
/*      */         
/* 2542 */         fdata = dtfa.getArray();
/* 2543 */         convert_data_from_float_to_double(fdata, ddata, count);
/* 2544 */         return ddata;
/*      */       case 0:
/* 2546 */         ddata = new double[count];
/* 2547 */         adwin_tcp_get_data_or_fifo_double(DataNr, ddata, IndexFirst, count, 0);
/* 2548 */         if (this.adl != null) {
/* 2549 */           this.adl.leave();
/*      */         }
/* 2551 */         return ddata;
/*      */     } 
/* 2553 */     if (this.adl != null) {
/* 2554 */       this.adl.leave();
/*      */     }
/* 2556 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   
/*      */   public synchronized int getDataType(int DataNr) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 2561 */     if (this.adl != null) {
/* 2562 */       this.adl.enter("getDataType (" + DataNr + ")");
/*      */     }
/*      */     
/* 2565 */     int DataType = 0;
/*      */     
/* 2567 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2569 */         Values = new int[4];
/* 2570 */         Values[0] = 7;
/* 2571 */         Values[1] = DataNr;
/* 2572 */         Values[2] = 1;
/* 2573 */         Values[3] = 0;
/*      */         
/* 2575 */         DataType = standardCall(100, Values, 8, "Unable to determine type of DATA_" + DataNr + ".", "type of DATA_" + DataNr, "Kann Typ von DATA_" + DataNr + " nicht bestimmen", "Typ von DATA_" + DataNr, false, null);
/*      */ 
/*      */         
/* 2578 */         if (DataType == 4) {
/* 2579 */           DataType = 3;
/*      */         }
/* 2581 */         if (DataType < 1 || DataType > 8) {
/*      */           
/* 2583 */           if (this.adl != null) {
/* 2584 */             this.adl.message("Datatype = " + DataType + " -> ADwinCommunicationError", 1);
/* 2585 */             this.adl.leave();
/*      */           } 
/* 2587 */           throw new ADwinCommunicationError("Unable to determine type of DATA_" + DataNr + ".", "Kann Typ von DATA_" + DataNr + " nicht bestimmen.", this.Language, 100);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 2593 */         DataType = adwin_tcp_get_data_type(DataNr);
/*      */         break;
/*      */       default:
/* 2596 */         if (this.adl != null) {
/* 2597 */           this.adl.leave();
/*      */         }
/* 2599 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2601 */     if (this.adl != null) {
/* 2602 */       this.adl.leave();
/*      */     }
/* 2604 */     return DataType;
/*      */   }
/*      */   
/*      */   public synchronized int getDataLength(int DataNr) throws ADwinCommunicationError {
/* 2608 */     int Values[], RetVal = 0;
/*      */     
/* 2610 */     if (this.adl != null) {
/* 2611 */       this.adl.enter("getDatalength (" + DataNr + ")");
/*      */     }
/*      */     
/* 2614 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2616 */         Values = new int[4];
/* 2617 */         Values[0] = 11;
/* 2618 */         Values[1] = DataNr;
/* 2619 */         RetVal = standardCall(0, Values, 8, "Unable to determine length of DATA_" + DataNr + ".", "length of DATA_" + DataNr, "Kann  Länge von DATA_" + DataNr + " nicht bestimmen", "Länge von DATA_" + DataNr, false, null);
/*      */ 
/*      */         
/* 2622 */         if (RetVal == 0) {
/* 2623 */           if (this.adl != null) {
/* 2624 */             this.adl.message("Datalength == 0 -> ADwinCommunicationError", 1);
/* 2625 */             this.adl.leave();
/*      */           } 
/* 2627 */           throw new ADwinCommunicationError("Unable to determine length of DATA_" + DataNr + ".", "Kann Länge von DATA_" + DataNr + " nicht bestimmen.", this.Language, 100);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 2633 */         RetVal = adwin_tcp_get_data_length(DataNr);
/*      */         break;
/*      */       default:
/* 2636 */         if (this.adl != null) {
/* 2637 */           this.adl.leave();
/*      */         }
/* 2639 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/*      */     
/* 2642 */     if (this.adl != null) {
/* 2643 */       this.adl.leave();
/*      */     }
/* 2645 */     return RetVal;
/*      */   }
/*      */   
/*      */   public synchronized void startProcess(int ProcessNo) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 2650 */     if (this.adl != null) {
/* 2651 */       this.adl.enter("startProcess (" + ProcessNo + ")");
/*      */     }
/*      */     
/* 2654 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2656 */         Values = new int[4];
/* 2657 */         Values[0] = 2;
/* 2658 */         Values[1] = ProcessNo;
/* 2659 */         Values[2] = 0;
/*      */         
/* 2661 */         standardCall(0, Values, 4, "Cannot start process " + ProcessNo, "starting process " + ProcessNo, "Kann Prozess " + ProcessNo + " nicht starten", "Starten von Prozess " + ProcessNo, false, null);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 2666 */         adwin_tcp_start_process(ProcessNo);
/*      */         break;
/*      */       default:
/* 2669 */         if (this.adl != null) {
/* 2670 */           this.adl.leave();
/*      */         }
/* 2672 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/*      */     
/* 2675 */     if (this.adl != null)
/* 2676 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void loadProcessFile(String FileName) throws IOException, ADwinCommunicationError { FileInputStream fis;
/*      */     byte[] Binary;
/* 2681 */     int t_pos = 3;
/* 2682 */     if (is_adwinx(this.version)) {
/* 2683 */       t_pos = 4;
/*      */     }
/* 2685 */     if (this.adl != null) {
/* 2686 */       this.adl.enter("loadProcess (" + FileName + ")");
/*      */     }
/* 2688 */     char c = FileName.charAt(FileName.length() - t_pos);
/* 2689 */     if (FileName == null || FileName.length() < 4 || (c != 't' && c != 'T')) {
/* 2690 */       if (this.adl != null) {
/* 2691 */         this.adl.leave();
/*      */       }
/* 2693 */       throw new ADwinCommunicationError("Filename " + FileName + " not in ADBasic executable file format (<fffff>.T<x><n> - <fff> = program name, <x> = processor, <n> = process no.)", "Dateiname " + FileName + " nicht im Format für ADBasic Binärdateien (<fffff>.T<x><n> - <fffff> = Programmname, <x> = Prozessor, <n> = Prozessnummer", this.Language, 202);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2698 */     int FileProcID = FileName.charAt(FileName.length() - 2);
/* 2699 */     if ((FileProcID < 48 || FileProcID > 57) && (FileProcID < 65 || FileProcID > 69) && (FileProcID < 97 || FileProcID > 101)) {
/*      */ 
/*      */       
/* 2702 */       if (this.adl != null) {
/* 2703 */         this.adl.leave();
/*      */       }
/* 2705 */       throw new ADwinCommunicationError("Filename " + FileName + " not in ADBasic executable file format (<fffff>.T<x><n> - <fff> = program name, <x> = processor, <n> = process no.)", "Dateiname " + FileName + " nicht im Format für ADBasic Binärdateien (<fffff>.T<x><n> - <fffff> = Programmname, <x> = Prozessor, <n> = Prozessnummer", this.Language, 202);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2710 */     if (this.ati.processortype == -1) {
/* 2711 */       this.ati.processortype = getProcessorType();
/*      */     }
/* 2713 */     switch (this.ati.processortype) {
/*      */       case 8:
/* 2715 */         if (FileProcID != 56) {
/* 2716 */           throw new ADwinCommunicationError("ADbasic-file is for another processor-type!", "ADbasic-Binärdatei ist für den falschen Prozessor!", this.Language, 205);
/*      */         }
/*      */         break;
/*      */       case 9:
/* 2720 */         if (FileProcID != 57) {
/* 2721 */           throw new ADwinCommunicationError("ADbasic-file is for another processor-type!", "ADbasic-Binärdatei ist für den falschen Prozessor!", this.Language, 205);
/*      */         }
/*      */         break;
/*      */       case 1010:
/* 2725 */         if (FileProcID != 97 && FileProcID != 65) {
/* 2726 */           throw new ADwinCommunicationError("ADbasic-file is for another processor-type!", "ADbasic-Binärdatei ist für den falschen Prozessor!", this.Language, 205);
/*      */         }
/*      */         break;
/*      */       case 1011:
/* 2730 */         if (FileProcID != 98 && FileProcID != 66) {
/* 2731 */           throw new ADwinCommunicationError("ADbasic-file is for another processor-type!", "ADbasic-Binärdatei ist für den falschen Prozessor!", this.Language, 205);
/*      */         }
/*      */         break;
/*      */       case 1012:
/* 2735 */         if (FileProcID != 99 && FileProcID != 67) {
/* 2736 */           throw new ADwinCommunicationError("ADbasic-file is for another processor-type!", "ADbasic-Binärdatei ist für den falschen Prozessor!", this.Language, 205);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 2742 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2744 */         fis = new FileInputStream(FileName);
/* 2745 */         Binary = new byte[fis.available()];
/* 2746 */         fis.read(Binary);
/* 2747 */         fis.close();
/* 2748 */         if (Binary.length == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 2752 */         loadProcessArray(Binary, FileName);
/*      */         break;
/*      */       case 0:
/* 2755 */         adwin_tcp_load_process(FileName);
/*      */         break;
/*      */       default:
/* 2758 */         if (this.adl != null) {
/* 2759 */           this.adl.leave();
/*      */         }
/* 2761 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2763 */     if (this.adl != null)
/* 2764 */       this.adl.leave();  } public synchronized void loadProcessArray(byte[] process, String fileName) throws ADwinCommunicationError, IOException {
/*      */     byte[] ConfirmationData;
/*      */     DatagramPacket ConfPacket;
/*      */     int[] requestIndex;
/*      */     int[] Values;
/* 2769 */     if (this.adl != null) {
/* 2770 */       this.adl.enter("loadProcessArray (byte[], \"" + fileName + "\")");
/*      */     }
/*      */     
/* 2773 */     switch (adwin_tcp_or_udp())
/*      */     { case 2:
/* 2775 */         ConfirmationData = new byte[32];
/* 2776 */         ConfPacket = new DatagramPacket(ConfirmationData, 32);
/* 2777 */         requestIndex = new int[1];
/*      */         
/* 2779 */         Values = new int[4];
/*      */         
/* 2781 */         Values[0] = 0;
/*      */         
/* 2783 */         Values[1] = this.DataBlockSize << 16;
/*      */         
/* 2785 */         Values[2] = 9;
/* 2786 */         Values[3] = process.length;
/* 2787 */         synchronized (this.ds)
/* 2788 */         { standardCall(4, Values, 4, "Cannot start loading process " + fileName, "loading process " + fileName, "Kann nicht damit beginnen, Prozess " + fileName + " zu laden", "Laden von Prozess " + fileName, false, requestIndex);
/*      */ 
/*      */ 
/*      */           
/* 2792 */           DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/* 2793 */           dft.send(process.length, process, "Process " + fileName, requestIndex[0]);
/*      */           
/* 2795 */           int TimeoutsOccured = 0;
/*      */           while (true)
/*      */           { try {
/* 2798 */               this.ds.receive(ConfPacket);
/* 2799 */               TimeoutsOccured = 0;
/* 2800 */             } catch (SocketTimeoutException ste) {
/* 2801 */               if (this.adl != null) {
/* 2802 */                 this.adl.message("Timeout when receiving confirmation...", 50);
/*      */               }
/* 2804 */               TimeoutsOccured++;
/* 2805 */               if (TimeoutsOccured > this.AllowedErrors) {
/* 2806 */                 if (this.adl != null) {
/* 2807 */                   this.adl.message("Too many timeouts -> ADwinCommunicationError...", 1);
/*      */                   
/* 2809 */                   this.adl.leave();
/*      */                 } 
/* 2811 */                 throw new ADwinCommunicationError("Process could not be loaded, " + ste
/* 2812 */                     .getMessage(), "Prozess konnte nicht geladen werden, " + ste.getMessage(), this.Language, 2001);
/*      */               } 
/*      */             } 
/*      */             
/* 2816 */             if (TimeoutsOccured <= 0)
/*      */             
/* 2818 */             { if (extractInt(ConfirmationData, 0) != 0) {
/* 2819 */                 if (this.adl != null) {
/* 2820 */                   this.adl.message("Errorcode " + extractInt(ConfirmationData, 0) + " -> ADwinCommunicationError", 1);
/*      */                   
/* 2822 */                   this.adl.leave();
/*      */                 } 
/* 2824 */                 if (extractInt(ConfirmationData, 0) == -35) {
/* 2825 */                   throw new ADwinCommunicationError("The binary file has been built for different processor", "Die Binaerdatei wurde fuer einen anderen Prozessor erzeugt", this.Language, 205);
/*      */                 }
/*      */                 
/* 2828 */                 if (extractInt(ConfirmationData, 0) == -100) {
/* 2829 */                   throw new ADwinCommunicationError("Not enough memory or memory damaged", "Nicht genug Speicher frei oder Speicher beschädigt", this.Language, 150);
/*      */                 }
/*      */ 
/*      */                 
/* 2833 */                 throw new ADwinCommunicationError("Error " + extractInt(ConfirmationData, 0) + " occured after loading " + fileName + ".", "Fehler " + 
/* 2834 */                     extractInt(ConfirmationData, 0) + " nach dem Laden von " + fileName + " aufgetreten", this.Language, 
/* 2835 */                     extractInt(ConfirmationData, 0));
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2849 */               if (this.adl != null)
/* 2850 */                 this.adl.leave();  return; }  }  } case 0: adwin_tcp_load_process(process); break;default: if (this.adl != null) this.adl.leave();  throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000); }  if (this.adl != null) this.adl.leave();
/*      */   
/*      */   }
/*      */   
/*      */   public boolean is_adwinx(int version) {
/* 2855 */     return (version >= 400 && version < 500);
/*      */   }
/*      */   
/*      */   public synchronized void setDataByteADwinX(int DataNr, byte[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError {
/* 2859 */     if (this.adl != null) {
/* 2860 */       this.adl.enter("setDataByte (" + DataNr + ", <int[]>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */ 
/*      */     
/* 2864 */     if (Count <= 0 || Count > DataContents.length) {
/* 2865 */       if (this.adl != null) {
/* 2866 */         this.adl.leave();
/*      */       }
/* 2868 */       throw new IllegalArgumentException((this.Language == 1) ? "The passed array is too small for the given range" : 
/* 2869 */           "Das übergebene Array ist zu klein für den angegebenen Bereich");
/*      */     } 
/*      */     
/* 2872 */     int DestType = getDataType(DataNr);
/* 2873 */     if (DestType != 8 && DestType != 1) {
/* 2874 */       if (this.adl != null) {
/* 2875 */         this.adl.leave();
/*      */       }
/*      */       
/* 2878 */       throw new ADwinCommunicationError("Data ist too small", "Data zu klein", this.Language, 100);
/*      */     } 
/*      */ 
/*      */     
/* 2882 */     setData(DataContents, DataNr, IndexFirst, IndexFirst + Count - 1, 1);
/*      */     
/* 2884 */     if (this.adl != null)
/* 2885 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized void setDataInt(int DataNr, int[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError { int DestType;
/*      */     byte[] DataBytes;
/*      */     int n;
/* 2890 */     if (this.adl != null) {
/* 2891 */       this.adl.enter("setDataInt (" + DataNr + ", <int[]>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */ 
/*      */     
/* 2895 */     if (Count <= 0 || Count > DataContents.length) {
/* 2896 */       if (this.adl != null) {
/* 2897 */         this.adl.leave();
/*      */       }
/* 2899 */       throw new IllegalArgumentException((this.Language == 1) ? "The passed array is too small for the given range" : 
/* 2900 */           "Das übergebene Array ist zu klein für den angegebenen Bereich");
/*      */     } 
/*      */     
/* 2903 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2905 */         DestType = getDataType(DataNr);
/* 2906 */         if (DestType == 4) {
/* 2907 */           DestType = 3;
/*      */         }
/* 2909 */         if (DestType < 3 || DestType > 6) {
/* 2910 */           if (this.adl != null) {
/* 2911 */             this.adl.leave();
/*      */           }
/* 2913 */           throw new ADwinCommunicationError("Data ist too small", "Data zu klein", this.Language, 100);
/*      */         } 
/*      */         
/* 2916 */         DataBytes = new byte[Count * 4];
/*      */         
/* 2918 */         switch (DestType) {
/*      */           case 3:
/*      */           case 6:
/* 2921 */             for (n = 0; n < Count; n++) {
/* 2922 */               setInteger(DataBytes, n * 4, DataContents[n]);
/*      */             }
/*      */             break;
/*      */           case 5:
/* 2926 */             for (n = 0; n < Count; n++) {
/* 2927 */               setInteger(DataBytes, n * 4, Float.floatToIntBits(DataContents[n]));
/*      */             }
/*      */             break;
/*      */         } 
/*      */         
/* 2932 */         if (is_adwinx(this.version)) {
/* 2933 */           int type = 0;
/* 2934 */           if (DestType == 6) type = 3; 
/* 2935 */           setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, type); break;
/*      */         } 
/* 2937 */         setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, 3);
/*      */         break;
/*      */       
/*      */       case 0:
/* 2941 */         adwin_tcp_set_data_or_fifo_int32(DataNr, DataContents, IndexFirst, Count, 0);
/*      */         break;
/*      */       default:
/* 2944 */         if (this.adl != null) {
/* 2945 */           this.adl.leave();
/*      */         }
/* 2947 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 2949 */     if (this.adl != null)
/* 2950 */       this.adl.leave();  } public synchronized void setDataLong(int DataNr, long[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     int DestType;
/*      */     byte[] DataBytes;
/*      */     int n;
/*      */     int[] tmp;
/* 2955 */     if (this.adl != null) {
/* 2956 */       this.adl.enter("setDataLong (" + DataNr + ", <int[]>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */ 
/*      */     
/* 2960 */     if (Count <= 0 || Count > DataContents.length) {
/* 2961 */       if (this.adl != null) {
/* 2962 */         this.adl.leave();
/*      */       }
/* 2964 */       throw new IllegalArgumentException((this.Language == 1) ? "The passed array is too small for the given range" : 
/* 2965 */           "Das übergebene Array ist zu klein für den angegebenen Bereich");
/*      */     } 
/*      */     
/* 2968 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 2970 */         DestType = getDataType(DataNr);
/* 2971 */         if (DestType == 4) {
/* 2972 */           DestType = 3;
/*      */         }
/* 2974 */         if (DestType < 3 || DestType > 7) {
/* 2975 */           if (this.adl != null) {
/* 2976 */             this.adl.leave();
/*      */           }
/* 2978 */           throw new ADwinCommunicationError("Data ist too small", "Data zu klein", this.Language, 100);
/*      */         } 
/*      */ 
/*      */         
/* 2982 */         if (DestType == 6 || DestType == 7) {
/* 2983 */           DataBytes = new byte[Count * 8];
/*      */         } else {
/* 2985 */           DataBytes = new byte[Count * 4];
/*      */         } 
/* 2987 */         switch (DestType) {
/*      */           case 3:
/*      */           case 6:
/* 2990 */             for (n = 0; n < Count; n++) {
/* 2991 */               setInteger(DataBytes, n * 4, (int)DataContents[n]);
/*      */             }
/*      */             break;
/*      */           case 5:
/* 2995 */             for (n = 0; n < Count; n++) {
/* 2996 */               setInteger(DataBytes, n * 4, Float.floatToIntBits((float)DataContents[n]));
/*      */             }
/*      */             break;
/*      */           case 7:
/* 3000 */             for (n = 0; n < Count; n++) {
/* 3001 */               setLong(DataBytes, n * 8, DataContents[n]);
/*      */             }
/*      */             break;
/*      */         } 
/*      */         
/* 3006 */         if (is_adwinx(this.version)) {
/* 3007 */           int type = 0;
/* 3008 */           if (DestType == 6) type = 3; 
/* 3009 */           setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, type); break;
/*      */         } 
/* 3011 */         setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, 3);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 3016 */         tmp = new int[Count];
/* 3017 */         convert_data_from_long_to_int(DataContents, tmp, Count);
/* 3018 */         adwin_tcp_set_data_or_fifo_int32(DataNr, tmp, IndexFirst, Count, 0);
/*      */         break;
/*      */       default:
/* 3021 */         if (this.adl != null) {
/* 3022 */           this.adl.leave();
/*      */         }
/* 3024 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3026 */     if (this.adl != null)
/* 3027 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized void setDataFloat(int DataNr, float[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     int DestType;
/*      */     byte[] DataBytes;
/* 3032 */     if (this.adl != null) {
/* 3033 */       this.adl.enter("setDataFloat (" + DataNr + ", <float []>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */     
/* 3036 */     if (Count <= 0 || Count > DataContents.length) {
/* 3037 */       if (this.adl != null) {
/* 3038 */         this.adl.leave();
/*      */       }
/* 3040 */       throw new IllegalArgumentException((this.Language == 1) ? "The array passed is too small for the given range" : 
/* 3041 */           "Das übergebene Array ist zu klein für den angegebenen Bereich");
/*      */     } 
/*      */     
/* 3044 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3046 */         DestType = getDataType(DataNr);
/* 3047 */         if (DestType == 4) {
/* 3048 */           DestType = 3;
/*      */         }
/* 3050 */         if (DestType < 3 || DestType > 6) {
/* 3051 */           if (this.adl != null) {
/* 3052 */             this.adl.leave();
/*      */           }
/* 3054 */           throw new ADwinCommunicationError("Data ist too small", "Data zu klein", this.Language, 100);
/*      */         } 
/* 3056 */         DataBytes = new byte[Count * 4];
/*      */         
/* 3058 */         if (DestType == 5 || DestType == 6) {
/* 3059 */           for (int n = 0; n < Count; n++) {
/* 3060 */             setInteger(DataBytes, n * 4, Float.floatToIntBits(DataContents[n]));
/*      */           }
/*      */         } else {
/* 3063 */           for (int n = 0; n < Count; n++) {
/* 3064 */             setInteger(DataBytes, n * 4, (int)DataContents[n]);
/*      */           }
/*      */         } 
/* 3067 */         if (is_adwinx(this.version)) {
/* 3068 */           int type = 0;
/* 3069 */           if (DestType == 6) type = 5; 
/* 3070 */           setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, type); break;
/*      */         } 
/* 3072 */         setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, 5);
/*      */         break;
/*      */       case 0:
/* 3075 */         adwin_tcp_set_data_or_fifo_float(DataNr, DataContents, IndexFirst, Count, 0);
/*      */         break;
/*      */       default:
/* 3078 */         if (this.adl != null) {
/* 3079 */           this.adl.leave();
/*      */         }
/* 3081 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3083 */     if (this.adl != null)
/* 3084 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void setDataDouble(int DataNr, double[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     float[] fdata;
/* 3089 */     if (this.adl != null) {
/* 3090 */       this.adl.enter("setDataDouble (" + DataNr + ", <double []>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */     
/* 3093 */     if (Count <= 0 || Count > DataContents.length) {
/* 3094 */       if (this.adl != null) {
/* 3095 */         this.adl.leave();
/*      */       }
/* 3097 */       throw new IllegalArgumentException((this.Language == 1) ? "The array passed is too small for the given range" : 
/* 3098 */           "Das übergebene Array ist zu klein für den angegebenen Bereich");
/*      */     } 
/*      */     
/* 3101 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3103 */         if (is_adwinx(this.version)) {
/* 3104 */           setDataDoubleADwinX(DataNr, DataContents, IndexFirst, Count);
/*      */           break;
/*      */         } 
/* 3107 */         fdata = new float[Count];
/* 3108 */         convert_data_from_double_to_float(DataContents, fdata, Count);
/* 3109 */         setDataFloat(DataNr, fdata, IndexFirst, Count);
/*      */         break;
/*      */       
/*      */       case 0:
/* 3113 */         adwin_tcp_set_data_or_fifo_double(DataNr, DataContents, IndexFirst, Count, 0);
/*      */         break;
/*      */       default:
/* 3116 */         if (this.adl != null) {
/* 3117 */           this.adl.leave();
/*      */         }
/* 3119 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3121 */     if (this.adl != null)
/* 3122 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized void setDataDoubleADwinX(int DataNr, double[] DataContents, int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     byte[] DataBytes;
/*      */     int n;
/* 3127 */     if (this.adl != null) {
/* 3128 */       this.adl.enter("setDataFloat (" + DataNr + ", <float []>, " + IndexFirst + ", " + Count + ")");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3133 */     int DestType = getDataType(DataNr);
/* 3134 */     if (DestType == 4) {
/* 3135 */       DestType = 3;
/*      */     }
/* 3137 */     switch (DestType) {
/*      */       case 3:
/* 3139 */         DataBytes = new byte[Count * 4];
/* 3140 */         for (n = 0; n < Count; n++) {
/* 3141 */           setInteger(DataBytes, n * 4, (int)DataContents[n]);
/*      */         }
/*      */         break;
/*      */       case 5:
/* 3145 */         DataBytes = new byte[Count * 4];
/* 3146 */         for (n = 0; n < Count; n++) {
/* 3147 */           setInteger(DataBytes, n * 4, Float.floatToIntBits((float)DataContents[n]));
/*      */         }
/*      */         break;
/*      */       case 6:
/* 3151 */         DataBytes = new byte[Count * 8];
/* 3152 */         convert_data_from_double_to_stream(DataContents, DataBytes, Count);
/*      */         break;
/*      */       default:
/* 3155 */         if (this.adl != null) {
/* 3156 */           this.adl.leave();
/*      */         }
/* 3158 */         throw new ADwinCommunicationError("Data ist too small", "Data zu klein", this.Language, 100);
/*      */     } 
/*      */     
/* 3161 */     if (is_adwinx(this.version)) {
/* 3162 */       int type = 0;
/* 3163 */       if (DestType == 6) type = 6; 
/* 3164 */       setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, type);
/*      */     } else {
/* 3166 */       setData(DataBytes, DataNr, IndexFirst, IndexFirst + Count - 1, 5);
/*      */     } 
/*      */     
/* 3169 */     if (this.adl != null)
/* 3170 */       this.adl.leave(); 
/*      */   } public synchronized int[] getFifoInt(int FifoNr, int Count) throws ADwinCommunicationError {
/*      */     int SourceType;
/*      */     DataToIntArray dtia;
/*      */     int[] idata;
/* 3175 */     if (this.adl != null) {
/* 3176 */       this.adl.enter("getFifoInt (" + FifoNr + ", " + Count + ")");
/*      */     }
/*      */     
/* 3179 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3181 */         SourceType = getDataType(FifoNr);
/* 3182 */         if (SourceType == 4) {
/* 3183 */           SourceType = 3;
/*      */         }
/* 3185 */         if (SourceType < 3 || SourceType > 6) {
/* 3186 */           throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 102);
/*      */         }
/* 3188 */         dtia = new DataToIntArray(Count, SourceType);
/*      */         
/* 3190 */         if (is_adwinx(this.version)) {
/* 3191 */           int type = 0;
/* 3192 */           if (SourceType == 6)
/* 3193 */             type = 6; 
/* 3194 */           readFifo(FifoNr, Count, dtia, type);
/*      */         } else {
/* 3196 */           readFifo(FifoNr, Count, dtia, SourceType);
/*      */         } 
/* 3198 */         if (this.adl != null) {
/* 3199 */           this.adl.leave();
/*      */         }
/* 3201 */         return dtia.getArray();
/*      */       case 0:
/* 3203 */         idata = new int[Count];
/* 3204 */         adwin_tcp_get_data_or_fifo_int32(FifoNr, idata, 1, Count, 1);
/* 3205 */         if (this.adl != null) {
/* 3206 */           this.adl.leave();
/*      */         }
/* 3208 */         return idata;
/*      */     } 
/* 3210 */     if (this.adl != null) {
/* 3211 */       this.adl.leave();
/*      */     }
/* 3213 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   } public synchronized float[] getFifoFloat(int FifoNr, int Count) throws ADwinCommunicationError {
/*      */     int SourceType;
/*      */     DataToFloatArray dtfa;
/*      */     float[] fdata;
/* 3218 */     if (this.adl != null) {
/* 3219 */       this.adl.enter("getFifoInt (" + FifoNr + ", " + Count + ")");
/*      */     }
/*      */     
/* 3222 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3224 */         SourceType = getDataType(FifoNr);
/* 3225 */         if (SourceType < 3 || SourceType > 6) {
/* 3226 */           throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 102);
/*      */         }
/*      */         
/* 3229 */         if (SourceType == 4) {
/* 3230 */           SourceType = 3;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3237 */         dtfa = new DataToFloatArray(Count, SourceType);
/*      */         
/* 3239 */         if (is_adwinx(this.version)) {
/* 3240 */           if (SourceType != 6)
/* 3241 */             SourceType = 0; 
/* 3242 */           readFifo(FifoNr, Count, dtfa, SourceType);
/*      */         } else {
/* 3244 */           readFifo(FifoNr, Count, dtfa, SourceType);
/*      */         } 
/* 3246 */         if (this.adl != null) {
/* 3247 */           this.adl.leave();
/*      */         }
/* 3249 */         return dtfa.getArray();
/*      */       case 0:
/* 3251 */         fdata = new float[Count];
/* 3252 */         adwin_tcp_get_data_or_fifo_float(FifoNr, fdata, 1, Count, 1);
/* 3253 */         if (this.adl != null) {
/* 3254 */           this.adl.leave();
/*      */         }
/* 3256 */         return fdata;
/*      */     } 
/* 3258 */     if (this.adl != null) {
/* 3259 */       this.adl.leave();
/*      */     }
/* 3261 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized double[] getFifoDoubleADwinX(int FifoNr, int Count) throws ADwinCommunicationError {
/* 3266 */     if (this.adl != null) {
/* 3267 */       this.adl.enter("getFifoFloat (" + FifoNr + ", " + Count + ")");
/*      */     }
/*      */     
/* 3270 */     int SourceType = getDataType(FifoNr);
/* 3271 */     if (SourceType == 4) {
/* 3272 */       SourceType = 3;
/*      */     }
/* 3274 */     if (SourceType < 3 || SourceType > 6) {
/* 3275 */       throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 102);
/*      */     }
/* 3277 */     DataToDoubleArray dtda = new DataToDoubleArray(Count, SourceType);
/*      */     
/* 3279 */     readFifo(FifoNr, Count, dtda, SourceType);
/* 3280 */     if (this.adl != null) {
/* 3281 */       this.adl.leave();
/*      */     }
/* 3283 */     return dtda.getArray();
/*      */   } public synchronized double[] getFifoDouble(int FifoNr, int Count) throws ADwinCommunicationError {
/*      */     double[] ddata;
/*      */     float[] fdata;
/* 3287 */     if (this.adl != null) {
/* 3288 */       this.adl.enter("getFifoDouble (" + FifoNr + ", " + Count + ")");
/*      */     }
/*      */     
/* 3291 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3293 */         if (is_adwinx(this.version)) {
/* 3294 */           double[] arrayOfDouble = getFifoDoubleADwinX(FifoNr, Count);
/*      */           break;
/*      */         } 
/* 3297 */         ddata = new double[Count];
/* 3298 */         fdata = getFifoFloat(FifoNr, Count);
/* 3299 */         convert_data_from_float_to_double(fdata, ddata, Count);
/*      */         break;
/*      */       case 0:
/* 3302 */         ddata = new double[Count];
/* 3303 */         adwin_tcp_get_data_or_fifo_double(FifoNr, ddata, 1, Count, 1);
/*      */         break;
/*      */       default:
/* 3306 */         if (this.adl != null) {
/* 3307 */           this.adl.leave();
/*      */         }
/* 3309 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3311 */     if (this.adl != null) {
/* 3312 */       this.adl.leave();
/*      */     }
/* 3314 */     return ddata;
/*      */   }
/*      */   public synchronized void setFifoInt(int FifoNr, int Count, int[] Data) throws ADwinCommunicationError {
/*      */     int n;
/* 3318 */     if (this.adl != null) {
/* 3319 */       this.adl.enter("setFifoInt (" + FifoNr + ", " + Count + ", <int []>)");
/*      */     }
/*      */     
/* 3322 */     if (adwin_tcp_or_udp() == 0) {
/* 3323 */       adwin_tcp_set_data_or_fifo_int32(FifoNr, Data, 1, Count, 1);
/* 3324 */       if (this.adl != null) {
/* 3325 */         this.adl.leave();
/*      */       }
/*      */       return;
/*      */     } 
/* 3329 */     int DestType = getDataType(FifoNr);
/* 3330 */     if (DestType == 4) {
/* 3331 */       DestType = 3;
/*      */     }
/* 3333 */     if (DestType < 3 || DestType > 6) {
/* 3334 */       throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 101);
/*      */     }
/*      */     
/* 3337 */     byte[] FifoData = new byte[Count * 4];
/* 3338 */     switch (DestType) {
/*      */       case 3:
/*      */       case 6:
/* 3341 */         for (n = 0; n < Count; n++) {
/* 3342 */           setInteger(FifoData, n * 4, Data[n]);
/*      */         }
/*      */         break;
/*      */       case 5:
/* 3346 */         for (n = 0; n < Count; n++) {
/* 3347 */           setInteger(FifoData, n * 4, Float.floatToIntBits(Data[n]));
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/* 3352 */     int NumBlocks = (Count - 1) / (this.DataBlockSize + 1) * 350 + 1;
/* 3353 */     int WordsSent = 0;
/*      */ 
/*      */     
/* 3356 */     for (int i = 0; i < NumBlocks; i++) {
/* 3357 */       int WordsToSend; if (i != NumBlocks - 1) {
/* 3358 */         WordsToSend = 350 * (this.DataBlockSize + 1);
/*      */       } else {
/* 3360 */         WordsToSend = Count % 350 * (this.DataBlockSize + 1);
/*      */       } 
/* 3362 */       if (WordsToSend == 0) {
/* 3363 */         WordsToSend = 350 * (this.DataBlockSize + 1);
/*      */       }
/*      */       
/* 3366 */       if (is_adwinx(this.version)) {
/* 3367 */         int type = 0;
/* 3368 */         if (DestType == 6)
/* 3369 */           type = 3; 
/* 3370 */         writeFifo(FifoNr, type, WordsToSend, WordsToSend, FifoData, WordsSent * 4);
/*      */       } else {
/* 3372 */         writeFifo(FifoNr, 2, WordsToSend, WordsToSend, FifoData, WordsSent * 4);
/* 3373 */       }  WordsSent += WordsToSend;
/*      */     } 
/* 3375 */     if (this.adl != null)
/* 3376 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void setFifoFloat(int FifoNr, int Count, float[] Data) throws ADwinCommunicationError {
/*      */     int n;
/* 3381 */     if (this.adl != null) {
/* 3382 */       this.adl.enter("setFifoFloat (" + FifoNr + ", " + Count + ", <float[]>)");
/*      */     }
/*      */     
/* 3385 */     if (adwin_tcp_or_udp() == 0) {
/* 3386 */       adwin_tcp_set_data_or_fifo_float(FifoNr, Data, 1, Count, 1);
/* 3387 */       if (this.adl != null) {
/* 3388 */         this.adl.leave();
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/* 3393 */     int DestType = getDataType(FifoNr);
/* 3394 */     if (DestType < 3 || DestType > 6) {
/* 3395 */       throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 101);
/*      */     }
/* 3397 */     byte[] FifoData = new byte[Count * 4];
/* 3398 */     switch (DestType) {
/*      */       case 3:
/* 3400 */         for (n = 0; n < Count; n++) {
/* 3401 */           setInteger(FifoData, n * 4, (int)Data[n]);
/*      */         }
/*      */         break;
/*      */       case 5:
/*      */       case 6:
/* 3406 */         for (n = 0; n < Count; n++) {
/* 3407 */           setInteger(FifoData, n * 4, Float.floatToIntBits(Data[n]));
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/* 3412 */     int NumBlocks = (Count - 1) / (this.DataBlockSize + 1) * 350 + 1;
/* 3413 */     int WordsSent = 0;
/*      */ 
/*      */     
/* 3416 */     for (int i = 0; i < NumBlocks; i++) {
/* 3417 */       int WordsToSend; if (i != NumBlocks - 1) {
/* 3418 */         WordsToSend = 350 * (this.DataBlockSize + 1);
/*      */       } else {
/* 3420 */         WordsToSend = Count % 350 * (this.DataBlockSize + 1);
/*      */       } 
/* 3422 */       if (WordsToSend == 0) {
/* 3423 */         WordsToSend = 350 * (this.DataBlockSize + 1);
/*      */       }
/*      */       
/* 3426 */       if (is_adwinx(this.version)) {
/* 3427 */         int type = 0;
/* 3428 */         if (DestType == 6)
/* 3429 */           type = 5; 
/* 3430 */         writeFifo(FifoNr, type, WordsToSend, WordsToSend, FifoData, WordsSent * 4);
/*      */       } else {
/* 3432 */         writeFifo(FifoNr, 2, WordsToSend, WordsToSend, FifoData, WordsSent * 4);
/* 3433 */       }  WordsSent += WordsToSend;
/*      */     } 
/* 3435 */     if (this.adl != null)
/* 3436 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void setFifoDouble(int FifoNr, int Count, double[] Data) throws ADwinCommunicationError {
/*      */     float[] fdata;
/* 3441 */     if (this.adl != null) {
/* 3442 */       this.adl.enter("setFifoDouble (" + FifoNr + ", " + Count + ", <double[]>)");
/*      */     }
/*      */     
/* 3445 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3447 */         if (is_adwinx(this.version)) {
/* 3448 */           setFifoDoubleADwinX(FifoNr, Count, Data);
/*      */           break;
/*      */         } 
/* 3451 */         fdata = new float[Count];
/* 3452 */         convert_data_from_double_to_float(Data, fdata, Count);
/* 3453 */         setFifoFloat(FifoNr, Count, fdata);
/*      */         break;
/*      */       case 0:
/* 3456 */         adwin_tcp_set_data_or_fifo_double(FifoNr, Data, 1, Count, 1);
/*      */         break;
/*      */       default:
/* 3459 */         if (this.adl != null) {
/* 3460 */           this.adl.leave();
/*      */         }
/* 3462 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3464 */     if (this.adl != null) {
/* 3465 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   public int BytesPerValue(int DataType) {
/* 3470 */     switch (DataType) {
/*      */       case 1:
/*      */       case 8:
/* 3473 */         return 1;
/*      */       case 2:
/* 3475 */         return 2;
/*      */       case 6:
/*      */       case 7:
/* 3478 */         return 8;
/*      */     } 
/* 3480 */     return 4;
/*      */   }
/*      */   
/*      */   private void setFifoDoubleADwinX(int FifoNr, int Count, double[] Data) throws ADwinCommunicationError {
/*      */     int n;
/* 3485 */     if (this.adl != null) {
/* 3486 */       this.adl.enter("setFifoFloat (" + FifoNr + ", " + Count + ", <float[]>)");
/*      */     }
/*      */     
/* 3489 */     int DestType = getDataType(FifoNr);
/* 3490 */     if (DestType < 3 || DestType > 6) {
/* 3491 */       throw new ADwinCommunicationError("Fifo ist too small", "Fifo zu klein", this.Language, 101);
/*      */     }
/*      */     
/* 3494 */     int type = DestType;
/* 3495 */     int bytes_per_value = BytesPerValue(DestType);
/* 3496 */     float SizeFactor = 1.0F;
/*      */     
/* 3498 */     if (bytes_per_value == 8)
/* 3499 */       SizeFactor = 2.0F; 
/* 3500 */     int values_per_block = (int)((350 * this.DataBlockSize) / SizeFactor);
/*      */     
/* 3502 */     byte[] FifoData = new byte[Count * bytes_per_value];
/*      */     
/* 3504 */     switch (DestType) {
/*      */       case 3:
/* 3506 */         for (n = 0; n < Count; n++) {
/* 3507 */           setInteger(FifoData, n * 4, (int)Data[n]);
/*      */         }
/* 3509 */         type = 0;
/*      */         break;
/*      */       case 5:
/* 3512 */         for (n = 0; n < Count; n++) {
/* 3513 */           setInteger(FifoData, n * 4, Float.floatToIntBits((float)Data[n]));
/*      */         }
/* 3515 */         type = 0;
/*      */         break;
/*      */       case 6:
/* 3518 */         for (n = 0; n < Count; n++) {
/* 3519 */           setLong(FifoData, n * 8, Double.doubleToLongBits(Data[n]));
/*      */         }
/*      */         break;
/*      */       default:
/* 3523 */         throw new IllegalStateException("Unexpected value: " + DestType);
/*      */     } 
/*      */     
/* 3526 */     int NumBlocks = (int)((Count * SizeFactor - 1.0F) / (this.DataBlockSize * 350) + 1.0F);
/*      */     
/* 3528 */     int WordsSent = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3533 */     for (int i = 0; i < NumBlocks; i++) {
/* 3534 */       int WordsToSend, j; if (i != NumBlocks - 1) {
/* 3535 */         WordsToSend = 350 * this.DataBlockSize;
/* 3536 */         j = values_per_block;
/*      */       } else {
/* 3538 */         WordsToSend = (int)(Count * SizeFactor) - i * 350 * this.DataBlockSize;
/* 3539 */         j = Count % values_per_block;
/* 3540 */         if (j == 0) j = values_per_block; 
/*      */       } 
/* 3542 */       if (WordsToSend == 0) {
/* 3543 */         WordsToSend = 350 * this.DataBlockSize;
/* 3544 */         j = values_per_block;
/*      */       } 
/*      */       
/* 3547 */       writeFifo(FifoNr, type, j, WordsToSend, FifoData, WordsSent * 4);
/* 3548 */       WordsSent += WordsToSend;
/*      */     } 
/* 3550 */     if (this.adl != null)
/* 3551 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized int getWorkload() throws ADwinCommunicationError {
/*      */     int processor;
/*      */     int[] Values;
/*      */     int RetCode;
/*      */     float RetVal;
/* 3558 */     if (this.adl != null) {
/* 3559 */       this.adl.enter("getWorkload ()");
/*      */     }
/*      */     
/* 3562 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3564 */         Values = new int[4];
/* 3565 */         Values[0] = 20;
/* 3566 */         Values[1] = 0;
/* 3567 */         Values[2] = 0;
/* 3568 */         RetCode = standardCall(20, Values, 16, "Unable to read workload.", "workload", "Kann Auslaustung nicht lesen", "Auslastung", true, null);
/*      */ 
/*      */         
/* 3571 */         processor = getProcessorType();
/* 3572 */         if (this.adl != null) {
/* 3573 */           this.adl.leave();
/*      */         }
/* 3575 */         if (RetCode == 0) {
/* 3576 */           if (processor == 11) {
/* 3577 */             return (int)(900.0D * (0.1111111111111111D - (Values[0] / Values[1])));
/*      */           }
/* 3579 */           return (int)(400.0D * (0.25D - (Values[0] / Values[1])));
/*      */         } 
/*      */         
/* 3582 */         return Values[0];
/*      */       
/*      */       case 0:
/* 3585 */         RetVal = adwin_tcp_workload();
/* 3586 */         if (this.adl != null) {
/* 3587 */           this.adl.leave();
/*      */         }
/* 3589 */         return (int)RetVal;
/*      */     } 
/* 3591 */     if (this.adl != null) {
/* 3592 */       this.adl.leave();
/*      */     }
/* 3594 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getFreeMem(int Type) throws ADwinCommunicationError {
/*      */     int RetVal;
/* 3601 */     if (this.adl != null) {
/* 3602 */       this.adl.enter("getFreeMem (" + Type + ")");
/*      */     }
/*      */     
/* 3605 */     if (adwin_tcp_or_udp() == 0) {
/* 3606 */       int ret = adwin_tcp_free_mem(Type);
/* 3607 */       if (this.adl != null) {
/* 3608 */         this.adl.leave();
/*      */       }
/* 3610 */       return ret;
/*      */     } 
/*      */     
/* 3613 */     if (Type < 0 || Type > 6) {
/* 3614 */       if (this.adl != null) {
/* 3615 */         this.adl.leave();
/*      */       }
/* 3617 */       throw new IllegalArgumentException((this.Language == 1) ? "Type may only be 0 - 6" : 
/* 3618 */           "Type darf nur 0 - 6 sein");
/*      */     } 
/*      */     
/* 3621 */     int processor = getProcessorType();
/*      */     
/* 3623 */     if (Type == 0) {
/* 3624 */       int[] Values = { 5, 0, 0, 0 };
/* 3625 */       RetVal = standardCall(0, Values, 8, "Unable to determine amount of free memory", "amount of free memory", "Kann die Größe des freien Speichers nicht bestimmen", "Größe des freien Speichers", false, null);
/*      */     }
/*      */     else {
/*      */       
/* 3629 */       int[] Values = { 12, Type, 0, 0 };
/* 3630 */       RetVal = standardCall(0, Values, 8, "Unable to determine amount of free memory", "amount of free memory", "Größe des freien Speichers konnte nicht bestimmt werden", "Größe des freien Speichers", false, null);
/*      */     } 
/*      */ 
/*      */     
/* 3634 */     if (this.adl != null) {
/* 3635 */       this.adl.leave();
/*      */     }
/*      */     
/* 3638 */     if (Type == 1 && (processor == 9 || processor == 10)) {
/* 3639 */       return RetVal * 6;
/*      */     }
/* 3641 */     if (processor == 10121)
/* 3642 */       return RetVal; 
/* 3643 */     return RetVal * 4;
/*      */   }
/*      */   
/*      */   public synchronized void stopProcess(int ProcessNo) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 3648 */     if (this.adl != null) {
/* 3649 */       this.adl.enter("stopProcess (" + ProcessNo + ")");
/*      */     }
/*      */     
/* 3652 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3654 */         Values = new int[] { 3, ProcessNo, 0, 0 };
/* 3655 */         standardCall(0, Values, 4, "Unable to stop process " + ProcessNo + ".", "stop process " + ProcessNo, "Prozess " + ProcessNo + " konnte nicht angehalten werden", "Process " + ProcessNo + " stoppen", false, null);
/*      */ 
/*      */         
/* 3658 */         if (this.adl != null) {
/* 3659 */           this.adl.leave();
/*      */         }
/*      */         break;
/*      */       case 0:
/* 3663 */         adwin_tcp_stop_process(ProcessNo);
/*      */         break;
/*      */       default:
/* 3666 */         if (this.adl != null) {
/* 3667 */           this.adl.leave();
/*      */         }
/* 3669 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3671 */     if (this.adl != null)
/* 3672 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized int getProcessState(int ProcessNo) throws ADwinCommunicationError {
/*      */     int RetVal;
/*      */     int[] Values;
/* 3677 */     if (this.adl != null) {
/* 3678 */       this.adl.enter("getProcessState (" + ProcessNo + ")");
/*      */     }
/*      */     
/* 3681 */     if (ProcessNo < 1 || ProcessNo > 15) {
/* 3682 */       if (this.adl != null) {
/* 3683 */         this.adl.leave();
/*      */       }
/* 3685 */       throw new IllegalArgumentException((this.Language == 1) ? "ProcessNo is out of range" : 
/* 3686 */           "ProcesssNo außerhalb des gültigen Bereichs");
/*      */     } 
/* 3688 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3690 */         Values = new int[] { 1, ProcessNo + 900, 0, 0 };
/* 3691 */         RetVal = standardCall(0, Values, 8, "Unable to determine state of process " + ProcessNo, "state of process " + ProcessNo, "Status von Prozess " + ProcessNo + " konnte nicht bestimmt werden", "Status von Prozess " + ProcessNo, false, null);
/*      */ 
/*      */         
/* 3694 */         if (this.adl != null) {
/* 3695 */           this.adl.leave();
/*      */         }
/* 3697 */         return RetVal;
/*      */       case 0:
/* 3699 */         RetVal = adwin_tcp_process_status(ProcessNo);
/* 3700 */         if (this.adl != null) {
/* 3701 */           this.adl.leave();
/*      */         }
/* 3703 */         return RetVal;
/*      */     } 
/* 3705 */     if (this.adl != null) {
/* 3706 */       this.adl.leave();
/*      */     }
/* 3708 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   
/*      */   public synchronized void clearProcess(int ProcessNo) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 3713 */     if (this.adl != null) {
/* 3714 */       this.adl.enter("clearProcess (" + ProcessNo + ")");
/*      */     }
/* 3716 */     if (ProcessNo < 1 || ProcessNo > 15) {
/* 3717 */       if (this.adl != null) {
/* 3718 */         this.adl.leave();
/*      */       }
/* 3720 */       throw new IllegalArgumentException((this.Language == 1) ? "ProcessNo is out of range" : 
/* 3721 */           "ProcessNo ist außerhalb des gültigen Bereichs");
/*      */     } 
/*      */     
/* 3724 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3726 */         Values = new int[] { 14, ProcessNo, 0, 0 };
/* 3727 */         standardCall(0, Values, 8, "Unable to clear process " + ProcessNo, "clear process " + ProcessNo, "Prozess " + ProcessNo + " konnte nicht gelöscht werden ", "Löschen von Prozess " + ProcessNo, false, null);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 3732 */         adwin_tcp_clear_process(ProcessNo);
/*      */         break;
/*      */       default:
/* 3735 */         if (this.adl != null) {
/* 3736 */           this.adl.leave();
/*      */         }
/* 3738 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 3740 */     if (this.adl != null)
/* 3741 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized int[] getParIntBlock(int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     int[] pars;
/*      */     DataToIntArray dtia;
/* 3746 */     if (this.adl != null) {
/* 3747 */       this.adl.enter("getParIntBlock (" + IndexFirst + ", " + Count + ")");
/*      */     }
/* 3749 */     if (IndexFirst < 1 || Count < 1) {
/* 3750 */       throw new IllegalArgumentException((this.Language == 1) ? "All parameters must be positive" : 
/* 3751 */           "Alle Parameter müssen positiv sein");
/*      */     }
/* 3753 */     if (IndexFirst + Count - 1 > 80) {
/* 3754 */       throw new IllegalArgumentException((this.Language == 1) ? "There are only 80 parameters" : 
/* 3755 */           "Es gibt nur 80 Parameter");
/*      */     }
/*      */     
/* 3758 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3760 */         dtia = new DataToIntArray(Count, 3);
/* 3761 */         getParBlock(IndexFirst, Count, dtia);
/* 3762 */         if (this.adl != null) {
/* 3763 */           this.adl.leave();
/*      */         }
/* 3765 */         return dtia.getArray();
/*      */       case 0:
/* 3767 */         pars = new int[Count];
/* 3768 */         adwin_tcp_get_par_block(IndexFirst, Count, pars);
/* 3769 */         if (this.adl != null) {
/* 3770 */           this.adl.leave();
/*      */         }
/* 3772 */         return pars;
/*      */     } 
/* 3774 */     if (this.adl != null) {
/* 3775 */       this.adl.leave();
/*      */     }
/* 3777 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized int[] getParIntAll() throws ADwinCommunicationError {
/* 3782 */     if (this.adl != null) {
/* 3783 */       this.adl.enter("getParIntAll ()");
/*      */     }
/* 3785 */     DataToIntArray dtia = new DataToIntArray(80, 3);
/* 3786 */     getParBlock(1, 80, dtia);
/* 3787 */     if (this.adl != null) {
/* 3788 */       this.adl.leave();
/*      */     }
/* 3790 */     return dtia.getArray();
/*      */   }
/*      */   public synchronized float[] getParFloatBlock(int IndexFirst, int Count) throws ADwinCommunicationError { float[] fpars;
/*      */     DataToFloatArray dtfa;
/* 3794 */     if (this.adl != null) {
/* 3795 */       this.adl.enter("getParFloatBlock (" + IndexFirst + ", " + Count + ")");
/*      */     }
/* 3797 */     if (IndexFirst < 1 || Count < 1) {
/* 3798 */       throw new IllegalArgumentException((this.Language == 1) ? "All parameters must be positive" : 
/* 3799 */           "Alle Parameter müssen positiv sein");
/*      */     }
/* 3801 */     if (IndexFirst + Count - 1 > 80) {
/* 3802 */       throw new IllegalArgumentException((this.Language == 1) ? "There are only 80 parameters" : 
/* 3803 */           "Es gibt nur 80 Parameter");
/*      */     }
/*      */ 
/*      */     
/* 3807 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 3809 */         dtfa = new DataToFloatArray(Count, 5);
/* 3810 */         getParBlock(IndexFirst + 100, Count, dtfa);
/* 3811 */         if (this.adl != null) {
/* 3812 */           this.adl.leave();
/*      */         }
/* 3814 */         return dtfa.getArray();
/*      */       case 0:
/* 3816 */         fpars = new float[Count];
/* 3817 */         adwin_tcp_get_fpar_block(IndexFirst, Count, fpars);
/* 3818 */         if (this.adl != null) {
/* 3819 */           this.adl.leave();
/*      */         }
/* 3821 */         return fpars;
/*      */     } 
/* 3823 */     if (this.adl != null) {
/* 3824 */       this.adl.leave();
/*      */     }
/* 3826 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000); } public synchronized double[] getParFloatBlockDouble(int IndexFirst, int Count) throws ADwinCommunicationError {
/*      */     double[] dpars;
/*      */     float[] fpars;
/*      */     DataToFloatArray dtfa;
/*      */     int i;
/* 3831 */     if (this.adl != null) {
/* 3832 */       this.adl.enter("getParFloatBlockDouble (" + IndexFirst + ", " + Count + ")");
/*      */     }
/* 3834 */     if (IndexFirst < 1 || Count < 1) {
/* 3835 */       throw new IllegalArgumentException((this.Language == 1) ? "All parameters must be positive" : 
/* 3836 */           "Alle Parameter müssen positiv sein");
/*      */     }
/* 3838 */     if (IndexFirst + Count - 1 > 80) {
/* 3839 */       throw new IllegalArgumentException((this.Language == 1) ? "There are only 80 parameters" : 
/* 3840 */           "Es gibt nur 80 Parameter");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3845 */     switch (adwin_tcp_or_udp()) {
/*      */       
/*      */       case 2:
/* 3848 */         dpars = new double[Count];
/*      */         
/* 3850 */         if (is_adwinx(this.version)) {
/* 3851 */           DataToDoubleArray dtda = new DataToDoubleArray(Count, 6);
/* 3852 */           getParBlock(IndexFirst + 200, Count, dtda);
/* 3853 */           if (this.adl != null) {
/* 3854 */             this.adl.leave();
/*      */           }
/* 3856 */           dpars = dtda.getArray();
/* 3857 */           return dpars;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3865 */         dtfa = new DataToFloatArray(Count, 5);
/* 3866 */         getParBlock(IndexFirst + 100, Count, dtfa);
/* 3867 */         if (this.adl != null) {
/* 3868 */           this.adl.leave();
/*      */         }
/* 3870 */         fpars = dtfa.getArray();
/*      */         
/* 3872 */         for (i = 0; i < Count; i++) {
/* 3873 */           dpars[i] = fpars[i];
/*      */         }
/* 3875 */         if (this.adl != null) {
/* 3876 */           this.adl.leave();
/*      */         }
/* 3878 */         return dpars;
/*      */       case 0:
/* 3880 */         dpars = new double[Count];
/* 3881 */         adwin_tcp_get_fpar_block_double(IndexFirst, Count, dpars);
/* 3882 */         if (this.adl != null) {
/* 3883 */           this.adl.leave();
/*      */         }
/* 3885 */         return dpars;
/*      */     } 
/* 3887 */     if (this.adl != null) {
/* 3888 */       this.adl.leave();
/*      */     }
/* 3890 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized float[] getParFloatAll() throws ADwinCommunicationError {
/* 3895 */     if (this.adl != null) {
/* 3896 */       this.adl.enter("getParFloatAll ()");
/*      */     }
/* 3898 */     DataToFloatArray dtfa = new DataToFloatArray(80, 5);
/* 3899 */     getParBlock(101, 80, dtfa);
/* 3900 */     if (this.adl != null) {
/* 3901 */       this.adl.leave();
/*      */     }
/* 3903 */     return dtfa.getArray();
/*      */   }
/*      */   
/*      */   public synchronized int getFifoFree(int FifoNo) throws ADwinCommunicationError {
/* 3907 */     if (this.adl != null) {
/* 3908 */       this.adl.enter("getFifoFree (" + FifoNo + ")");
/*      */     }
/* 3910 */     if (FifoNo < 1 || FifoNo > 200) {
/* 3911 */       if (this.adl != null) {
/* 3912 */         this.adl.leave();
/*      */       }
/* 3914 */       throw new IllegalArgumentException((this.Language == 1) ? ("FifoNo (" + FifoNo + ") is out of range") : (
/* 3915 */           "FifoNo (" + FifoNo + ") außerhalb des gültigen Bereichs"));
/*      */     } 
/*      */     
/* 3918 */     if (adwin_tcp_or_udp() == 0) {
/* 3919 */       int ret = adwin_tcp_fifo_empty(FifoNo);
/* 3920 */       if (this.adl != null) {
/* 3921 */         this.adl.leave();
/*      */       }
/* 3923 */       return ret;
/*      */     } 
/*      */     
/* 3926 */     int[] Values = { 22, FifoNo, 0, 0 };
/* 3927 */     int RetVal = standardCall(0, Values, 8, "Unable to determine number of free elements in fifo " + FifoNo, "number of free elements in fifo " + FifoNo, "Anzahl der freien Elemente in Fifo " + FifoNo + " konnte nicht bestimmt werden", "Anzahl der freien Elemente in " + FifoNo, false, null);
/*      */ 
/*      */     
/* 3930 */     if (this.adl != null) {
/* 3931 */       this.adl.leave();
/*      */     }
/* 3933 */     return RetVal;
/*      */   }
/*      */   
/*      */   public synchronized int getFifoUsed(int FifoNo) throws ADwinCommunicationError {
/* 3937 */     if (this.adl != null) {
/* 3938 */       this.adl.enter("getFifoUsed (" + FifoNo + ")");
/*      */     }
/* 3940 */     if (FifoNo < 1 || FifoNo > 200) {
/* 3941 */       if (this.adl != null) {
/* 3942 */         this.adl.leave();
/*      */       }
/* 3944 */       throw new IllegalArgumentException((this.Language == 1) ? ("FifoNo (" + FifoNo + ") is out of range") : (
/* 3945 */           "FifoNo (" + FifoNo + ") außerhalb des gültigen Bereichs"));
/*      */     } 
/* 3947 */     if (adwin_tcp_or_udp() == 0) {
/* 3948 */       int ret = adwin_tcp_fifo_full(FifoNo);
/* 3949 */       if (this.adl != null) {
/* 3950 */         this.adl.leave();
/*      */       }
/* 3952 */       return ret;
/*      */     } 
/*      */     
/* 3955 */     int[] Values = { 23, FifoNo, 0, 0 };
/* 3956 */     int RetVal = standardCall(0, Values, 8, "Unable to determine number of used elements in fifo " + FifoNo, "number of used elements in fifo " + FifoNo, "Anzahl der benutzen Elemente in Fifo " + FifoNo + "konnte nicht bestimmt werden", "Anzahl der benutzten Elemente in Fifo " + FifoNo, false, null);
/*      */ 
/*      */     
/* 3959 */     if (this.adl != null) {
/* 3960 */       this.adl.leave();
/*      */     }
/* 3962 */     return RetVal;
/*      */   }
/*      */   
/*      */   public synchronized void clearFifo(int FifoNo) throws ADwinCommunicationError {
/* 3966 */     if (this.adl != null) {
/* 3967 */       this.adl.enter("clearFifo (" + FifoNo + ")");
/*      */     }
/* 3969 */     if (FifoNo < 1 || FifoNo > 200) {
/* 3970 */       if (this.adl != null) {
/* 3971 */         this.adl.leave();
/*      */       }
/* 3973 */       throw new IllegalArgumentException((this.Language == 1) ? ("FifoNo (" + FifoNo + ") is out of range") : (
/* 3974 */           "FifoNo (" + FifoNo + ") ist außerhalb des gültigen Bereichs"));
/*      */     } 
/*      */     
/* 3977 */     if (adwin_tcp_or_udp() == 0) {
/* 3978 */       adwin_tcp_fifo_clear(FifoNo);
/* 3979 */       if (this.adl != null) {
/* 3980 */         this.adl.leave();
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/* 3985 */     int[] Values = { 21, FifoNo, 0, 0 };
/* 3986 */     standardCall(0, Values, 4, "Unable to clear fifo " + FifoNo, "clear fifo " + FifoNo, "Fifo " + FifoNo + " konnte nicht gelöscht werden.", "Löschen von Fifo " + FifoNo, false, null);
/*      */ 
/*      */     
/* 3989 */     if (this.adl != null)
/* 3990 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized int getStringLength(int DataNo) throws ADwinCommunicationError { int[] Length;
/*      */     int ret;
/* 3995 */     if (DataNo < 1 || DataNo > 200) {
/* 3996 */       throw new IllegalArgumentException((this.Language == 1) ? "DataNo is out of range" : 
/* 3997 */           "DataNo nicht innerhalb des gültigen Bereichs");
/*      */     }
/* 3999 */     if (this.adl != null) {
/* 4000 */       this.adl.enter("getStringLength (" + DataNo + ")");
/*      */     }
/* 4002 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4004 */         if (is_adwinx(this.version)) {
/*      */           
/* 4006 */           int[] Values = new int[4];
/* 4007 */           Values[0] = 44;
/* 4008 */           Values[1] = DataNo;
/* 4009 */           Values[3] = 0; Values[2] = 0;
/* 4010 */           return standardCall(0, Values, 8, "Unable to get stringlength from data " + DataNo + ".", "getStringLength " + DataNo, "StringLength von Data " + DataNo + " kann nicht abgerufen werden", "Data_" + DataNo, false, null);
/*      */         } 
/*      */         
/* 4013 */         Length = getDataInt(DataNo, 1, 1);
/* 4014 */         if (this.adl != null) {
/* 4015 */           this.adl.leave();
/*      */         }
/* 4017 */         return Length[0];
/*      */       case 0:
/* 4019 */         ret = adwin_tcp_string_length(DataNo);
/* 4020 */         if (this.adl != null) {
/* 4021 */           this.adl.leave();
/*      */         }
/* 4023 */         return ret;
/*      */     } 
/* 4025 */     if (this.adl != null) {
/* 4026 */       this.adl.leave();
/*      */     }
/* 4028 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000); } public synchronized String getString(int DataNo) throws ADwinCommunicationError {
/*      */     int DataType;
/*      */     DataToIntArray dtia;
/*      */     int strlen;
/*      */     String str;
/* 4033 */     if (DataNo < 1 || DataNo > 200) {
/* 4034 */       throw new IllegalArgumentException((this.Language == 1) ? "DataNo is out of range" : 
/* 4035 */           "DataNo nicht innerhalb des gültigen Bereichs");
/*      */     }
/* 4037 */     if (this.adl != null) {
/* 4038 */       this.adl.enter("getString (" + DataNo + ")");
/*      */     }
/*      */     
/* 4041 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4043 */         DataType = getDataType(DataNo);
/* 4044 */         if (is_adwinx(this.version)) {
/* 4045 */           if (DataType != 8) {
/* 4046 */             if (this.adl != null) {
/* 4047 */               this.adl.leave();
/*      */             }
/* 4049 */             throw new IllegalArgumentException((this.Language == 1) ? ("DATA_" + DataNo + " is not of type string") : (
/* 4050 */                 "DATA_" + DataNo + " ist nicht vom Typ string"));
/*      */           } 
/* 4052 */           int len = getStringLength(DataNo);
/* 4053 */           DataToByteArray dtba = (DataToByteArray)getDataADwinX(DataNo, 0, len, DataType);
/* 4054 */           if (this.adl != null) {
/* 4055 */             this.adl.leave();
/*      */           }
/* 4057 */           return dtba.getString();
/*      */         } 
/*      */         
/* 4060 */         if (DataType != 3) {
/* 4061 */           if (this.adl != null) {
/* 4062 */             this.adl.leave();
/*      */           }
/* 4064 */           throw new IllegalArgumentException((this.Language == 1) ? ("DATA_" + DataNo + " is not of type int") : (
/* 4065 */               "DATA_" + DataNo + " ist nicht vom Typ int"));
/*      */         } 
/* 4067 */         dtia = (DataToIntArray)getData(DataNo, 1, getStringLength(DataNo) + 1, DataType);
/* 4068 */         if (this.adl != null) {
/* 4069 */           this.adl.leave();
/*      */         }
/* 4071 */         return dtia.getString();
/*      */       case 0:
/* 4073 */         strlen = adwin_tcp_string_length(DataNo);
/* 4074 */         str = adwin_tcp_get_data_string(DataNo, strlen);
/* 4075 */         if (this.adl != null) {
/* 4076 */           this.adl.leave();
/*      */         }
/* 4078 */         return str;
/*      */     } 
/* 4080 */     if (this.adl != null) {
/* 4081 */       this.adl.leave();
/*      */     }
/* 4083 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   public synchronized void setString(int DataNo, String Str) throws ADwinCommunicationError {
/*      */     int[] StringData;
/*      */     int n;
/* 4088 */     if (DataNo < 1 || DataNo > 200) {
/* 4089 */       throw new IllegalArgumentException((this.Language == 1) ? "DataNo is out of range" : 
/* 4090 */           "DataNo nicht innerhalb des gültigen Bereichs");
/*      */     }
/* 4092 */     if (this.adl != null) {
/* 4093 */       this.adl.enter("setString (" + DataNo + ", \"" + Str + "\")");
/*      */     }
/*      */     
/* 4096 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4098 */         if (is_adwinx(this.version)) {
/* 4099 */           byte[] stringdata = Str.getBytes();
/* 4100 */           int strlen = stringdata.length + 1;
/* 4101 */           byte[] data = new byte[strlen];
/*      */           
/* 4103 */           System.arraycopy(stringdata, 0, data, 0, strlen - 1);
/* 4104 */           data[strlen - 1] = 0;
/* 4105 */           setDataByteADwinX(DataNo, data, 0, strlen);
/*      */           break;
/*      */         } 
/* 4108 */         StringData = new int[Str.length() + 2];
/* 4109 */         StringData[0] = Str.length();
/* 4110 */         for (n = 0; n < Str.length(); n++) {
/* 4111 */           StringData[n + 1] = Str.charAt(n);
/*      */         }
/* 4113 */         StringData[Str.length() + 1] = 0;
/* 4114 */         setDataInt(DataNo, StringData, 1, Str.length() + 2);
/*      */         break;
/*      */       case 0:
/* 4117 */         adwin_tcp_set_data_string(DataNo, Str, Str.length() + 2);
/*      */         break;
/*      */       default:
/* 4120 */         if (this.adl != null) {
/* 4121 */           this.adl.leave();
/*      */         }
/* 4123 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 4125 */     if (this.adl != null)
/* 4126 */       this.adl.leave(); 
/*      */   }
/*      */   public synchronized int getGlobalDelay(int ProcessNo) throws ADwinCommunicationError {
/*      */     int RetVal;
/*      */     int[] Values;
/* 4131 */     if (this.adl != null) {
/* 4132 */       this.adl.enter("getGlobalDelay (" + ProcessNo + ")");
/*      */     }
/*      */     
/* 4135 */     if (ProcessNo < 1 || ProcessNo > 10) {
/* 4136 */       if (this.adl != null) {
/* 4137 */         this.adl.leave();
/*      */       }
/* 4139 */       throw new IllegalArgumentException((this.Language == 1) ? "ProcessNo is out of range" : 
/* 4140 */           "ProcessNo nicht innerhalb des gültigen Bereichs");
/*      */     } 
/* 4142 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4144 */         Values = new int[] { 1, 910 + ProcessNo, 0, 0 };
/* 4145 */         RetVal = standardCall(0, Values, 8, "Unable to load the GlobalDelay of Process " + ProcessNo + ".", "GlobalDelay of Process " + ProcessNo, "Das GlobalDelay von Prozess " + ProcessNo + " konnte nicht geladen werden.", "GlobalDelay von Prozess " + ProcessNo, false, null);
/*      */ 
/*      */         
/* 4148 */         if (this.adl != null) {
/* 4149 */           this.adl.leave();
/*      */         }
/* 4151 */         return RetVal;
/*      */       case 0:
/* 4153 */         RetVal = adwin_tcp_get_processdelay(ProcessNo);
/* 4154 */         if (this.adl != null) {
/* 4155 */           this.adl.leave();
/*      */         }
/* 4157 */         return RetVal;
/*      */     } 
/* 4159 */     if (this.adl != null) {
/* 4160 */       this.adl.leave();
/*      */     }
/* 4162 */     throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */   }
/*      */   
/*      */   public synchronized void setGlobalDelay(int ProcessNo, int NewGlobalDelay) throws ADwinCommunicationError {
/*      */     int[] Values;
/* 4167 */     if (this.adl != null) {
/* 4168 */       this.adl.enter("setGlobalDelay (" + ProcessNo + ", " + NewGlobalDelay + ")");
/*      */     }
/* 4170 */     if (ProcessNo < 1 || ProcessNo > 10) {
/* 4171 */       if (this.adl != null) {
/* 4172 */         this.adl.leave();
/*      */       }
/* 4174 */       throw new IllegalArgumentException((this.Language == 1) ? "ProcessNo is out of range" : 
/* 4175 */           "ProcessNo nicht innerhalb des gültigen Bereichs");
/*      */     } 
/*      */     
/* 4178 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4180 */         Values = new int[] { 6, 910 + ProcessNo, NewGlobalDelay, 0 };
/* 4181 */         standardCall(0, Values, 4, "Unable to set the GlobalDelay of Process " + ProcessNo + ".", "setting GlobalDelay for Process " + ProcessNo + ".", "Das GlobalDelay für Prozess " + ProcessNo + " konnte nicht gesetzt werden", "Setzen des GlobalDelays von Prozess " + ProcessNo, false, null);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 0:
/* 4186 */         adwin_tcp_set_processdelay(ProcessNo, NewGlobalDelay);
/*      */         break;
/*      */       default:
/* 4189 */         if (this.adl != null) {
/* 4190 */           this.adl.leave();
/*      */         }
/* 4192 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 4194 */     if (this.adl != null)
/* 4195 */       this.adl.leave(); 
/*      */   }
/*      */   
/*      */   public synchronized void bootFile(String FileName, int Processor) throws ADwinCommunicationError, IOException {
/*      */     FileInputStream fis;
/*      */     byte[] Binary;
/* 4201 */     if (this.adl != null) {
/* 4202 */       this.adl.enter("bootFile (" + FileName + ", " + Processor + ")");
/*      */     }
/*      */     int l;
/* 4205 */     if (FileName == null || (l = FileName.length()) < 5) {
/* 4206 */       if (this.adl != null) {
/* 4207 */         this.adl.leave();
/*      */       }
/* 4209 */       throw new ADwinCommunicationError("The file is not a BTL file", "Die Datei ist keine BTL-Datei", this.Language, 204);
/*      */     } 
/* 4211 */     if ((FileName.charAt(l - 1) != 'l' && FileName.charAt(l - 1) != 'L') || (FileName
/* 4212 */       .charAt(l - 2) != 't' && FileName.charAt(l - 2) != 'T') || (FileName
/* 4213 */       .charAt(l - 3) != 'b' && FileName.charAt(l - 3) != 'B')) {
/* 4214 */       if (this.adl != null) {
/* 4215 */         this.adl.leave();
/*      */       }
/* 4217 */       throw new ADwinCommunicationError("The file is not a BTL file", "Die Datei ist keine BTL-Datei", this.Language, 204);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4222 */     if (FileName.toLowerCase().endsWith("121.btl")) {
/* 4223 */       FileInputStream fileInputStream = new FileInputStream(FileName);
/* 4224 */       byte[] arrayOfByte = new byte[fileInputStream.available()];
/* 4225 */       fileInputStream.read(arrayOfByte);
/* 4226 */       fileInputStream.close();
/* 4227 */       if (arrayOfByte.length == 0) {
/*      */         return;
/*      */       }
/* 4230 */       bootArrayADwinX(arrayOfByte, FileName, Processor);
/*      */       
/*      */       return;
/*      */     } 
/* 4234 */     switch (adwin_tcp_or_udp()) {
/*      */       case 2:
/* 4236 */         fis = new FileInputStream(FileName);
/* 4237 */         Binary = new byte[fis.available()];
/* 4238 */         fis.read(Binary);
/* 4239 */         fis.close();
/* 4240 */         if (Binary.length == 0) {
/*      */           return;
/*      */         }
/* 4243 */         bootArray(Binary, FileName, Processor);
/*      */         break;
/*      */       case 0:
/* 4246 */         adwin_tcp_boot(FileName);
/*      */         break;
/*      */       default:
/* 4249 */         if (this.adl != null) {
/* 4250 */           this.adl.leave();
/*      */         }
/* 4252 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     } 
/* 4254 */     if (this.adl != null) {
/* 4255 */       this.adl.leave();
/*      */     }
/*      */   }
/*      */   
/*      */   public static List<NetworkInterface> getAllInterfaces() {
/* 4260 */     List<NetworkInterface> ret = new ArrayList<>();
/*      */     try {
/* 4262 */       Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
/* 4263 */       while (interfaces.hasMoreElements()) {
/* 4264 */         NetworkInterface networkInterface = interfaces.nextElement();
/*      */         
/* 4266 */         if (networkInterface.isLoopback() || !networkInterface.isUp()) {
/*      */           continue;
/*      */         }
/* 4269 */         ret.add(networkInterface);
/*      */       } 
/* 4271 */     } catch (SocketException ex) {
/* 4272 */       System.err.println("SocketException: " + ex);
/*      */     } 
/* 4274 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendADwinXBootBroadcast() {
/* 4284 */     int BufLen = 100;
/* 4285 */     byte[] data = new byte[108];
/* 4286 */     data[0] = 51;
/* 4287 */     data[1] = 0;
/* 4288 */     data[2] = 18;
/* 4289 */     data[3] = 118;
/* 4290 */     System.arraycopy(this.Connection.getAddress(), 0, data, 4, 4);
/* 4291 */     data[8] = (byte)(this.Port >> 8 & 0xFF);
/* 4292 */     data[9] = (byte)(this.Port & 0xFF);
/* 4293 */     System.arraycopy(this.Password.getBytes(), 0, data, 10, this.Password.length());
/*      */     
/* 4295 */     List<NetworkInterface> nil = getAllInterfaces();
/* 4296 */     int dev_ip_as_int = ByteBuffer.wrap(this.Connection.getAddress()).getInt();
/*      */     
/* 4298 */     for (NetworkInterface ni : nil) {
/*      */       try {
/* 4300 */         if (ni.isLoopback() || !ni.isUp()) {
/*      */           continue;
/*      */         }
/* 4303 */         List<InterfaceAddress> inal = ni.getInterfaceAddresses();
/*      */         
/* 4305 */         for (InterfaceAddress ia : inal) {
/* 4306 */           int prefixlen = ia.getNetworkPrefixLength();
/* 4307 */           if (prefixlen > 1 && prefixlen < 32) {
/* 4308 */             int prefix = -1 << 32 - prefixlen;
/* 4309 */             int net_ip_as_int = ByteBuffer.wrap(ia.getAddress().getAddress()).getInt();
/*      */             
/* 4311 */             if ((dev_ip_as_int & prefix) == (net_ip_as_int & prefix)) {
/*      */               
/* 4313 */               DatagramSocket socket = new DatagramSocket(new InetSocketAddress(ia.getAddress(), 0));
/* 4314 */               socket.setBroadcast(true);
/* 4315 */               socket.send(new DatagramPacket(data, BufLen, new InetSocketAddress("255.255.255.255", 7000)));
/* 4316 */               socket.close();
/*      */             } 
/*      */           } 
/*      */         } 
/* 4320 */       } catch (SocketException ex) {
/* 4321 */         System.err.println("SocketException: " + ex);
/* 4322 */       } catch (IOException e) {
/* 4323 */         e.printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public synchronized void bootArrayADwinX(byte[] OS, String FileName, int Processor) throws ADwinCommunicationError, IOException {
/* 4329 */     if (this.adl != null) {
/* 4330 */       this.adl.enter("bootArrayADwinX (<byte[]>, " + FileName + ", " + Processor + ")");
/*      */     }
/*      */     
/* 4333 */     int _timeout = this.MaxPacketDelay;
/* 4334 */     this.MaxPacketDelay = 100;
/* 4335 */     this.version = 0;
/*      */     try {
/* 4337 */       getArmVersion();
/* 4338 */       if (this.version < 400)
/* 4339 */         throw new ADwinCommunicationError("", "", this.Language, 205); 
/* 4340 */       System.out.print(" (getArmVersion: " + this.version + ") ");
/* 4341 */     } catch (ADwinCommunicationError awce) {
/* 4342 */       if (awce.getCode() == 205) {
/* 4343 */         if (this.adl != null) {
/* 4344 */           this.adl.leave();
/*      */         }
/* 4346 */         this.MaxPacketDelay = _timeout;
/* 4347 */         throw new ADwinCommunicationError("The binary file has been built for a different processor.", "Diese BTL ist für einen anderen Prozessor.", this.Language, 205);
/*      */       } 
/*      */       
/* 4350 */       this.MaxPacketDelay = 300;
/*      */       try {
/* 4352 */         for (int i = 0; i < 4; i++) {
/* 4353 */           sendADwinXBootBroadcast();
/* 4354 */           if (i < 3) {
/* 4355 */             Thread.sleep(300L);
/*      */           }
/*      */         } 
/* 4358 */         Thread.sleep(4000L);
/* 4359 */       } catch (InterruptedException e) {
/* 4360 */         this.MaxPacketDelay = _timeout;
/* 4361 */         e.printStackTrace();
/*      */       } 
/*      */     } 
/* 4364 */     if (_timeout < 1500) {
/* 4365 */       this.MaxPacketDelay = 1500;
/*      */     } else {
/* 4367 */       this.MaxPacketDelay = _timeout;
/*      */     } 
/*      */     
/* 4370 */     byte[] ConfirmationData = new byte[32];
/* 4371 */     DatagramPacket ConfPacket = new DatagramPacket(ConfirmationData, 32);
/* 4372 */     int[] requestPacketIndex = new int[1];
/*      */     
/* 4374 */     int[] Values = new int[4];
/* 4375 */     Values[0] = 1000;
/*      */     
/* 4377 */     Values[1] = this.DataBlockSize << 16;
/* 4378 */     Values[2] = Processor;
/* 4379 */     Values[3] = OS.length;
/* 4380 */     synchronized (this.ds) {
/* 4381 */       standardCall(50, Values, 4, "Unable to start booting.", "starting to boot", "Es konnte nicht mit dem Booten begonnen werden", "Start des Bootens", false, requestPacketIndex);
/*      */ 
/*      */       
/* 4384 */       DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/* 4385 */       dft.send(OS.length, OS, "operating system " + FileName, requestPacketIndex[0]);
/*      */       
/* 4387 */       int TimeoutsOccured = 0;
/*      */       while (true) {
/*      */         try {
/* 4390 */           this.ds.receive(ConfPacket);
/* 4391 */           TimeoutsOccured = 0;
/* 4392 */         } catch (SocketTimeoutException ste) {
/* 4393 */           TimeoutsOccured++;
/* 4394 */           if (this.adl != null) {
/* 4395 */             this.adl.message("Timeout...", 100);
/*      */           }
/* 4397 */           if (TimeoutsOccured > this.AllowedErrors) {
/* 4398 */             if (this.adl != null) {
/* 4399 */               this.adl.leave();
/*      */             }
/* 4401 */             this.MaxPacketDelay = _timeout;
/* 4402 */             throw new ADwinCommunicationError("ADwin system could not be booted, " + ste
/* 4403 */                 .getMessage(), "ADwin-System konnte nicht gebootet werden, " + ste
/* 4404 */                 .getMessage(), this.Language, 2001);
/*      */           } 
/* 4406 */         } catch (IOException ioe) {
/* 4407 */           this.MaxPacketDelay = _timeout;
/* 4408 */           if (this.adl != null) {
/* 4409 */             this.adl.message("IOException -> ADwinCommunicationError", 1);
/* 4410 */             this.adl.leave();
/*      */           } 
/* 4412 */           throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 4413 */               .getMessage(), this.Language, 2000);
/*      */         } 
/*      */         
/* 4416 */         if (TimeoutsOccured <= 0) {
/*      */ 
/*      */           
/* 4419 */           if (extractInt(ConfirmationData, 0) != 0) {
/* 4420 */             if (this.adl != null) {
/* 4421 */               this.adl.message("Error Code: " + extractInt(ConfirmationData, 0), 1);
/* 4422 */               this.adl.leave();
/*      */             } 
/* 4424 */             this.MaxPacketDelay = _timeout;
/* 4425 */             throw new ADwinCommunicationError("Error " + extractInt(ConfirmationData, 0) + " occured after loading operating system " + FileName + ".", "Fehler " + 
/*      */                 
/* 4427 */                 extractInt(ConfirmationData, 0) + " nach dem Laden von Betriebssystem " + FileName + " aufgetreten", this.Language, 
/* 4428 */                 extractInt(ConfirmationData, 0));
/*      */           } 
/* 4430 */           this.MaxPacketDelay = _timeout;
/* 4431 */           if (this.adl != null)
/* 4432 */             this.adl.leave();  return;
/*      */         } 
/*      */       } 
/*      */     }  } public synchronized void bootArray(byte[] OS, String FileName, int Processor) throws ADwinCommunicationError, IOException { byte[] ConfirmationData; DatagramPacket ConfPacket;
/*      */     int[] requestPacketIndex;
/*      */     int[] Values;
/* 4438 */     if (this.adl != null) {
/* 4439 */       this.adl.enter("bootArray (<byte[]>, " + FileName + ", " + Processor + ")");
/*      */     }
/*      */     
/* 4442 */     switch (adwin_tcp_or_udp())
/*      */     { case 2:
/* 4444 */         ConfirmationData = new byte[32];
/* 4445 */         ConfPacket = new DatagramPacket(ConfirmationData, 32);
/* 4446 */         requestPacketIndex = new int[1];
/*      */         
/* 4448 */         Values = new int[4];
/* 4449 */         Values[0] = 1000;
/*      */         
/* 4451 */         Values[1] = this.DataBlockSize << 16;
/* 4452 */         Values[2] = Processor;
/* 4453 */         Values[3] = OS.length;
/* 4454 */         synchronized (this.ds)
/* 4455 */         { standardCall(50, Values, 4, "Unable to start booting.", "starting to boot", "Es konnte nicht mit dem Booten begonnen werden", "Start des Bootens", false, requestPacketIndex);
/*      */ 
/*      */           
/* 4458 */           DataFieldTransfer dft = new DataFieldTransfer(this.Connection, this.ds, this);
/* 4459 */           dft.send(OS.length, OS, "operating system " + FileName, requestPacketIndex[0]);
/*      */           
/* 4461 */           int TimeoutsOccured = 0;
/*      */           while (true)
/*      */           { try {
/* 4464 */               this.ds.receive(ConfPacket);
/* 4465 */               TimeoutsOccured = 0;
/* 4466 */             } catch (SocketTimeoutException ste) {
/* 4467 */               TimeoutsOccured++;
/* 4468 */               if (this.adl != null) {
/* 4469 */                 this.adl.message("Timeout...", 100);
/*      */               }
/* 4471 */               if (TimeoutsOccured > this.AllowedErrors) {
/* 4472 */                 if (this.adl != null) {
/* 4473 */                   this.adl.leave();
/*      */                 }
/* 4475 */                 throw new ADwinCommunicationError("ADwin system could not be booted, " + ste
/* 4476 */                     .getMessage(), "ADwin-System konnte nicht gebootet werden, " + ste
/* 4477 */                     .getMessage(), this.Language, 2001);
/*      */               } 
/* 4479 */             } catch (IOException ioe) {
/* 4480 */               if (this.adl != null) {
/* 4481 */                 this.adl.message("IOException -> ADwinCommunicationError", 1);
/* 4482 */                 this.adl.leave();
/*      */               } 
/* 4484 */               throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 4485 */                   .getMessage(), this.Language, 2000);
/*      */             } 
/*      */             
/* 4488 */             if (TimeoutsOccured <= 0)
/*      */             
/*      */             { 
/* 4491 */               if (extractInt(ConfirmationData, 0) != 0) {
/* 4492 */                 if (this.adl != null) {
/* 4493 */                   this.adl.message("Error Code: " + extractInt(ConfirmationData, 0), 1);
/* 4494 */                   this.adl.leave();
/*      */                 } 
/* 4496 */                 throw new ADwinCommunicationError("Error " + extractInt(ConfirmationData, 0) + " occured after loading operating system " + FileName + ".", "Fehler " + 
/*      */                     
/* 4498 */                     extractInt(ConfirmationData, 0) + " nach dem Laden von Betriebssystem " + FileName + " aufgetreten", this.Language, 
/* 4499 */                     extractInt(ConfirmationData, 0));
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4512 */               if (this.adl != null)
/* 4513 */                 this.adl.leave();  return; }  }  } case 0: adwin_tcp_boot(OS); break;default: if (this.adl != null) this.adl.leave();  throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000); }  if (this.adl != null) this.adl.leave();
/*      */      }
/*      */ 
/*      */ 
/*      */   
/*      */   void new_socket() throws SocketException {
/* 4519 */     this.ati.socket = new Socket();
/* 4520 */     this.ati.socket.setSendBufferSize(131072);
/* 4521 */     this.ati.socket.setReceiveBufferSize(131072);
/* 4522 */     this.ati.socket.setSoTimeout(this.ati.timeout_ms);
/* 4523 */     this.ati.socket.setTcpNoDelay(true);
/*      */   }
/*      */   
/*      */   final void adwin_tcp_construct() throws SocketException {
/* 4527 */     this.ati = new adwin_tcp_info_t();
/* 4528 */     this.ati.server_addr = this.Connection;
/* 4529 */     this.ati.req = new adwin_tcp_buffer_t();
/* 4530 */     this.ati.resp = new adwin_tcp_buffer_t();
/* 4531 */     this.ati.error_number = 0;
/* 4532 */     this.ati.firmware_version = 0;
/* 4533 */     this.ati.firmware_version_beta = 0;
/* 4534 */     this.ati.processortype = -1;
/* 4535 */     this.ati.initialized = true;
/* 4536 */     this.ati.timeout_size = 10485760;
/*      */     
/* 4538 */     this.ati.req.max = 10240;
/*      */     
/* 4540 */     this.ati.req.data = new byte[this.ati.req.max + 4];
/* 4541 */     setInteger(this.ati.req.data, 10240, 305432421);
/* 4542 */     this.ati.resp.max = 10240;
/* 4543 */     this.ati.resp.data = new byte[this.ati.resp.max + 4];
/* 4544 */     setInteger(this.ati.resp.data, 10240, 573785173);
/* 4545 */     this.ati.dll_version = 1;
/* 4546 */     this.ati.timeout_ms = this.ADwTimeout;
/*      */     
/* 4548 */     new_socket();
/*      */   }
/*      */   
/*      */   void init_ati(int command) {
/* 4552 */     this.ati.command = command;
/*      */     
/* 4554 */     if (extractInt(this.ati.req.data, 10240) != 305432421);
/*      */ 
/*      */     
/* 4557 */     if (extractInt(this.ati.resp.data, 10240) != 573785173);
/*      */ 
/*      */     
/* 4560 */     this.ati.req.do_convert = 1;
/* 4561 */     this.ati.req.used = 0;
/* 4562 */     this.ati.resp.do_convert = 2;
/* 4563 */     this.ati.resp.used = 0;
/* 4564 */     this.ati.status = -1111;
/*      */   }
/*      */   
/*      */   int check_tcp_ret(int ret, int ref) throws ADwinCommunicationError {
/* 4568 */     if (ret == ref) {
/* 4569 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 4574 */       this.ati.stream_in.close();
/* 4575 */       this.ati.stream_out.close();
/* 4576 */       this.ati.socket.close();
/* 4577 */     } catch (IOException e) {
/* 4578 */       System.out.println(e.getMessage());
/* 4579 */       this.ati.connected = false;
/* 4580 */       throw new ADwinCommunicationError("I/O-Error: " + e.getMessage(), "E/A-Fehler: " + e.getMessage(), this.Language, 2000);
/*      */     } 
/*      */     
/* 4583 */     this.ati.connected = false;
/* 4584 */     return 1;
/*      */   }
/*      */   
/*      */   public int htonl(int value) {
/* 4588 */     if (ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN)) {
/* 4589 */       return value;
/*      */     }
/* 4591 */     return Integer.reverseBytes(value);
/*      */   }
/*      */   
/*      */   public int ntohl(int value) {
/* 4595 */     if (ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN)) {
/* 4596 */       return value;
/*      */     }
/* 4598 */     return Integer.reverseBytes(value);
/*      */   }
/*      */ 
/*      */   
/*      */   int tcp_discard_pending(adwin_tcp_info_t ati) throws ADwinCommunicationError {
/* 4603 */     if (ati.rx_pending == 0) {
/* 4604 */       return 0;
/*      */     }
/* 4606 */     adwin_tcp_buffer_t tmp = new adwin_tcp_buffer_t();
/* 4607 */     tmp.max = ati.rx_pending;
/* 4608 */     tmp.used = 0;
/* 4609 */     tmp.do_convert = 0;
/* 4610 */     tmp.data = new byte[ati.rx_pending];
/*      */     
/* 4612 */     return tcp_read_pending(ati, ati.rx_pending, tmp);
/*      */   }
/*      */   
/*      */   public synchronized void adwin_tcp_connect() throws ADwinCommunicationError {
/* 4616 */     InetSocketAddress isa = new InetSocketAddress(this.Connection, this.Port);
/*      */ 
/*      */     
/* 4619 */     this.ati.connected = false;
/*      */     try {
/* 4621 */       new_socket();
/* 4622 */       this.ati.socket.connect(isa, 1000);
/* 4623 */     } catch (IOException e) {
/* 4624 */       check_tcp_ret(0, 1);
/*      */       
/*      */       return;
/*      */     } 
/* 4628 */     init_ati(300);
/*      */     
/* 4630 */     setInteger(this.ati.req.data, 0, htonl(this.ati.dll_version));
/* 4631 */     setInteger(this.ati.req.data, 16, htonl(5 * this.ati.timeout_ms));
/* 4632 */     setInteger(this.ati.req.data, 20, htonl(this.ati.timeout_size));
/*      */     
/*      */     int n;
/* 4635 */     for (n = 0; n < 10 && n < this.Password.length(); n++) {
/* 4636 */       this.ati.req.data[n + 4] = (byte)this.Password.charAt(n);
/*      */     }
/* 4638 */     this.ati.req.data[n + 4] = 0;
/* 4639 */     this.ati.req.used = 24;
/* 4640 */     this.ati.req.do_convert = 0;
/*      */     
/*      */     try {
/* 4643 */       this.ati.stream_in = this.ati.socket.getInputStream();
/* 4644 */       this.ati.stream_out = this.ati.socket.getOutputStream();
/* 4645 */     } catch (IOException e) {
/* 4646 */       check_tcp_ret(0, 1);
/* 4647 */       throw new ADwinCommunicationError("socket-error: " + e.getMessage(), "Socket-Fehler: " + e
/* 4648 */           .getMessage(), this.Language, 2000);
/*      */     } 
/*      */ 
/*      */     
/* 4652 */     if (tcp_write_request(this.ati, null) == -1) {
/* 4653 */       check_tcp_ret(0, 1);
/*      */       
/*      */       return;
/*      */     } 
/* 4657 */     if (tcp_read_response(this.ati, 16, null) == -1) {
/* 4658 */       check_tcp_ret(0, 1);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 4663 */     this.ati.processortype = extractInt(this.ati.resp.data, 0) + 9;
/* 4664 */     int connectCount = extractInt(this.ati.resp.data, 4);
/*      */     
/* 4666 */     this.ati.firmware_version = extractInt(this.ati.resp.data, 8);
/* 4667 */     this.ati.firmware_version_beta = extractInt(this.ati.resp.data, 12);
/* 4668 */     switch (this.ati.processortype) {
/*      */       case 9:
/* 4670 */         this.ati.processortype = 9;
/*      */         break;
/*      */       
/*      */       case 10:
/* 4674 */         this.ati.processortype = 1010;
/*      */         break;
/*      */       
/*      */       case 11:
/* 4678 */         this.ati.processortype = 1011;
/*      */         break;
/*      */       
/*      */       case 12:
/* 4682 */         this.ati.processortype = 1012;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4690 */     this.ati.connected = (this.ati.error_number == 0);
/*      */   }
/*      */   
/*      */   public synchronized int adwin_tcp_or_udp() throws ADwinCommunicationError {
/* 4694 */     Date now = new Date();
/*      */     
/* 4696 */     if (this.ati.initialized && this.ati.connected && this.last_access.getTime() + 5000L > now.getTime())
/*      */     {
/* 4698 */       return 0;
/*      */     }
/*      */ 
/*      */     
/* 4702 */     if (this.version == 0 || this.last_access.getTime() == 0L || this.last_access.getTime() + 5000L > now.getTime())
/*      */     {
/* 4704 */       if (getArmVersion() == 0)
/*      */       {
/* 4706 */         return 1;
/*      */       }
/*      */     }
/* 4709 */     this.last_access = now;
/*      */ 
/*      */ 
/*      */     
/* 4713 */     if (this.supports_tcp) {
/* 4714 */       if (!this.ati.initialized)
/*      */       {
/* 4716 */         return 1;
/*      */       }
/* 4718 */       if (!this.ati.connected)
/*      */       {
/* 4720 */         adwin_tcp_connect();
/*      */       }
/* 4722 */       if (this.ati.connected)
/*      */       {
/* 4724 */         return 0;
/*      */       }
/*      */ 
/*      */       
/* 4728 */       return 1;
/*      */     } 
/*      */     
/* 4731 */     return 2;
/*      */   }
/*      */   void do_convert(adwin_tcp_buffer_t buf) {
/*      */     int i;
/* 4735 */     if (buf == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 4740 */     switch (buf.do_convert) {
/*      */       case 2:
/* 4742 */         for (i = 0; i < buf.used / 4; i++) {
/* 4743 */           setInteger(buf.data, i * 4, ntohl(extractInt(buf.data, i * 4)));
/*      */         }
/*      */         break;
/*      */       case 1:
/* 4747 */         for (i = 0; i < buf.used / 4; i++)
/*      */         {
/* 4749 */           setInteger(buf.data, i * 4, ntohl(extractInt(buf.data, i * 4))); } 
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   int tcp_write_request(adwin_tcp_info_t ati, adwin_tcp_buffer_t buf) throws ADwinCommunicationError {
/* 4755 */     adwin_tcp_buffer_t tmp = new adwin_tcp_buffer_t();
/* 4756 */     if (buf == null) {
/* 4757 */       buf = tmp;
/*      */     }
/*      */     
/* 4760 */     ati.req_count++;
/*      */ 
/*      */     
/* 4763 */     int req_len = ati.req.used + buf.used;
/*      */     
/* 4765 */     int bytes_already_send = 0;
/*      */     
/* 4767 */     do_convert(ati.req);
/* 4768 */     do_convert(buf);
/*      */ 
/*      */     
/* 4771 */     int bytes_current_transfer = Math.min(buf.used, ati.timeout_size);
/*      */     
/* 4773 */     int header_len = 16 + ati.req.used;
/* 4774 */     byte[] buffers = new byte[header_len];
/* 4775 */     setInteger(buffers, 0, htonl(1118650900));
/* 4776 */     setInteger(buffers, 4, htonl(ati.req_count));
/* 4777 */     setInteger(buffers, 8, htonl(req_len));
/* 4778 */     setInteger(buffers, 12, htonl(ati.command));
/* 4779 */     System.arraycopy(ati.req.data, 0, buffers, 16, ati.req.used);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 4784 */       ati.stream_out.write(buffers, 0, header_len);
/* 4785 */     } catch (IOException ex) {
/* 4786 */       check_tcp_ret(0, 1);
/* 4787 */       throw new ADwinCommunicationError("Network-error: " + ex.getMessage(), "Netzwerk-Fehler: " + ex.getMessage(), this.Language, 2000);
/*      */     } 
/*      */     
/* 4790 */     if (bytes_current_transfer > 0) {
/*      */ 
/*      */       
/*      */       try {
/* 4794 */         ati.stream_out.write(buf.data, 0, bytes_current_transfer);
/* 4795 */       } catch (IOException ex) {
/* 4796 */         check_tcp_ret(0, 1);
/* 4797 */         throw new ADwinCommunicationError("Network-error: " + ex.getMessage(), "Netzwerk-Fehler: " + ex.getMessage(), this.Language, 2000);
/*      */       } 
/* 4799 */       bytes_already_send = bytes_current_transfer;
/*      */ 
/*      */       
/* 4802 */       while (bytes_already_send < buf.used) {
/* 4803 */         if (bytes_already_send + ati.timeout_size <= buf.used) {
/* 4804 */           bytes_current_transfer = ati.timeout_size;
/*      */         } else {
/* 4806 */           bytes_current_transfer = buf.used - bytes_already_send;
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/* 4811 */           ati.stream_out.write(buf.data, bytes_already_send, bytes_current_transfer);
/* 4812 */           bytes_already_send += bytes_current_transfer;
/* 4813 */         } catch (IOException ex) {
/* 4814 */           check_tcp_ret(0, 1);
/* 4815 */           throw new ADwinCommunicationError("Network-error: " + ex.getMessage(), "Netzwerk-Fehler: " + ex.getMessage(), this.Language, 2000);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 4820 */     return 0;
/*      */   }
/*      */   
/*      */   int tcp_read_response(adwin_tcp_info_t ati, int min_bytes, adwin_tcp_buffer_t buf) throws ADwinCommunicationError {
/*      */     adwin_tcp_buffer_t resp;
/* 4825 */     byte[] mybytearray = new byte[40];
/*      */     
/* 4827 */     adwin_tcp_header_t ath = new adwin_tcp_header_t();
/*      */     
/* 4829 */     if (buf == null) {
/* 4830 */       resp = ati.resp;
/*      */     } else {
/* 4832 */       resp = buf;
/*      */     } 
/*      */     
/*      */     try {
/* 4836 */       int i = ati.stream_in.read(mybytearray, 0, 16);
/* 4837 */       if (check_tcp_ret(i, 16) == 1) {
/* 4838 */         throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */       }
/* 4840 */     } catch (IOException ex) {
/* 4841 */       throw new ADwinCommunicationError("Network-error: " + ex.getMessage(), "Netzwerk-Fehler: " + ex.getMessage(), this.Language, 2000);
/*      */     } 
/*      */     
/* 4844 */     ath.magic_flag = ntohl(extractInt(mybytearray, 0));
/* 4845 */     ath.req_count = ntohl(extractInt(mybytearray, 4));
/* 4846 */     ath.length = ntohl(extractInt(mybytearray, 8));
/* 4847 */     ath.command_or_status = ntohl(extractInt(mybytearray, 12));
/*      */     
/* 4849 */     if (check_tcp_ret(ath.magic_flag, 1118650963) == 1) {
/* 4850 */       throw new ADwinCommunicationError("Network-error!", "Netzwerk-Fehler!", this.Language, 2000);
/*      */     }
/*      */     
/* 4853 */     ati.rx_pending = ath.length;
/* 4854 */     ati.status = map_error_code(ath.command_or_status);
/*      */     
/* 4856 */     int ret = tcp_read_pending(ati, min_bytes, resp);
/*      */     
/* 4858 */     if (ati.status != 0) {
/* 4859 */       if (ati.status == -5) {
/* 4860 */         throw new ADwinCommunicationError("Wrong Password", "Falsches Passwort", this.Language, 2002);
/*      */       }
/* 4862 */       if (ati.status == -30) {
/* 4863 */         throw new ADwinCommunicationError("Wrong Version", "Falsche Version", this.Language, 20);
/*      */       }
/* 4865 */       if (ati.status == 1) {
/* 4866 */         throw new ADwinCommunicationError("Timeout to link", "Timeout beim Schreiben zum Link", this.Language, 1);
/*      */       }
/* 4868 */       if (ati.status == 2) {
/* 4869 */         throw new ADwinCommunicationError("Timeout from link", "Timeout beim Lesen vom Link", this.Language, 2);
/*      */       }
/*      */       
/* 4872 */       if (ati.status == 100) {
/* 4873 */         throw new ADwinCommunicationError("The Data is too small", "Das Data ist zu klein", this.Language, 100);
/*      */       }
/* 4875 */       if (ati.status == 101) {
/* 4876 */         throw new ADwinCommunicationError("There is not enough space left in fifo", "Nicht genug Platz übrig in Fifo", this.Language, 101);
/*      */       }
/* 4878 */       if (ati.status == 102) {
/* 4879 */         throw new ADwinCommunicationError("The Fifo has not enough values", "Das Fifo-Feld hat nicht genug Daten", this.Language, 102);
/*      */       }
/*      */ 
/*      */       
/* 4883 */       throw new ADwinCommunicationError("status error: " + ati.status, "Status-Fehler: " + ati.status, this.Language, ati.status);
/*      */     } 
/* 4885 */     return ret;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int readInputStreamWithTimeout(InputStream is, byte[] b, int offset, int timeoutMillis, int maxBytes) throws IOException {
/* 4890 */     int bufferOffset = 0;
/* 4891 */     long maxTimeMillis = System.currentTimeMillis() + timeoutMillis;
/*      */ 
/*      */     
/* 4894 */     while (System.currentTimeMillis() < maxTimeMillis && bufferOffset < maxBytes) {
/* 4895 */       int readLength = Math.min(is.available(), maxBytes - bufferOffset);
/* 4896 */       readLength = Math.min(readLength, maxBytes);
/*      */ 
/*      */ 
/*      */       
/* 4900 */       int readResult = is.read(b, bufferOffset + offset, readLength);
/* 4901 */       if (readResult == -1) {
/*      */         break;
/*      */       }
/* 4904 */       bufferOffset += readResult;
/*      */     } 
/* 4906 */     return bufferOffset;
/*      */   }
/*      */   
/*      */   int tcp_read_pending(adwin_tcp_info_t ati, int min_bytes, adwin_tcp_buffer_t buf) throws ADwinCommunicationError {
/*      */     adwin_tcp_buffer_t resp;
/* 4911 */     int bytes_already_read = 0;
/*      */ 
/*      */ 
/*      */     
/* 4915 */     if (buf == null) {
/* 4916 */       resp = ati.resp;
/*      */     } else {
/* 4918 */       resp = buf;
/*      */     } 
/*      */     
/* 4921 */     if (resp.max < min_bytes) {
/* 4922 */       throw new ADwinCommunicationError("memory-error: not enough room in destination memory", "Speicher-Fehler!", this.Language, 0);
/*      */     }
/*      */     
/* 4925 */     if (ati.rx_pending < min_bytes) {
/*      */       
/* 4927 */       System.err.println("*** error: read pending ");
/* 4928 */       throw new ADwinCommunicationError("memory-error: not enough room in destination memory", "Speicher-Fehler!", this.Language, 0);
/*      */     } 
/*      */     
/* 4931 */     while (min_bytes > bytes_already_read) {
/* 4932 */       int bytes_current_transfer; if (min_bytes > bytes_already_read + ati.timeout_size) {
/* 4933 */         bytes_current_transfer = ati.timeout_size;
/*      */       } else {
/* 4935 */         bytes_current_transfer = min_bytes - bytes_already_read;
/*      */       } 
/*      */       try {
/* 4938 */         int ret = readInputStreamWithTimeout(ati.stream_in, resp.data, bytes_already_read, ati.timeout_ms, bytes_current_transfer);
/* 4939 */         if (check_tcp_ret(ret, bytes_current_transfer) == 1) {
/* 4940 */           System.err.println("*** readInputStreamWithTimeout returned: " + ret + " expected " + bytes_current_transfer);
/* 4941 */           throw new ADwinCommunicationError("Network timeout", "Netzwerk Timeout: ", this.Language, 2001);
/*      */         } 
/* 4943 */       } catch (IOException ex) {
/*      */         
/* 4945 */         System.err.println(ex.getMessage());
/* 4946 */         return -1;
/*      */       } 
/* 4948 */       bytes_already_read += bytes_current_transfer;
/*      */     } 
/*      */     
/* 4951 */     resp.used = bytes_already_read;
/* 4952 */     ati.rx_pending -= bytes_already_read;
/* 4953 */     do_convert(resp);
/* 4954 */     return 0;
/*      */   }
/*      */   
/*      */   void adwin_tcp_boot(String filename) throws IOException, ADwinCommunicationError {
/* 4958 */     boot_or_loadprocess(filename, 50);
/*      */   }
/*      */   
/*      */   void adwin_tcp_boot(byte[] Binary) throws IOException, ADwinCommunicationError {
/* 4962 */     boot_or_loadprocess(Binary, 50);
/*      */   }
/*      */   
/*      */   void adwin_tcp_load_process(String filename) throws IOException, ADwinCommunicationError {
/* 4966 */     boot_or_loadprocess(filename, 4);
/*      */   }
/*      */   
/*      */   void adwin_tcp_load_process(byte[] Binary) throws IOException, ADwinCommunicationError {
/* 4970 */     boot_or_loadprocess(Binary, 4);
/*      */   }
/*      */   
/*      */   void boot_or_loadprocess(String filename, int command) throws IOException, ADwinCommunicationError {
/* 4974 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/* 4975 */     req.max = 0;
/* 4976 */     req.used = 0;
/* 4977 */     req.do_convert = 0;
/* 4978 */     req.data = null;
/*      */     
/* 4980 */     init_ati(command);
/*      */     
/* 4982 */     FileInputStream fis = new FileInputStream(filename);
/* 4983 */     byte[] Binary = new byte[fis.available()];
/* 4984 */     fis.read(Binary);
/* 4985 */     fis.close();
/* 4986 */     if (Binary.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 4990 */     req.data = Binary;
/* 4991 */     req.max = req.used = Binary.length;
/*      */     
/* 4993 */     if (tcp_write_request(this.ati, req) == -1) {
/* 4994 */       check_tcp_ret(0, 1);
/*      */       
/*      */       return;
/*      */     } 
/* 4998 */     this.ati.resp.do_convert = 0;
/* 4999 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */   
/*      */   void boot_or_loadprocess(byte[] Binary, int command) throws IOException, ADwinCommunicationError {
/* 5003 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/* 5004 */     req.max = 0;
/* 5005 */     req.used = 0;
/* 5006 */     req.do_convert = 0;
/* 5007 */     req.data = null;
/*      */     
/* 5009 */     init_ati(command);
/*      */     
/* 5011 */     if (Binary.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5015 */     req.data = Binary;
/* 5016 */     req.max = req.used = Binary.length;
/*      */     
/* 5018 */     if (tcp_write_request(this.ati, req) == -1) {
/* 5019 */       check_tcp_ret(0, 1);
/*      */       
/*      */       return;
/*      */     } 
/* 5023 */     this.ati.resp.do_convert = 0;
/*      */     
/* 5025 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */   
/*      */   void command_4p4(int[] to_values, int[] from_values) throws ADwinCommunicationError {
/* 5029 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/* 5030 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5032 */     req.max = 16;
/* 5033 */     req.used = 16;
/* 5034 */     req.do_convert = 1;
/* 5035 */     req.data = new byte[16];
/* 5036 */     setInteger(req.data, 0, to_values[0]);
/* 5037 */     setInteger(req.data, 4, to_values[1]);
/* 5038 */     setInteger(req.data, 8, to_values[2]);
/* 5039 */     setInteger(req.data, 12, to_values[3]);
/* 5040 */     resp.max = 16;
/* 5041 */     resp.used = 0;
/* 5042 */     resp.do_convert = 2;
/* 5043 */     resp.data = new byte[16];
/*      */     
/* 5045 */     init_ati(0);
/* 5046 */     if (tcp_write_request(this.ati, req) == -1) {
/*      */       return;
/*      */     }
/* 5049 */     if (tcp_read_response(this.ati, 16, resp) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5053 */     from_values[0] = extractInt(resp.data, 0);
/* 5054 */     from_values[1] = extractInt(resp.data, 4);
/* 5055 */     from_values[2] = extractInt(resp.data, 8);
/* 5056 */     from_values[3] = extractInt(resp.data, 12);
/*      */   }
/*      */   
/*      */   void adwin_tcp_start_process(int processnumber) throws ADwinCommunicationError {
/* 5060 */     int[] from_values = new int[4];
/* 5061 */     int[] to_values = { 2, processnumber, 0, 0 };
/* 5062 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   void adwin_tcp_stop_process(int processnumber) throws ADwinCommunicationError {
/* 5066 */     int[] from_values = new int[4];
/* 5067 */     int[] to_values = { 3, processnumber, 0, 0 };
/* 5068 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   void adwin_tcp_clear_process(int processnumber) throws ADwinCommunicationError {
/* 5072 */     int[] from_values = new int[4];
/* 5073 */     int[] to_values = { 14, processnumber, 0, 0 };
/* 5074 */     command_4p4(to_values, from_values);
/*      */   }
/*      */ 
/*      */   
/*      */   int adwin_tcp_process_status(int processnumber) throws ADwinCommunicationError {
/* 5079 */     return adwin_tcp_get_par(-100 + processnumber);
/*      */   }
/*      */   
/*      */   int adwin_tcp_get_processdelay(int processnumber) throws ADwinCommunicationError {
/* 5083 */     return adwin_tcp_get_par(-90 + processnumber);
/*      */   }
/*      */   
/*      */   void adwin_tcp_set_processdelay(int processnumber, int delay) throws ADwinCommunicationError {
/* 5087 */     adwin_tcp_set_par(-90 + processnumber, delay);
/*      */   }
/*      */   
/*      */   float adwin_tcp_workload() throws ADwinCommunicationError {
/* 5091 */     float workload = -1.0F;
/*      */     
/* 5093 */     init_ati(20);
/*      */     
/* 5095 */     if (tcp_write_request(this.ati, null) == -1) {
/* 5096 */       return -1.0F;
/*      */     }
/* 5098 */     if (tcp_read_response(this.ati, 16, null) == -1) {
/* 5099 */       return -1.0F;
/*      */     }
/*      */     
/* 5102 */     if (this.ati.processortype != 1012) {
/*      */ 
/*      */ 
/*      */       
/* 5106 */       int val1 = extractInt(this.ati.resp.data, 0);
/* 5107 */       int t1 = extractInt(this.ati.resp.data, 4);
/* 5108 */       int workload_calculated_by_dsp = extractInt(this.ati.resp.data, 8);
/*      */       
/* 5110 */       if (workload_calculated_by_dsp == 0) {
/* 5111 */         if (t1 == 0) {
/* 5112 */           return 100.0F;
/*      */         }
/* 5114 */         float help1 = val1 / t1;
/* 5115 */         if (help1 == 0.0F) {
/* 5116 */           return 100.0F;
/*      */         }
/* 5118 */         if (this.ati.processortype == 1011) {
/* 5119 */           workload = 100.0F * (0.11111111F - help1) * 9.0F;
/*      */         } else {
/*      */           
/* 5122 */           workload = 100.0F * (0.25F - help1) / 0.25F;
/*      */         } 
/*      */       } else {
/*      */         
/* 5126 */         workload = val1;
/*      */       } 
/*      */     } else {
/* 5129 */       workload = extractInt(this.ati.resp.data, 0);
/*      */     } 
/*      */     
/* 5132 */     if (workload > 100.0F) {
/* 5133 */       return 100.0F;
/*      */     }
/* 5135 */     if (workload < 0.0F) {
/* 5136 */       return 0.0F;
/*      */     }
/* 5138 */     return workload;
/*      */   }
/*      */ 
/*      */   
/*      */   int adwin_tcp_get_par(int par_no) throws ADwinCommunicationError {
/* 5143 */     int[] from_values = new int[4];
/* 5144 */     int[] to_values = { 1, par_no + 1000, 0, 0 };
/* 5145 */     command_4p4(to_values, from_values);
/* 5146 */     return from_values[0];
/*      */   }
/*      */   
/*      */   void adwin_tcp_set_par(int par_no, int value) throws ADwinCommunicationError {
/* 5150 */     int[] from_values = new int[4];
/* 5151 */     int[] to_values = { 6, par_no + 1000, value, 0 };
/* 5152 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   float adwin_tcp_get_fpar(int par_no) throws ADwinCommunicationError {
/* 5156 */     int[] from_values = new int[4];
/* 5157 */     int[] to_values = { 1, par_no + 1100, 0, 0 };
/* 5158 */     command_4p4(to_values, from_values);
/* 5159 */     return Float.intBitsToFloat(from_values[0]);
/*      */   }
/*      */   
/*      */   void adwin_tcp_set_fpar(int par_no, float value) throws ADwinCommunicationError {
/* 5163 */     int[] from_values = new int[4];
/* 5164 */     int[] to_values = { 6, par_no + 1100, Float.floatToIntBits(value), 0 };
/* 5165 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   double adwin_tcp_get_fpar_double(int par_no) throws ADwinCommunicationError {
/* 5169 */     if (this.ati.processortype != 1012) {
/* 5170 */       return adwin_tcp_get_fpar(par_no);
/*      */     }
/* 5172 */     byte[] bdata = new byte[8];
/* 5173 */     int[] from_values = new int[4];
/* 5174 */     int[] to_values = { 1, par_no + 1200, 0, 0 };
/* 5175 */     command_4p4(to_values, from_values);
/*      */     
/* 5177 */     setInteger(bdata, 0, from_values[0]);
/* 5178 */     setInteger(bdata, 4, from_values[1]);
/* 5179 */     return ByteBuffer.wrap(bdata).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*      */   }
/*      */   
/*      */   void adwin_tcp_set_fpar_double(int par_no, double value) throws ADwinCommunicationError {
/* 5183 */     if (this.ati.processortype != 1012) {
/* 5184 */       adwin_tcp_set_fpar(par_no, (float)value);
/*      */       return;
/*      */     } 
/* 5187 */     int[] from_values = new int[4];
/* 5188 */     long dummy = Double.doubleToLongBits(value);
/* 5189 */     int[] to_values = { 6, par_no + 1200, (int)(dummy >> 32L), (int)dummy };
/* 5190 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   void adwin_tcp_get_par_block(int start, int count, int[] pars) throws ADwinCommunicationError {
/* 5194 */     init_ati(13);
/* 5195 */     setInteger(this.ati.req.data, 0, start);
/* 5196 */     setInteger(this.ati.req.data, 4, count);
/* 5197 */     this.ati.req.used = 8;
/*      */     
/* 5199 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5203 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/* 5204 */     resp.data = new byte[count * 4];
/* 5205 */     resp.max = count * 4;
/* 5206 */     resp.used = 0;
/* 5207 */     resp.do_convert = 0;
/* 5208 */     if (tcp_read_response(this.ati, resp.max, resp) == -1) {
/*      */       return;
/*      */     }
/* 5211 */     for (int i = 0; i < count; i++) {
/* 5212 */       pars[i] = extractInt(resp.data, i * 4);
/*      */     }
/*      */   }
/*      */   
/*      */   void adwin_tcp_get_par_all(int[] pars) throws ADwinCommunicationError {
/* 5217 */     adwin_tcp_get_par_block(1, 80, pars);
/*      */   }
/*      */   
/*      */   void adwin_tcp_get_fpar_block(int start, int count, float[] fpars) throws ADwinCommunicationError {
/* 5221 */     int[] idummy = new int[count];
/* 5222 */     adwin_tcp_get_par_block(100 + start, count, idummy);
/* 5223 */     for (int i = 0; i < count; i++) {
/* 5224 */       fpars[i] = Float.intBitsToFloat(idummy[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   void adwin_tcp_get_fpar_all(float[] fpars) throws ADwinCommunicationError {
/* 5229 */     int[] idummy = new int[80];
/* 5230 */     adwin_tcp_get_par_block(101, 80, idummy);
/* 5231 */     for (int i = 0; i < 80; i++) {
/* 5232 */       fpars[i] = Float.intBitsToFloat(idummy[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_fpar_block_double(int start, int count, double[] dpars) throws ADwinCommunicationError {
/* 5240 */     if (this.ati.processortype != 1012) {
/* 5241 */       int[] pars = new int[count];
/* 5242 */       adwin_tcp_get_par_block(100 + start, count, pars);
/* 5243 */       for (int i = 0; i < count; i++) {
/* 5244 */         dpars[i] = Float.intBitsToFloat(pars[i]);
/*      */       }
/*      */     } else {
/* 5247 */       init_ati(13);
/* 5248 */       setInteger(this.ati.req.data, 0, 200 + start);
/* 5249 */       setInteger(this.ati.req.data, 4, count * 2);
/* 5250 */       this.ati.req.used = 8;
/*      */       
/* 5252 */       if (tcp_write_request(this.ati, null) == -1) {
/*      */         return;
/*      */       }
/*      */       
/* 5256 */       adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/* 5257 */       resp.data = new byte[count * 8];
/* 5258 */       resp.max = count * 8;
/* 5259 */       resp.used = 0;
/* 5260 */       resp.do_convert = 0;
/* 5261 */       if (tcp_read_response(this.ati, resp.max, resp) == -1) {
/*      */         return;
/*      */       }
/*      */       
/* 5265 */       for (int i = 0; i < count; i++) {
/* 5266 */         dpars[i] = ByteBuffer.wrap(resp.data, i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_fpar_all_double(double[] dpars) throws ADwinCommunicationError {
/* 5275 */     if (this.ati.processortype != 1012) {
/* 5276 */       int[] pars = new int[80];
/* 5277 */       adwin_tcp_get_par_block(101, 80, pars);
/* 5278 */       for (int i = 0; i < 80; i++) {
/* 5279 */         dpars[i] = Float.intBitsToFloat(pars[i]);
/*      */       }
/*      */     } else {
/* 5282 */       adwin_tcp_get_fpar_block_double(1, 80, dpars);
/*      */     } 
/*      */   }
/*      */   
/*      */   int adwin_tcp_free_mem(int mem_spec) throws ADwinCommunicationError {
/* 5287 */     int[] from_values = new int[4];
/* 5288 */     int[] to_values = { 12, mem_spec, 0, 0 };
/* 5289 */     command_4p4(to_values, from_values);
/* 5290 */     return from_values[0];
/*      */   }
/*      */   
/*      */   void adwin_tcp_peek(int address, int count, int[] pc_array) throws ADwinCommunicationError {
/* 5294 */     init_ati(1000000);
/* 5295 */     this.ati.req.used = 8;
/*      */     
/* 5297 */     setInteger(this.ati.req.data, 0, address);
/* 5298 */     setInteger(this.ati.req.data, 4, count);
/*      */     
/* 5300 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5304 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/* 5305 */     resp.data = new byte[count * 4];
/* 5306 */     resp.max = count * 4;
/* 5307 */     resp.used = 0;
/* 5308 */     resp.do_convert = 0;
/*      */     
/* 5310 */     if (tcp_read_response(this.ati, resp.max, resp) == -1) {
/*      */       return;
/*      */     }
/* 5313 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5317 */     for (int i = 0; i < count; i++) {
/* 5318 */       pc_array[i] = extractInt(resp.data, i * 4);
/*      */     }
/*      */   }
/*      */   
/*      */   int bytes_per_value(adwin_data_type_t adt) {
/* 5323 */     switch (adt) {
/*      */       case ADWIN_BYTE:
/*      */       case ADWIN_STRING:
/* 5326 */         return 1;
/*      */       case ADWIN_SHORT:
/* 5328 */         return 2;
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/*      */       case ADWIN_FLOAT:
/* 5332 */         return 4;
/*      */       case ADWIN_DOUBLE:
/*      */       case ADWIN_INT64:
/* 5335 */         return 8;
/*      */     } 
/* 5337 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   adwin_data_type_t int_to_adwin_data_type(int type) {
/* 5342 */     switch (type) {
/*      */       case 1:
/* 5344 */         return adwin_data_type_t.ADWIN_BYTE;
/*      */       case 2:
/* 5346 */         return adwin_data_type_t.ADWIN_SHORT;
/*      */       case 3:
/* 5348 */         return adwin_data_type_t.ADWIN_LONG;
/*      */       case 4:
/* 5350 */         return adwin_data_type_t.ADWIN_INTEGER;
/*      */       case 5:
/* 5352 */         return adwin_data_type_t.ADWIN_FLOAT;
/*      */       case 6:
/* 5354 */         return adwin_data_type_t.ADWIN_DOUBLE;
/*      */       case 7:
/* 5356 */         return adwin_data_type_t.ADWIN_INT64;
/*      */       case 8:
/* 5358 */         return adwin_data_type_t.ADWIN_STRING;
/*      */       case 20:
/* 5360 */         return adwin_data_type_t.ADWIN_VARIANT;
/*      */     } 
/* 5362 */     return adwin_data_type_t.ADWIN_DATA_TYPE_INVALID;
/*      */   }
/*      */ 
/*      */   
/*      */   int adwin_tcp_get_data_type(int datanumber) throws ADwinCommunicationError {
/* 5367 */     init_ati(100);
/* 5368 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5369 */     this.ati.req.used = 4;
/*      */     
/* 5371 */     if (tcp_write_request(this.ati, null) == -1) {
/* 5372 */       return 0;
/*      */     }
/* 5374 */     if (tcp_read_response(this.ati, 4, null) == -1) {
/* 5375 */       return 0;
/*      */     }
/* 5377 */     return extractInt(this.ati.resp.data, 0);
/*      */   }
/*      */   
/*      */   int adwin_tcp_get_data_length(int datanumber) throws ADwinCommunicationError {
/* 5381 */     int[] from_values = new int[4];
/* 5382 */     int[] to_values = { 11, datanumber, 0, 0 };
/* 5383 */     command_4p4(to_values, from_values);
/* 5384 */     return from_values[0];
/*      */   }
/*      */   
/*      */   void adwin_tcp_clear_data(int datanumber) throws ADwinCommunicationError {
/* 5388 */     int[] from_values = new int[4];
/* 5389 */     int[] to_values = { 9, datanumber, 0, 0 };
/* 5390 */     command_4p4(to_values, from_values);
/*      */   }
/*      */   
/*      */   int adwin_tcp_fifo_full(int datanumber) throws ADwinCommunicationError {
/* 5394 */     int[] from_values = new int[4];
/* 5395 */     int[] to_values = { 23, datanumber, 0, 0 };
/* 5396 */     command_4p4(to_values, from_values);
/* 5397 */     return from_values[0];
/*      */   }
/*      */   
/*      */   int adwin_tcp_fifo_empty(int datanumber) throws ADwinCommunicationError {
/* 5401 */     int[] from_values = new int[4];
/* 5402 */     int[] to_values = { 22, datanumber, 0, 0 };
/* 5403 */     command_4p4(to_values, from_values);
/* 5404 */     return from_values[0];
/*      */   }
/*      */   
/*      */   void adwin_tcp_fifo_clear(int datanumber) throws ADwinCommunicationError {
/* 5408 */     int[] from_values = new int[4];
/* 5409 */     int[] to_values = { 21, datanumber, 0, 0 };
/* 5410 */     command_4p4(to_values, from_values);
/*      */   }
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_data_or_fifo_int32(int datanumber, int[] data, int start, int count, int get_fifo) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     float[] fdata;
/*      */     double[] ddata;
/* 5417 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5419 */     if (count < 1) {
/* 5420 */       throw new IllegalArgumentException("get_data count < 1");
/*      */     }
/*      */     
/* 5423 */     if (get_fifo == 1) {
/* 5424 */       init_ati(24);
/*      */     } else {
/* 5426 */       init_ati(7);
/*      */     } 
/*      */     
/* 5429 */     this.ati.req.used = 12;
/* 5430 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5431 */     setInteger(this.ati.req.data, 4, start);
/* 5432 */     setInteger(this.ati.req.data, 8, count);
/* 5433 */     this.ati.req.max = count * 4;
/*      */     
/* 5435 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5438 */     if (tcp_read_response(this.ati, 12, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5442 */     adwin_data_type_t adwin_datatype = int_to_adwin_data_type(extractInt(this.ati.resp.data, 0));
/* 5443 */     int count_b = count * bytes_per_value(adwin_datatype);
/*      */     
/* 5445 */     if (bytes_per_value(adwin_datatype) < 0) {
/* 5446 */       this.ati.status = 150;
/* 5447 */       tcp_discard_pending(this.ati);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5452 */     resp.data = new byte[count_b];
/* 5453 */     byte[] buf = resp.data;
/*      */     
/* 5455 */     if (resp.data == null) {
/* 5456 */       throw new ADwinCommunicationError("Not enough memory or memory access error.", "Nicht genug Speicher oder Speicherzugriffsfehler.", this.Language, 150);
/*      */     }
/*      */ 
/*      */     
/* 5460 */     resp.max = count_b;
/* 5461 */     resp.do_convert = 0;
/* 5462 */     resp.used = 0;
/* 5463 */     if (tcp_read_pending(this.ati, count_b, resp) == -1) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5468 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5472 */     if (extractInt(this.ati.resp.data, 0) != 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5476 */     switch (adwin_datatype) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 5479 */         convert_data_from_stream_to_int(buf, data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 5482 */         fdata = new float[count];
/* 5483 */         convert_data_from_stream_to_float(buf, fdata, count);
/* 5484 */         convert_data_from_float_to_int(fdata, data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 5487 */         ddata = new double[count];
/* 5488 */         convert_data_from_stream_to_double(buf, ddata, count);
/* 5489 */         convert_data_from_double_to_int(ddata, data, count);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   void adwin_tcp_get_data_or_fifo_int64(int datanumber, long[] data, int start, int count, int get_fifo) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     int[] idata;
/*      */     float[] fdata;
/*      */     double[] ddata;
/* 5497 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5499 */     if (count < 1) {
/* 5500 */       throw new IllegalArgumentException("get_data count < 1");
/*      */     }
/*      */     
/* 5503 */     if (get_fifo == 1) {
/* 5504 */       init_ati(24);
/*      */     } else {
/* 5506 */       init_ati(7);
/*      */     } 
/*      */     
/* 5509 */     this.ati.req.used = 12;
/* 5510 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5511 */     setInteger(this.ati.req.data, 4, start);
/* 5512 */     setInteger(this.ati.req.data, 8, count);
/* 5513 */     this.ati.req.max = count * 4;
/*      */     
/* 5515 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5518 */     if (tcp_read_response(this.ati, 12, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5522 */     adwin_data_type_t adwin_datatype = int_to_adwin_data_type(extractInt(this.ati.resp.data, 0));
/* 5523 */     int count_b = count * bytes_per_value(adwin_datatype);
/*      */     
/* 5525 */     if (bytes_per_value(adwin_datatype) < 0) {
/* 5526 */       this.ati.status = 150;
/* 5527 */       tcp_discard_pending(this.ati);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5532 */     resp.data = new byte[count_b];
/* 5533 */     byte[] buf = resp.data;
/*      */     
/* 5535 */     if (resp.data == null) {
/* 5536 */       throw new ADwinCommunicationError("Not enough memory or memory access error.", "Nicht genug Speicher oder Speicherzugriffsfehler.", this.Language, 150);
/*      */     }
/*      */ 
/*      */     
/* 5540 */     resp.max = count_b;
/* 5541 */     resp.do_convert = 0;
/* 5542 */     resp.used = 0;
/* 5543 */     if (tcp_read_pending(this.ati, count_b, resp) == -1) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5548 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5552 */     if (extractInt(this.ati.resp.data, 0) != 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5556 */     switch (adwin_datatype) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 5559 */         idata = new int[count];
/* 5560 */         convert_data_from_stream_to_int(buf, idata, count);
/* 5561 */         convert_data_from_int_to_long(idata, data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 5564 */         fdata = new float[count];
/* 5565 */         convert_data_from_stream_to_float(buf, fdata, count);
/* 5566 */         convert_data_from_float_to_long(fdata, data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 5569 */         ddata = new double[count];
/* 5570 */         convert_data_from_stream_to_double(buf, ddata, count);
/* 5571 */         convert_data_from_double_to_long(ddata, data, count);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_data_or_fifo_int8(int datanumber, byte[] data, int start, int count, int get_fifo) throws ADwinCommunicationError, IllegalArgumentException {
/* 5582 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5584 */     if (count < 1) {
/* 5585 */       throw new IllegalArgumentException("get_data count < 1");
/*      */     }
/*      */     
/* 5588 */     if (get_fifo == 1) {
/* 5589 */       init_ati(24);
/*      */     } else {
/* 5591 */       init_ati(7);
/*      */     } 
/*      */     
/* 5594 */     this.ati.req.used = 12;
/* 5595 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5596 */     setInteger(this.ati.req.data, 4, start);
/* 5597 */     setInteger(this.ati.req.data, 8, count);
/*      */     
/* 5599 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5602 */     if (tcp_read_response(this.ati, 12, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5606 */     adwin_data_type_t adwin_datatype = int_to_adwin_data_type(extractInt(this.ati.resp.data, 0));
/* 5607 */     if (bytes_per_value(adwin_datatype) != 1) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5612 */     int count_b = count;
/*      */     
/* 5614 */     resp.data = new byte[count_b];
/* 5615 */     byte[] buf = resp.data;
/*      */     
/* 5617 */     if (resp.data == null) {
/* 5618 */       throw new ADwinCommunicationError("Not enough memory or memory access error.", "Nicht genug Speicher oder Speicherzugriffsfehler.", this.Language, 150);
/*      */     }
/*      */ 
/*      */     
/* 5622 */     resp.max = count_b;
/* 5623 */     resp.do_convert = 0;
/* 5624 */     resp.used = 0;
/* 5625 */     if (tcp_read_pending(this.ati, count_b, resp) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5629 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5633 */     if (extractInt(this.ati.resp.data, 0) != 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5637 */     System.arraycopy(buf, 0, data, 0, count);
/*      */   }
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_data_or_fifo_float(int datanumber, float[] data, int start, int count, int get_fifo) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     int[] idata;
/*      */     double[] ddata;
/* 5644 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5646 */     if (count < 1) {
/* 5647 */       throw new IllegalArgumentException("get_data count < 1");
/*      */     }
/*      */     
/* 5650 */     if (get_fifo == 1) {
/* 5651 */       init_ati(24);
/*      */     } else {
/* 5653 */       init_ati(7);
/*      */     } 
/*      */     
/* 5656 */     this.ati.req.used = 12;
/* 5657 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5658 */     setInteger(this.ati.req.data, 4, start);
/* 5659 */     setInteger(this.ati.req.data, 8, count);
/*      */     
/* 5661 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5664 */     if (tcp_read_response(this.ati, 12, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5668 */     adwin_data_type_t adwin_datatype = int_to_adwin_data_type(extractInt(this.ati.resp.data, 0));
/* 5669 */     int count_b = count * bytes_per_value(adwin_datatype);
/*      */     
/* 5671 */     if (bytes_per_value(adwin_datatype) < 0) {
/* 5672 */       this.ati.status = 150;
/* 5673 */       tcp_discard_pending(this.ati);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5678 */     resp.data = new byte[count_b];
/* 5679 */     byte[] buf = resp.data;
/*      */     
/* 5681 */     if (resp.data == null) {
/* 5682 */       throw new ADwinCommunicationError("Not enough memory or memory access error.", "Nicht genug Speicher oder Speicherzugriffsfehler.", this.Language, 150);
/*      */     }
/*      */ 
/*      */     
/* 5686 */     resp.max = count_b;
/* 5687 */     resp.do_convert = 0;
/* 5688 */     resp.used = 0;
/* 5689 */     if (tcp_read_pending(this.ati, count_b, resp) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5693 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5697 */     if (extractInt(this.ati.resp.data, 0) != 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5701 */     switch (adwin_datatype) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 5704 */         idata = new int[count];
/* 5705 */         convert_data_from_stream_to_int(buf, idata, count);
/* 5706 */         convert_data_from_int_to_float(idata, data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 5709 */         convert_data_from_stream_to_float(buf, data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 5712 */         ddata = new double[count];
/* 5713 */         convert_data_from_stream_to_double(buf, ddata, count);
/* 5714 */         convert_data_from_double_to_float(ddata, data, count);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void adwin_tcp_get_data_or_fifo_double(int datanumber, double[] data, int start, int count, int get_fifo) throws ADwinCommunicationError, IllegalArgumentException {
/*      */     int[] idata;
/*      */     float[] fdata;
/* 5723 */     adwin_tcp_buffer_t resp = new adwin_tcp_buffer_t();
/*      */     
/* 5725 */     if (count < 1) {
/* 5726 */       throw new IllegalArgumentException("get_data count < 1");
/*      */     }
/*      */     
/* 5729 */     if (get_fifo == 1) {
/* 5730 */       init_ati(24);
/*      */     } else {
/* 5732 */       init_ati(7);
/*      */     } 
/*      */     
/* 5735 */     this.ati.req.used = 12;
/* 5736 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5737 */     setInteger(this.ati.req.data, 4, start);
/* 5738 */     setInteger(this.ati.req.data, 8, count);
/*      */     
/* 5740 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5743 */     if (tcp_read_response(this.ati, 12, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5747 */     adwin_data_type_t adwin_datatype = int_to_adwin_data_type(extractInt(this.ati.resp.data, 0));
/* 5748 */     int count_b = count * bytes_per_value(adwin_datatype);
/*      */     
/* 5750 */     if (bytes_per_value(adwin_datatype) < 0) {
/* 5751 */       this.ati.status = 150;
/* 5752 */       tcp_discard_pending(this.ati);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5757 */     resp.data = new byte[count_b];
/* 5758 */     byte[] buf = resp.data;
/*      */     
/* 5760 */     if (resp.data == null) {
/* 5761 */       throw new ADwinCommunicationError("Not enough memory or memory access error.", "Nicht genug Speicher oder Speicherzugriffsfehler.", this.Language, 150);
/*      */     }
/*      */ 
/*      */     
/* 5765 */     resp.max = count_b;
/* 5766 */     resp.do_convert = 0;
/* 5767 */     resp.used = 0;
/* 5768 */     if (tcp_read_pending(this.ati, count_b, resp) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5772 */     if (tcp_read_pending(this.ati, 4, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5776 */     if (extractInt(this.ati.resp.data, 0) != 0) {
/*      */       return;
/*      */     }
/*      */     
/* 5780 */     switch (adwin_datatype) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 5783 */         idata = new int[count];
/* 5784 */         convert_data_from_stream_to_int(buf, idata, count);
/* 5785 */         convert_data_from_int_to_double(idata, data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 5788 */         fdata = new float[count];
/* 5789 */         convert_data_from_stream_to_float(buf, fdata, count);
/* 5790 */         convert_data_from_float_to_double(fdata, data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 5793 */         convert_data_from_stream_to_double(buf, data, count);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String adwin_tcp_get_data_string(int datanumber, int max_count) throws ADwinCommunicationError {
/* 5803 */     byte[] str = new byte[max_count];
/*      */     
/* 5805 */     if (max_count < 1) {
/* 5806 */       return "";
/*      */     }
/*      */ 
/*      */     
/* 5810 */     if (this.ati.processortype == 1012) {
/* 5811 */       adwin_tcp_get_data_or_fifo_int8(datanumber, str, 0, max_count, 0);
/*      */       
/* 5813 */       return new String(str);
/*      */     } 
/*      */     
/* 5816 */     str = new byte[4 * (max_count + 1)];
/* 5817 */     int[] idata = new int[max_count + 1];
/* 5818 */     adwin_tcp_get_data_or_fifo_int32(datanumber, idata, 1, max_count + 1, 0); int i;
/* 5819 */     for (i = 0; i < max_count + 1; i++) {
/* 5820 */       str[i] = (byte)idata[i];
/*      */     }
/* 5822 */     int strlen = str[0];
/*      */     
/* 5824 */     byte[] tmp = new byte[strlen];
/* 5825 */     for (i = 0; i < strlen; i++) {
/* 5826 */       byte val = str[i * 4 + 3];
/* 5827 */       if (val > 0 && val < 256) {
/* 5828 */         tmp[i] = val;
/*      */       } else {
/* 5830 */         tmp[i] = 0;
/*      */         break;
/*      */       } 
/*      */     } 
/* 5834 */     tmp[strlen - 1] = 0;
/* 5835 */     return new String(tmp);
/*      */   }
/*      */ 
/*      */   
/*      */   int adwin_tcp_string_length(int datanumber) throws ADwinCommunicationError {
/* 5840 */     int[] from_values = new int[4];
/* 5841 */     if (this.ati.processortype == 1012) {
/* 5842 */       int[] to_values = { 44, datanumber, 0, 0 };
/* 5843 */       command_4p4(to_values, from_values);
/*      */     } else {
/*      */       
/* 5846 */       adwin_tcp_get_data_or_fifo_int32(datanumber, from_values, 1, 1, 0);
/*      */     } 
/*      */     
/* 5849 */     return from_values[0];
/*      */   }
/*      */   
/*      */   void adwin_tcp_get_data_info(int datanumber, int[] values) throws ADwinCommunicationError {
/* 5853 */     init_ati(45);
/* 5854 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5855 */     this.ati.req.used = 4;
/*      */     
/* 5857 */     if (tcp_write_request(this.ati, null) == -1) {
/*      */       return;
/*      */     }
/* 5860 */     if (tcp_read_response(this.ati, 16, null) == -1) {
/*      */       return;
/*      */     }
/*      */     
/* 5864 */     values[0] = extractInt(this.ati.resp.data, 0);
/* 5865 */     values[1] = extractInt(this.ati.resp.data, 4);
/* 5866 */     values[2] = extractInt(this.ati.resp.data, 8);
/* 5867 */     values[3] = extractInt(this.ati.resp.data, 12);
/*      */   }
/*      */ 
/*      */   
/*      */   void adwin_tcp_set_data_or_fifo_int8(int datanumber, byte[] data, int start, int count, int set_fifo) throws ADwinCommunicationError {
/*      */     int i, idata[];
/*      */     float[] fdata;
/*      */     double[] ddata;
/* 5875 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/*      */     
/* 5877 */     if (count < 1) {
/* 5878 */       throw new IllegalArgumentException((this.Language == 1) ? ("setting DATA_" + datanumber + ": Only a positive Number of elements can be set!") : (
/* 5879 */           "Nur eine positive Anzahl von Elementen kann bei DATA_" + datanumber + " gesetzt werden!"));
/*      */     }
/*      */     
/* 5882 */     int[] info = new int[4];
/* 5883 */     adwin_tcp_get_data_info(datanumber, info);
/* 5884 */     if (this.ati.error_number != 0) {
/*      */       return;
/*      */     }
/* 5887 */     adwin_data_type_t adt = int_to_adwin_data_type(info[0]);
/* 5888 */     int data_size = info[1];
/* 5889 */     int is_fifo = info[2];
/* 5890 */     int fifo_full = info[3];
/*      */ 
/*      */     
/* 5893 */     if (data_size < start - 1 + count) {
/* 5894 */       throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */     }
/*      */     
/* 5897 */     if (this.ati.processortype == 1012) {
/* 5898 */       if (is_fifo == 1 && set_fifo == 1 && count > data_size - fifo_full) {
/* 5899 */         throw new ADwinCommunicationError("There is not enough space left in fifo " + datanumber, "Nicht genug Platz übrig in Fifo " + datanumber, this.Language, 101);
/*      */       }
/* 5901 */       if (set_fifo == 1 && is_fifo == 0) {
/* 5902 */         throw new ADwinCommunicationError("Data " + datanumber + " isn't a fifo!", "Data " + datanumber + " ist nicht als FIFO deklariert!", this.Language, 101);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 5907 */     int count_b = count * bytes_per_value(adt);
/* 5908 */     req.data = new byte[count_b];
/* 5909 */     switch (adt) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 5912 */         idata = new int[count];
/* 5913 */         convert_data_from_byte_to_int(data, idata, count);
/* 5914 */         convert_data_from_int_to_stream(idata, req.data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 5917 */         fdata = new float[count];
/* 5918 */         for (i = 0; i < count; i++) {
/* 5919 */           fdata[i] = data[i];
/*      */         }
/* 5921 */         convert_data_from_float_to_stream(fdata, req.data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 5924 */         ddata = new double[count];
/* 5925 */         for (i = 0; i < count; i++) {
/* 5926 */           ddata[i] = data[i];
/*      */         }
/* 5928 */         convert_data_from_double_to_stream(ddata, req.data, count);
/*      */         break;
/*      */       case ADWIN_BYTE:
/*      */       case ADWIN_STRING:
/* 5932 */         req.data = data;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5942 */     if (set_fifo == 1) {
/* 5943 */       init_ati(25);
/*      */     } else {
/* 5945 */       init_ati(8);
/*      */     } 
/* 5947 */     setInteger(this.ati.req.data, 0, datanumber);
/* 5948 */     setInteger(this.ati.req.data, 4, start);
/* 5949 */     setInteger(this.ati.req.data, 8, count);
/* 5950 */     setInteger(this.ati.req.data, 12, info[0]);
/*      */     
/* 5952 */     this.ati.req.used = 16;
/* 5953 */     req.do_convert = 0;
/* 5954 */     req.used = count_b;
/*      */     
/* 5956 */     if (tcp_write_request(this.ati, req) == -1) {
/*      */       return;
/*      */     }
/* 5959 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */ 
/*      */   
/*      */   void adwin_tcp_set_data_or_fifo_int32(int datanumber, int[] data, int start, int count, int set_fifo) throws ADwinCommunicationError {
/*      */     int i;
/*      */     float[] fdata;
/*      */     double[] ddata;
/* 5967 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/*      */     
/* 5969 */     if (count < 1) {
/* 5970 */       throw new IllegalArgumentException((this.Language == 1) ? ("setting DATA_" + datanumber + ": Only a positive Number of elements can be set!") : (
/* 5971 */           "Nur eine positive Anzahl von Elementen kann bei DATA_" + datanumber + " gesetzt werden!"));
/*      */     }
/*      */     
/* 5974 */     int[] info = new int[4];
/* 5975 */     adwin_tcp_get_data_info(datanumber, info);
/* 5976 */     if (this.ati.error_number != 0) {
/*      */       return;
/*      */     }
/* 5979 */     adwin_data_type_t adt = int_to_adwin_data_type(info[0]);
/* 5980 */     int data_size = info[1];
/* 5981 */     int is_fifo = info[2];
/* 5982 */     int fifo_full = info[3];
/*      */     
/* 5984 */     if (adt == adwin_data_type_t.ADWIN_DATA_TYPE_INVALID) {
/* 5985 */       throw new ADwinCommunicationError("The Data array is not declared", "Das Data ist nicht deklariert", this.Language, 103);
/*      */     }
/*      */ 
/*      */     
/* 5989 */     if (data_size < start - 1 + count) {
/* 5990 */       if (set_fifo == 0) {
/* 5991 */         throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */       }
/* 5993 */       throw new ADwinCommunicationError("The Fifo is too small or not enough values", "Das Fifo-Feld ist zu klein oder nicht genug Daten", this.Language, 101);
/*      */     } 
/*      */ 
/*      */     
/* 5997 */     if (this.ati.processortype == 1012) {
/* 5998 */       if (is_fifo == 1 && set_fifo == 1 && count > data_size - fifo_full) {
/* 5999 */         throw new ADwinCommunicationError("The Fifo is too small or not enough values", "Das Fifo-Feld ist zu klein oder nicht genug Daten", this.Language, 101);
/*      */       }
/* 6001 */       if (set_fifo == 1 && is_fifo == 0) {
/* 6002 */         throw new ADwinCommunicationError("Data " + datanumber + " isn't a fifo!", "Data " + datanumber + " ist nicht als FIFO deklariert!", this.Language, 101);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 6007 */     int count_b = count * bytes_per_value(adt);
/* 6008 */     req.data = new byte[count_b];
/* 6009 */     switch (adt) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 6012 */         convert_data_from_int_to_stream(data, req.data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 6015 */         fdata = new float[count];
/* 6016 */         for (i = 0; i < count; i++) {
/* 6017 */           fdata[i] = data[i];
/*      */         }
/* 6019 */         convert_data_from_float_to_stream(fdata, req.data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 6022 */         ddata = new double[count];
/* 6023 */         for (i = 0; i < count; i++) {
/* 6024 */           ddata[i] = data[i];
/*      */         }
/* 6026 */         convert_data_from_double_to_stream(ddata, req.data, count);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6036 */     if (set_fifo == 1) {
/* 6037 */       init_ati(25);
/*      */     } else {
/* 6039 */       init_ati(8);
/*      */     } 
/* 6041 */     setInteger(this.ati.req.data, 0, datanumber);
/* 6042 */     setInteger(this.ati.req.data, 4, start);
/* 6043 */     setInteger(this.ati.req.data, 8, count);
/* 6044 */     setInteger(this.ati.req.data, 12, info[0]);
/*      */     
/* 6046 */     this.ati.req.used = 16;
/* 6047 */     req.do_convert = 0;
/* 6048 */     req.used = count_b;
/*      */     
/* 6050 */     if (tcp_write_request(this.ati, req) == -1) {
/*      */       return;
/*      */     }
/* 6053 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void adwin_tcp_set_data_or_fifo_float(int datanumber, float[] data, int start, int count, int set_fifo) throws ADwinCommunicationError {
/*      */     int[] idata;
/*      */     double[] ddata;
/* 6061 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/*      */     
/* 6063 */     if (count < 1) {
/* 6064 */       throw new IllegalArgumentException((this.Language == 1) ? ("setting DATA_" + datanumber + ": Only a positive Number of elements can be set!") : (
/* 6065 */           "Nur eine positive Anzahl von Elementen kann bei DATA_" + datanumber + " gesetzt werden!"));
/*      */     }
/*      */     
/* 6068 */     int[] info = new int[4];
/* 6069 */     adwin_tcp_get_data_info(datanumber, info);
/* 6070 */     if (this.ati.error_number != 0) {
/*      */       return;
/*      */     }
/* 6073 */     adwin_data_type_t adt = int_to_adwin_data_type(info[0]);
/* 6074 */     int data_size = info[1];
/* 6075 */     int is_fifo = info[2];
/* 6076 */     int fifo_full = info[3];
/*      */ 
/*      */     
/* 6079 */     if (data_size < start - 1 + count) {
/* 6080 */       throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */     }
/*      */     
/* 6083 */     if (this.ati.processortype == 1012) {
/* 6084 */       if (is_fifo == 1 && set_fifo == 1 && count > data_size - fifo_full) {
/* 6085 */         throw new ADwinCommunicationError("There is not enough space left in fifo " + datanumber, "Nicht genug Platz übrig in Fifo " + datanumber, this.Language, 101);
/*      */       }
/* 6087 */       if (set_fifo == 1 && is_fifo == 0) {
/* 6088 */         throw new ADwinCommunicationError("Data " + datanumber + " isn't a fifo!", "Data " + datanumber + " ist nicht als FIFO deklariert!", this.Language, 101);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 6093 */     int count_b = count * bytes_per_value(adt);
/* 6094 */     req.data = new byte[count_b];
/* 6095 */     switch (adt) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 6098 */         idata = new int[count];
/* 6099 */         convert_data_from_float_to_int(data, idata, count);
/* 6100 */         convert_data_from_int_to_stream(idata, req.data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 6103 */         convert_data_from_float_to_stream(data, req.data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 6106 */         ddata = new double[count];
/* 6107 */         convert_data_from_float_to_double(data, ddata, count);
/* 6108 */         convert_data_from_double_to_stream(ddata, req.data, count);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6117 */     if (set_fifo == 1) {
/* 6118 */       init_ati(25);
/*      */     } else {
/* 6120 */       init_ati(8);
/*      */     } 
/* 6122 */     setInteger(this.ati.req.data, 0, datanumber);
/* 6123 */     setInteger(this.ati.req.data, 4, start);
/* 6124 */     setInteger(this.ati.req.data, 8, count);
/* 6125 */     setInteger(this.ati.req.data, 12, info[0]);
/*      */     
/* 6127 */     this.ati.req.used = 16;
/* 6128 */     req.do_convert = 0;
/* 6129 */     req.used = count_b;
/*      */     
/* 6131 */     if (tcp_write_request(this.ati, req) == -1) {
/*      */       return;
/*      */     }
/* 6134 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void adwin_tcp_set_data_or_fifo_double(int datanumber, double[] data, int start, int count, int set_fifo) throws ADwinCommunicationError {
/*      */     int i, idata[];
/*      */     float[] fdata;
/* 6142 */     adwin_tcp_buffer_t req = new adwin_tcp_buffer_t();
/*      */     
/* 6144 */     if (count < 1) {
/* 6145 */       throw new IllegalArgumentException((this.Language == 1) ? ("setting DATA_" + datanumber + ": Only a positive Number of elements can be set!") : (
/* 6146 */           "Nur eine positive Anzahl von Elementen kann bei DATA_" + datanumber + " gesetzt werden!"));
/*      */     }
/*      */     
/* 6149 */     int[] info = new int[4];
/* 6150 */     adwin_tcp_get_data_info(datanumber, info);
/* 6151 */     if (this.ati.error_number != 0) {
/*      */       return;
/*      */     }
/* 6154 */     adwin_data_type_t adt = int_to_adwin_data_type(info[0]);
/* 6155 */     int data_size = info[1];
/* 6156 */     int is_fifo = info[2];
/* 6157 */     int fifo_full = info[3];
/*      */ 
/*      */     
/* 6160 */     if (data_size < start - 1 + count) {
/* 6161 */       throw new ADwinCommunicationError("Data is too small", "Data zu klein", this.Language, 100);
/*      */     }
/*      */     
/* 6164 */     if (this.ati.processortype == 1012) {
/* 6165 */       if (is_fifo == 1 && set_fifo == 1 && count > data_size - fifo_full) {
/* 6166 */         throw new ADwinCommunicationError("There is not enough space left in fifo " + datanumber, "Nicht genug Platz übrig in Fifo " + datanumber, this.Language, 101);
/*      */       }
/* 6168 */       if (set_fifo == 1 && is_fifo == 0) {
/* 6169 */         throw new ADwinCommunicationError("Data " + datanumber + " isn't a fifo!", "Data " + datanumber + " ist nicht als FIFO deklariert!", this.Language, 101);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 6174 */     int count_b = count * bytes_per_value(adt);
/* 6175 */     req.data = new byte[count_b];
/* 6176 */     switch (adt) {
/*      */       case ADWIN_LONG:
/*      */       case ADWIN_INTEGER:
/* 6179 */         idata = new int[count];
/* 6180 */         for (i = 0; i < count; i++) {
/* 6181 */           idata[i] = (int)data[i];
/*      */         }
/* 6183 */         convert_data_from_int_to_stream(idata, req.data, count);
/*      */         break;
/*      */       case ADWIN_FLOAT:
/* 6186 */         fdata = new float[count];
/* 6187 */         convert_data_from_double_to_float(data, fdata, count);
/* 6188 */         convert_data_from_float_to_stream(fdata, req.data, count);
/*      */         break;
/*      */       case ADWIN_DOUBLE:
/* 6191 */         convert_data_from_double_to_stream(data, req.data, count);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6200 */     if (set_fifo == 1) {
/* 6201 */       init_ati(25);
/*      */     } else {
/* 6203 */       init_ati(8);
/*      */     } 
/* 6205 */     setInteger(this.ati.req.data, 0, datanumber);
/* 6206 */     setInteger(this.ati.req.data, 4, start);
/* 6207 */     setInteger(this.ati.req.data, 8, count);
/* 6208 */     setInteger(this.ati.req.data, 12, info[0]);
/*      */     
/* 6210 */     this.ati.req.used = 16;
/* 6211 */     req.do_convert = 0;
/* 6212 */     req.used = count_b;
/*      */     
/* 6214 */     if (tcp_write_request(this.ati, req) == -1) {
/*      */       return;
/*      */     }
/* 6217 */     tcp_read_response(this.ati, 0, null);
/*      */   }
/*      */   
/*      */   void adwin_tcp_set_data_string(int datanumber, String s, int max_count) throws ADwinCommunicationError {
/* 6221 */     int length = s.length();
/*      */     
/* 6223 */     if (length > max_count) {
/* 6224 */       length = max_count;
/*      */     }
/*      */     
/* 6227 */     if (this.ati.processortype == 1012) {
/* 6228 */       byte[] stringdata = s.getBytes();
/* 6229 */       int strlen = stringdata.length + 1;
/* 6230 */       byte[] data = new byte[strlen];
/*      */       
/* 6232 */       System.arraycopy(stringdata, 0, data, 0, strlen - 1);
/* 6233 */       data[strlen - 1] = 0;
/*      */       
/* 6235 */       adwin_tcp_set_data_or_fifo_int8(datanumber, data, 0, strlen, 0);
/*      */     } else {
/* 6237 */       int[] data = new int[length + 2];
/* 6238 */       data[0] = length;
/* 6239 */       for (int i = 0; i < length; i++) {
/* 6240 */         data[i + 1] = s.charAt(i);
/*      */       }
/* 6242 */       data[length + 1] = 0;
/* 6243 */       adwin_tcp_set_data_or_fifo_int32(datanumber, data, 1, length + 2, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void convert_data_from_stream_to_int(byte[] from_data, int[] to_data, int count) {
/* 6250 */     for (int i = 0; i < count; i++) {
/* 6251 */       to_data[i] = extractInt(from_data, i * 4);
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_stream_to_long(byte[] from_data, long[] to_data, int count) {
/* 6256 */     for (int i = 0; i < count; i++) {
/* 6257 */       to_data[i] = extractLong(from_data, i * 8);
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_stream_to_float(byte[] from_data, float[] to_data, int count) {
/* 6262 */     for (int i = 0; i < count; i++) {
/* 6263 */       to_data[i] = Float.intBitsToFloat(extractInt(from_data, i * 4));
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_stream_to_double(byte[] from_data, double[] to_data, int count) {
/* 6268 */     for (int i = 0; i < count; i++) {
/* 6269 */       to_data[i] = ByteBuffer.wrap(from_data, i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void convert_data_from_int_to_stream(int[] from_data, byte[] to_data, int count) {
/* 6276 */     for (int i = 0; i < count; i++) {
/* 6277 */       setInteger(to_data, i * 4, from_data[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_long_to_stream(long[] from_data, byte[] to_data, int count) {
/* 6282 */     for (int i = 0; i < count; i++) {
/* 6283 */       setLong(to_data, i * 8, from_data[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_float_to_stream(float[] from_data, byte[] to_data, int count) {
/* 6288 */     for (int i = 0; i < count; i++) {
/* 6289 */       setInteger(to_data, i * 4, Float.floatToIntBits(from_data[i]));
/*      */     }
/*      */   }
/*      */   
/*      */   void convert_data_from_double_to_stream(double[] from_data, byte[] to_data, int count) {
/* 6294 */     for (int i = 0; i < count; i++) {
/* 6295 */       ByteBuffer.wrap(to_data, i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).putDouble(from_data[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_float_to_int(float[] from_data, int[] to_data, int count) {
/* 6301 */     for (int i = 0; i < count; i++) {
/* 6302 */       to_data[i] = (int)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_float_to_long(float[] from_data, long[] to_data, int count) {
/* 6308 */     for (int i = 0; i < count; i++) {
/* 6309 */       to_data[i] = (long)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_float_to_double(float[] from_data, double[] to_data, int count) {
/* 6315 */     for (int i = 0; i < count; i++) {
/* 6316 */       to_data[i] = from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_byte_to_int(byte[] from_data, int[] to_data, int count) {
/* 6322 */     for (int i = 0; i < count; i++) {
/* 6323 */       to_data[i] = from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_int_to_byte(int[] from_data, byte[] to_data, int count) {
/* 6329 */     for (int i = 0; i < count; i++) {
/* 6330 */       to_data[i] = (byte)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_int_to_float(int[] from_data, float[] to_data, int count) {
/* 6336 */     for (int i = 0; i < count; i++) {
/* 6337 */       to_data[i] = from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_int_to_double(int[] from_data, double[] to_data, int count) {
/* 6343 */     for (int i = 0; i < count; i++) {
/* 6344 */       to_data[i] = from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_int_to_long(int[] from_data, long[] to_data, int count) {
/* 6350 */     for (int i = 0; i < count; i++) {
/* 6351 */       to_data[i] = from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_long_to_int(long[] from_data, int[] to_data, int count) {
/* 6357 */     for (int i = 0; i < count; i++) {
/* 6358 */       to_data[i] = (int)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void convert_data_from_double_to_float(double[] from_data, float[] to_data, int count) {
/* 6365 */     for (int i = 0; i < count; i++) {
/* 6366 */       to_data[i] = (float)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_double_to_int(double[] from_data, int[] to_data, int count) {
/* 6372 */     for (int i = 0; i < count; i++) {
/* 6373 */       to_data[i] = (int)from_data[i];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void convert_data_from_double_to_long(double[] from_data, long[] to_data, int count) {
/* 6379 */     for (int i = 0; i < count; i++) {
/* 6380 */       to_data[i] = (long)from_data[i];
/*      */     }
/*      */   }
/*      */   
/*      */   int map_error_code(int adwin_error) {
/* 6385 */     switch (adwin_error) {
/*      */       case -1:
/* 6387 */         return 2001;
/*      */       case -5:
/* 6389 */         return 2002;
/*      */       case -100:
/*      */       case -31:
/* 6392 */         return 100;
/*      */       case -32:
/* 6394 */         return 102;
/*      */       case -35:
/* 6396 */         return 205;
/*      */     } 
/* 6398 */     return adwin_error;
/*      */   }
/*      */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinDirectDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */