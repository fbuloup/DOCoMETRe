/*     */ package de.adwin.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GetDataSHQueue
/*     */ {
/*     */   private final int[] queue;
/*     */   private int requestNumber;
/*     */   private int lastReceived;
/*     */   private final int packetIndex;
/*     */   private int queueInsertPointer;
/*     */   private int queueDeletePointer;
/*     */   private final DatagramSocket ds;
/*     */   private final ADwinDirectDevice add;
/*     */   private final InetAddress addr;
/*     */   private final int port;
/*     */   
/*     */   class GetDataSHRequest
/*     */   {
/*     */     static final int REQ_SINGLE = 0;
/*     */     static final int REQ_RANGE = 1;
/*     */     static final int REQ_END = 2;
/*  31 */     int isRange = 0;
/*  32 */     int p1_firstRequested = 0, p2_lastRequested = 0;
/*  33 */     int packetIndex = 0;
/*  34 */     int requestNumber = 0;
/*  35 */     int completePackets = 0;
/*     */ 
/*     */     
/*     */     GetDataSHRequest() {}
/*     */ 
/*     */     
/*     */     GetDataSHRequest(int packetIndex, int requestNumber, int completePackets, int p1) {
/*  42 */       this.isRange = 0;
/*  43 */       this.p1_firstRequested = p1;
/*  44 */       this.packetIndex = packetIndex;
/*  45 */       this.requestNumber = requestNumber;
/*  46 */       this.completePackets = completePackets;
/*     */     }
/*     */ 
/*     */     
/*     */     GetDataSHRequest(int packetIndex, int requestNumber, int completePackets, int p1, int p2) {
/*  51 */       this.isRange = 1;
/*  52 */       this.p1_firstRequested = p1;
/*  53 */       this.p2_lastRequested = p2;
/*  54 */       this.packetIndex = packetIndex;
/*  55 */       this.requestNumber = requestNumber;
/*  56 */       this.completePackets = completePackets;
/*     */     }
/*     */ 
/*     */     
/*     */     GetDataSHRequest(int packetIndex, int requestNumber) {
/*  61 */       this.isRange = 2;
/*  62 */       this.requestNumber = requestNumber;
/*  63 */       this.packetIndex = packetIndex;
/*     */     }
/*     */     
/*     */     DatagramPacket getPacket(InetAddress address, int port) {
/*  67 */       byte[] b = new byte[64];
/*     */       
/*  69 */       Arrays.fill(b, (byte)0);
/*  70 */       ADwinDirectDevice.setInteger(b, 0, ADwinDirectDevice.reverseByteOrder(this.packetIndex));
/*  71 */       ADwinDirectDevice.setInteger(b, 4, ADwinDirectDevice.reverseByteOrder(this.requestNumber));
/*  72 */       ADwinDirectDevice.setInteger(b, 8, ADwinDirectDevice.reverseByteOrder(this.completePackets));
/*  73 */       ADwinDirectDevice.setInteger(b, 12, ADwinDirectDevice.reverseByteOrder(this.isRange));
/*  74 */       ADwinDirectDevice.setInteger(b, 16, ADwinDirectDevice.reverseByteOrder(this.p1_firstRequested));
/*  75 */       ADwinDirectDevice.setInteger(b, 20, ADwinDirectDevice.reverseByteOrder(this.p2_lastRequested));
/*  76 */       return new DatagramPacket(b, 64, address, port);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class GetDataSHData
/*     */   {
/*     */     static final int PACKAGE_SIZE = 1344;
/*     */     static final int PARAM_SIZE = 12;
/*     */     static final int PACKET_SIZE = 1356;
/*     */     byte[] packetData;
/*  87 */     int packetIndex = 0;
/*     */     
/*     */     GetDataSHData(DatagramPacket dp) {
/*  90 */       this.packetData = dp.getData();
/*     */     }
/*     */     
/*     */     int getPacketIndex() {
/*  94 */       return ADwinDirectDevice.reverseByteOrder(ADwinDirectDevice.extractInt(this.packetData, 0));
/*     */     }
/*     */     
/*     */     int getPacketNumber() {
/*  98 */       return ADwinDirectDevice.reverseByteOrder(ADwinDirectDevice.extractInt(this.packetData, 4));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GetDataSHQueue(int size, int sentPacketIndex, DatagramSocket ds, ADwinDirectDevice add, InetAddress addr, int port) {
/* 133 */     this.queue = new int[size];
/* 134 */     this.packetIndex = sentPacketIndex;
/* 135 */     this.requestNumber = 0;
/* 136 */     this.ds = ds;
/* 137 */     this.add = add;
/* 138 */     this.addr = addr;
/* 139 */     this.port = port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getMin() {
/* 149 */     int min = 0;
/*     */     
/*     */     int i;
/*     */     
/* 153 */     for (i = 0; i < this.queue.length; i++) {
/* 154 */       if (this.queue[i] != 0) {
/* 155 */         min = this.queue[i];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 160 */     if (min == 0)
/*     */     {
/* 162 */       return 0;
/*     */     }
/*     */     
/* 165 */     for (; i < this.queue.length; i++) {
/* 166 */       if (this.queue[i] != 0 && this.queue[i] < min) {
/* 167 */         min = this.queue[i];
/*     */       }
/*     */     } 
/* 170 */     return min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deleteAll() {
/* 191 */     Arrays.fill(this.queue, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteItem(int item) {
/* 202 */     if (this.queue[this.queueDeletePointer] == item) {
/* 203 */       this.queue[this.queueDeletePointer] = 0;
/* 204 */       this.queueDeletePointer++;
/* 205 */       if (this.queueDeletePointer >= this.queue.length) {
/* 206 */         this.queueDeletePointer = 0;
/*     */       }
/* 208 */       return false;
/*     */     } 
/*     */     
/* 211 */     for (int i = 0; i < this.queue.length; i++) {
/* 212 */       if (this.queue[i] == item) {
/* 213 */         this.queue[i] = 0;
/* 214 */         this.queueDeletePointer = i + 1;
/* 215 */         if (this.queueDeletePointer >= this.queue.length) {
/* 216 */           this.queueDeletePointer = 0;
/*     */         }
/* 218 */         return false;
/*     */       } 
/*     */     } 
/* 221 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean insertItem(int item) {
/* 232 */     int full = 0;
/*     */     
/*     */     while (true) {
/* 235 */       if (this.queue[this.queueInsertPointer] == 0) {
/* 236 */         this.queue[this.queueInsertPointer] = item;
/* 237 */         this.queueInsertPointer++;
/* 238 */         if (this.queueInsertPointer >= this.queue.length) {
/* 239 */           this.queueInsertPointer = 0;
/*     */         }
/* 241 */         return true;
/*     */       } 
/* 243 */       this.queueInsertPointer++;
/* 244 */       if (this.queueInsertPointer >= this.queue.length) {
/* 245 */         this.queueInsertPointer = 0;
/*     */       }
/* 247 */       full++;
/* 248 */       if (full == this.queue.length) {
/* 249 */         return false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendRequest(int isRange, int p1, int p2, boolean enlist) throws ADwinCommunicationError {
/*     */     GetDataSHRequest gdshr;
/* 275 */     int min = 0;
/*     */     
/* 277 */     if (isRange != 2) {
/* 278 */       min = getMin();
/* 279 */       if (min == 0) {
/* 280 */         min = this.lastReceived;
/*     */       } else {
/* 282 */         min--;
/*     */       } 
/*     */     } 
/*     */     
/* 286 */     switch (isRange) {
/*     */       case 0:
/* 288 */         gdshr = new GetDataSHRequest(this.packetIndex, ++this.requestNumber, min, p1);
/*     */         break;
/*     */       case 1:
/* 291 */         gdshr = new GetDataSHRequest(this.packetIndex, ++this.requestNumber, min, p1, p2);
/*     */         break;
/*     */       case 2:
/* 294 */         gdshr = new GetDataSHRequest(this.packetIndex, ++this.requestNumber);
/*     */         break;
/*     */       default:
/* 297 */         throw new RuntimeException("invalid parameter isRange (" + isRange + ")");
/*     */     } 
/*     */     
/* 300 */     if (enlist) {
/* 301 */       if (isRange == 1) {
/* 302 */         for (int i = p1; i <= p2; i++) {
/* 303 */           insertItem(i);
/*     */         }
/* 305 */       } else if (isRange == 0) {
/* 306 */         insertItem(p1);
/*     */       } 
/*     */     }
/*     */     
/* 310 */     DatagramPacket dp = gdshr.getPacket(this.addr, this.port);
/*     */     try {
/* 312 */       this.ds.send(dp);
/* 313 */     } catch (IOException ioe) {
/* 314 */       throw new ADwinCommunicationError("I/O-Error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 315 */           .getMessage(), this.add.Language, 2000);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendAll() throws ADwinCommunicationError {
/* 325 */     for (int i = 0; i < this.queue.length; i++) {
/* 326 */       if (this.queue[i] != 0) {
/* 327 */         sendRequest(0, this.queue[i], 0, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendAllLessThan(int item) throws ADwinCommunicationError {
/* 340 */     for (int i = 0; i < this.queue.length; i++) {
/* 341 */       if (this.queue[i] < item && this.queue[i] != 0) {
/* 342 */         sendRequest(0, this.queue[i], 0, false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void getArraySH(int totalCount, DataToArrayConverter dtac) throws ADwinCommunicationError {
/* 357 */     int lastReceived = 0;
/*     */     
/* 359 */     int packetCount = totalCount / 336;
/* 360 */     if (totalCount % 336 != 0) {
/* 361 */       packetCount++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     deleteAll();
/*     */     
/* 369 */     int isRange = 1;
/* 370 */     int p1 = 1;
/* 371 */     int lastPacket = (packetCount <= 30) ? packetCount : 30, p2 = lastPacket;
/* 372 */     for (int i = 1; i <= p2; i++) {
/* 373 */       insertItem(i);
/*     */     }
/* 375 */     int openPackets = p2;
/*     */     
/* 377 */     int timeoutCounter = 0;
/*     */     
/* 379 */     byte[] bytes = new byte[1500];
/* 380 */     DatagramPacket dp = new DatagramPacket(bytes, 1500);
/* 381 */     while (openPackets > 0) {
/*     */       
/*     */       try {
/* 384 */         this.ds.setSoTimeout(this.add.MaxPacketDelay);
/* 385 */         this.ds.receive(dp);
/* 386 */         timeoutCounter = 0;
/* 387 */       } catch (SocketTimeoutException ste) {
/* 388 */         timeoutCounter++;
/* 389 */         if (timeoutCounter > this.add.AllowedErrors) {
/* 390 */           throw new ADwinCommunicationError("timeout when waiting for the data field", "Timeout beim Warten auf das Data", this.add.Language, 2001);
/*     */         }
/*     */       }
/* 393 */       catch (IOException ioe) {
/* 394 */         throw new ADwinCommunicationError("I/O error: " + ioe.getMessage(), "E/A-Fehler: " + ioe
/* 395 */             .getMessage(), this.add.Language, 2000);
/*     */       } 
/*     */ 
/*     */       
/* 399 */       if (timeoutCounter != 0) {
/* 400 */         sendAll();
/*     */       }
/* 402 */       else if (dp.getLength() == 1356) {
/* 403 */         GetDataSHData gdshd = new GetDataSHData(dp);
/* 404 */         if (gdshd.getPacketIndex() == this.packetIndex) {
/*     */           
/* 406 */           lastReceived = gdshd.getPacketNumber();
/* 407 */           if (!deleteItem(lastReceived)) {
/*     */             
/* 409 */             openPackets--;
/* 410 */             dtac.storeBytes(bytes, 12, (lastReceived - 1) * 336, 336);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 418 */       if (openPackets == 6 && lastPacket != packetCount) {
/* 419 */         p1 = lastPacket + 1;
/* 420 */         if (packetCount - lastPacket >= 24) {
/*     */           
/* 422 */           p2 = lastPacket + 30 - 6;
/* 423 */           openPackets += 24;
/* 424 */         } else if (lastPacket < packetCount) {
/*     */           
/* 426 */           p2 = packetCount;
/* 427 */           openPackets += packetCount - lastPacket;
/*     */         } 
/*     */ 
/*     */         
/* 431 */         sendAllLessThan(lastPacket - 6);
/*     */         
/* 433 */         lastPacket = p2;
/* 434 */         isRange = (p1 == p2) ? 0 : 1;
/* 435 */         sendRequest(isRange, p1, p2, true);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 441 */       sendRequest(2, 0, 0, false);
/* 442 */     } catch (ADwinCommunicationError aDwinCommunicationError) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\GetDataSHQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */