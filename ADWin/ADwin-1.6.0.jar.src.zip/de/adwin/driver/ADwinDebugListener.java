package de.adwin.driver;

public interface ADwinDebugListener extends ADwinDebugListenerPrioConstants {
  void tryLater(int paramInt1, int paramInt2);
  
  void sendAgain(int paramInt1, int paramInt2, int paramInt3);
  
  void recvAgain(int paramInt1, int paramInt2, int paramInt3);
  
  void message(String paramString, int paramInt);
  
  void enter(String paramString);
  
  void leave();
}


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinDebugListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */