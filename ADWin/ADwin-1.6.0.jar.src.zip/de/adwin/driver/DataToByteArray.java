/*     */ package de.adwin.driver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataToByteArray
/*     */   extends DataToArrayConverter
/*     */ {
/*     */   protected byte[] Array;
/*     */   
/*     */   DataToByteArray(int Size, int SourceType) {
/*  86 */     super(Size);
/*  87 */     this.Array = new byte[Size];
/*  88 */     this.SourceType = SourceType;
/*     */   }
/*     */   
/*     */   byte[] getArray() {
/*  92 */     return this.Array;
/*     */   }
/*     */ 
/*     */   
/*     */   void storeBytesImpl(byte[] Bytes, int BytesIndex, int IndexStart, int Amount) {
/*  97 */     switch (this.SourceType) {
/*     */       case 1:
/*     */       case 8:
/* 100 */         if (Amount >= 0) System.arraycopy(Bytes, BytesIndex, this.Array, IndexStart, Amount); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   String getString() {
/* 106 */     StringBuilder Str = new StringBuilder(0);
/*     */     
/* 108 */     for (int n = 0; n < this.Array.length && this.Array[n] != 0; n++) {
/* 109 */       Str.append((char)this.Array[n]);
/*     */     }
/* 111 */     return Str.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataToByteArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */