/*     */ package de.adwin.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataToIntArray
/*     */   extends DataToArrayConverter
/*     */ {
/*     */   protected int[] Array;
/*     */   
/*     */   DataToIntArray(int Size, int SourceType) {
/* 120 */     super(Size);
/* 121 */     this.Array = new int[Size];
/* 122 */     this.SourceType = SourceType;
/*     */   }
/*     */   
/*     */   int[] getArray() {
/* 126 */     return this.Array;
/*     */   }
/*     */   
/*     */   void storeBytesImpl(byte[] Bytes, int BytesIndex, int IndexStart, int Amount) {
/*     */     int i;
/* 131 */     switch (this.SourceType) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 8:
/* 135 */         for (i = 0; i < Amount; i++) {
/* 136 */           this.Array[IndexStart + i] = ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4);
/*     */         }
/*     */         break;
/*     */       case 5:
/* 140 */         for (i = 0; i < Amount; i++) {
/* 141 */           this.Array[IndexStart + i] = (int)Float.intBitsToFloat(ADwinDirectDevice.extractInt(Bytes, BytesIndex + i * 4));
/*     */         }
/*     */         break;
/*     */       case 6:
/* 145 */         for (i = 0; i < Amount; i++) {
/* 146 */           this.Array[IndexStart + i] = (int)ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getDouble();
/*     */         }
/*     */         break;
/*     */       case 7:
/* 150 */         for (i = 0; i < Amount; i++)
/* 151 */           this.Array[IndexStart + i] = (int)ByteBuffer.wrap(Bytes, BytesIndex + i * 8, 8).order(ByteOrder.LITTLE_ENDIAN).getLong(); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   String getString() {
/* 157 */     StringBuilder Str = new StringBuilder(0);
/*     */     
/* 159 */     for (int n = 1; n < this.Array.length && this.Array[n] != 0; n++) {
/* 160 */       Str.append((char)this.Array[n]);
/*     */     }
/* 162 */     return Str.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\DataToIntArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */