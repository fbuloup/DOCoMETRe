/*     */ package de.adwin.driver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ADwinCommunicationError
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -5442029274320045585L;
/*  27 */   private int code = 0;
/*  28 */   private int LangId = 1;
/*     */   
/*     */   public ADwinCommunicationError(String StrEnglish, String StrGer, int LangID, int code) {
/*  31 */     super((LangID == 1) ? StrEnglish : StrGer);
/*  32 */     this.code = code;
/*  33 */     this.LangId = LangID;
/*     */   }
/*     */   
/*     */   public ADwinCommunicationError(String StrEnglish, String StrGer, int LangID) {
/*  37 */     super((LangID == 1) ? StrEnglish : StrGer);
/*  38 */     this.LangId = LangID;
/*     */   }
/*     */   
/*     */   public ADwinCommunicationError(String Str, int code) {
/*  42 */     super(Str);
/*  43 */     this.code = code;
/*     */   }
/*     */   
/*     */   public ADwinCommunicationError(String Str) {
/*  47 */     super(Str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ADwinCommunicationError() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/*  80 */     return this.code;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  85 */     String t = "";
/*  86 */     switch (getCode()) {
/*     */       
/*     */       case 1:
/*  89 */         t = (this.LangId == 1) ? "Timeout error on writing to the ADwin System - " : "Timeout Fehler beim Schreiben zum ADwin System - ";
/*     */         break;
/*     */       
/*     */       case 2:
/*  93 */         t = (this.LangId == 1) ? "Timeout error when reading from the ADwin System. - " : "Timeout Fehler beim Lesen vom ADwin-System. - ";
/*     */         break;
/*     */       
/*     */       case 20:
/*  97 */         t = (this.LangId == 1) ? "Incompatible versions of ADwin operating system ,\ndriver and/or ADbasic binary-file. - " : "Inkompatible Versionen von ADwin-Betriebssystem, Treiberdatei und / oder ADbasic-Binärdatei. - ";
/*     */         break;
/*     */       
/*     */       case 100:
/* 101 */         t = (this.LangId == 1) ? "The Data is too small. - " : "Das DATA-Feld ist zu klein. - ";
/*     */         break;
/*     */       
/*     */       case 101:
/* 105 */         t = (this.LangId == 1) ? "The Fifo is too small or not enough values. - " : "Das FIFO-Feld ist zu klein oder nicht genug Daten. - ";
/*     */         break;
/*     */       
/*     */       case 150:
/* 109 */         t = (this.LangId == 1) ? "Not enough memory or memory access error. -" : "Nicht genug Speicher oder Speicherzugriffsfehler";
/*     */         break;
/*     */       
/*     */       case 200:
/* 113 */         t = (this.LangId == 1) ? "File not found. - " : "Datei konnte nicht gefunden werden. - ";
/*     */         break;
/*     */       
/*     */       case 202:
/* 117 */         t = (this.LangId == 1) ? "The file is not an ADBasic binary-file. - " : "Die Datei ist keine ADbasic Binärdatei. - ";
/*     */         break;
/*     */       
/*     */       case 204:
/* 121 */         t = (this.LangId == 1) ? "The file is not a BTL. - " : "Die Datei ist keine BTL. - ";
/*     */         break;
/*     */       
/*     */       case 2000:
/* 125 */         t = (this.LangId == 1) ? "Network error (TcpIp). - " : "Netzwerk Fehler (TCP/IP). - ";
/*     */         break;
/*     */       
/*     */       case 2001:
/* 129 */         t = (this.LangId == 1) ? "Network timeout. - " : "Netzwerk timeout. - ";
/*     */         break;
/*     */       
/*     */       case 2002:
/* 133 */         t = (this.LangId == 1) ? "Wrong password. - " : "Falsches Passwort. - ";
/*     */         break;
/*     */     } 
/* 136 */     return t + super.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\Buloup\Documents\GIT\DOCoMETRe\ADWin\ADwin-1.6.0.jar!\de\adwin\driver\ADwinCommunicationError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */